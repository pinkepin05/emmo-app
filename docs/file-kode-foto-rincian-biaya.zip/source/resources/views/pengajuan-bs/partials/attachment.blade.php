@if($bs->isPerjalananDinas() && $bs->attachment_path)
    <div class="card-custom mb-4">
        <div class="section-title">Lampiran (Laporan HRIS / Izin Perjalanan Dinas)</div>
        <div class="d-flex flex-wrap align-items-center gap-3 p-3 rounded bg-light border">
            <i class="bi bi-file-earmark-text fs-2 text-primary" aria-hidden="true"></i>
            <div class="flex-grow-1" style="min-width: 0; overflow-wrap: anywhere;">
                <div class="fw-semibold">{{ $bs->attachment_name ?: 'Dokumen Pendukung' }}</div>
                <small class="text-muted">Terunggah pada {{ \App\Support\AppTime::format($bs->created_at) }}</small>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="{{ route('pengajuan-bs.attachment', $bs) }}" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-eye me-1"></i> Lihat
                </a>
                <a href="{{ route('pengajuan-bs.attachment', ['bs' => $bs, 'download' => 1]) }}" class="btn btn-sm btn-primary">
                    <i class="bi bi-download me-1"></i> Unduh
                </a>
            </div>
        </div>
        @if($forApproval ?? false)
            <p class="small text-muted mt-3 mb-0">Periksa lampiran sebelum memproses pengajuan.</p>
        @endif
    </div>
@endif
