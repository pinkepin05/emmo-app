# Perjalanan Dinas — form pada screenshot

Salinan kode saat pemetaan 8 Oktober 2026. Fitur foto per rincian belum diimplementasikan.

## resources/views/transaksi_perjalanan_dinas/create.blade.php

Form pembuatan, baris awal, template Tambah Baris, dan JavaScript inline; titik utama penambahan input foto.

~~~~php
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Input Perjalanan Dinas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
:root {
--primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
--success-gradient: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
--danger-gradient: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%);
--info-gradient: linear-gradient(135deg, #00c6fb 0%, #005bea 100%);
--primary-color: #667eea;
--success-color: #11998e;
--info-color: #0099e5;
--bg-color: #f0f4f8;
}
body {
font-family: 'Plus Jakarta Sans', sans-serif;
background: var(--bg-color);
background-image: radial-gradient(#667eea 0.5px, transparent 0.5px), radial-gradient(#667eea 0.5px, var(--bg-color) 0.5px);
background-size: 20px 20px;
background-position: 0 0, 10px 10px;
min-height: 100vh;
}
.text-success { color: #11998e !important; }
.text-danger  { color: #e11d48 !important; }
.text-primary { color: #667eea !important; }
.text-info    { color: #0099e5 !important; }
.text-muted   { color: #718096 !important; }
.bg-success   { background-color: #11998e !important; }
.bg-danger    { background-color: #e11d48 !important; }
.bg-warning   { background-color: #f59e0b !important; }
.page-header { background: var(--primary-gradient); color: white; padding: 2rem 0; margin-bottom: 2rem; box-shadow: 0 10px 40px rgba(102, 126, 234, 0.3); }
.page-header h1 { font-weight: 800; margin: 0; font-size: 2rem; }
.page-header p  { margin: 0.5rem 0 0 0; opacity: 0.9; }
.card-modern { background: white; border: none; border-radius: 20px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08); overflow: hidden; margin-bottom: 2rem; }
.card-header-modern { background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); border-bottom: 2px solid rgba(102, 126, 234, 0.1); padding: 1.5rem 2rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; }
.card-header-modern.success { background: linear-gradient(135deg, rgba(17, 153, 142, 0.1) 0%, rgba(56, 239, 125, 0.1) 100%); border-bottom-color: rgba(17, 153, 142, 0.2); }
.card-header-modern.info { background: linear-gradient(135deg, rgba(0, 198, 251, 0.1) 0%, rgba(0, 91, 234, 0.1) 100%); border-bottom-color: rgba(0, 153, 229, 0.2); }
.card-header-modern h5 { margin: 0; font-weight: 700; color: #2d3748; display: flex; align-items: center; gap: 0.75rem; }
.card-header-modern h5 i { font-size: 1.5rem; background: var(--primary-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.card-header-modern.success h5 i { background: var(--success-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.card-header-modern.info h5 i { background: var(--info-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.form-label { font-weight: 600; color: #4a5568; margin-bottom: 0.5rem; font-size: 0.9rem; display: flex; align-items: center; flex-wrap: wrap; gap: 0.4rem; }
.form-control, .form-select { border: 2px solid #e2e8f0; border-radius: 12px; padding: 0.75rem 1rem; font-size: 0.95rem; transition: border-color 0.3s ease, box-shadow 0.3s ease; }
.form-control:focus, .form-select:focus { border-color: var(--primary-color); box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1); }
.form-control:disabled, .form-select:disabled { background: #f7fafc; border-color: #e2e8f0; opacity: 0.8; }
textarea.form-control { border-radius: 15px; }
.input-group-text { background: white; border: 2px solid #e2e8f0; color: var(--primary-color); font-weight: 600; }
.input-with-icon .input-group-text { border-right: none; border-radius: 12px 0 0 12px; }
.input-with-icon .form-control     { border-radius: 0 12px 12px 0; }
.input-suffix .input-group-text    { border-left: none; border-radius: 0 12px 12px 0; background: #f8fafc; color: #4a5568; }
.input-suffix .form-control        { border-radius: 12px 0 0 12px; }
.helper-text { font-size: 0.78rem; color: #718096; margin-top: 0.4rem; display: block; }
.rule-badge { font-size: 0.7rem; font-weight: 700; padding: 0.35rem 0.7rem; border-radius: 20px; letter-spacing: 0.3px; }
.rule-badge.lumpsum { background: rgba(0, 198, 251, 0.12); color: #0077b6; border: 1px solid rgba(0, 153, 229, 0.35); }
.rule-badge.hotel   { background: rgba(245, 158, 11, 0.12); color: #92400e; border: 1px solid rgba(245, 158, 11, 0.35); }
.status-info { min-height: 1.3rem; margin-top: 0.4rem; font-size: 0.82rem; font-weight: 600; }
.btn-modern { border-radius: 12px; padding: 0.75rem 1.5rem; font-weight: 600; border: none; display: inline-flex; align-items: center; gap: 0.5rem; }
.btn-primary-modern { background: var(--primary-gradient); color: white; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); border-radius: 15px; font-weight: 700; letter-spacing: 0.3px; }
.btn-primary-modern:hover, .btn-primary-modern:focus, .btn-primary-modern:active { background: var(--primary-gradient); color: white; transform: none; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); }
.btn-success-modern { background: var(--success-gradient); color: white; box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4); transition: all 0.3s ease; }
.btn-success-modern:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(17, 153, 142, 0.5); color: white; }
.btn-danger-modern { background: var(--danger-gradient); color: white; box-shadow: 0 4px 15px rgba(238, 9, 121, 0.4); transition: all 0.3s ease; }
.btn-danger-modern:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(238, 9, 121, 0.5); color: white; }
.btn-icon { width: 40px; height: 40px; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; padding: 0; }
.preview-box { border: none; border-radius: 15px; padding: 1rem 1.5rem; font-weight: 500; display: flex; align-items: center; gap: 0.6rem; }
.preview-box.alert-info    { background: linear-gradient(135deg, rgba(0,198,251,.12), rgba(0,91,234,.06));  color: #0077b6; border-left: 4px solid #0099e5; }
.preview-box.alert-success { background: linear-gradient(135deg, rgba(17,153,142,.12), rgba(56,239,125,.06)); color: #0f766e; border-left: 4px solid #11998e; }
.preview-box.alert-warning { background: linear-gradient(135deg, rgba(245,158,11,.12), rgba(245,158,11,.05)); color: #92400e; border-left: 4px solid #f59e0b; }
.stat-box { background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 15px; padding: 1.25rem; text-align: center; }
.stat-box small { color: #718096; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; font-size: 0.72rem; }
.stat-box .value { font-size: 1.4rem; font-weight: 800; margin-top: 0.25rem; display: block; }
#info-plafon-total   { color: #667eea !important; }
#info-total-input    { color: #11998e !important; }
#info-sisa-anggaran  { color: #0099e5 !important; }
#info-sisa-anggaran.text-danger { color: #e11d48 !important; }
#plafon-status-message .badge { padding: 0.6rem 1.25rem; border-radius: 30px; font-weight: 700; font-size: 0.85rem; }
.table-modern { width: 100%; border-collapse: separate; border-spacing: 0; }
.table-modern thead th { background: linear-gradient(135deg, rgba(17, 153, 142, 0.06) 0%, rgba(56, 239, 125, 0.06) 100%); border-bottom: 2px solid #e2e8f0; padding: 1rem; font-weight: 700; color: #2d3748; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.5px; }
.table-modern tbody td { padding: 1rem; border-bottom: 1px solid #f0f4f8; vertical-align: middle; }
.table-modern tbody tr:hover { background: rgba(17, 153, 142, 0.02); }
.total-badge { background: linear-gradient(135deg, rgba(17, 153, 142, 0.1) 0%, rgba(56, 239, 125, 0.1) 100%); border: 2px solid var(--success-color); border-radius: 15px; padding: 0.75rem 1.5rem; text-align: right; }
.total-badge .amount { font-size: 1.6rem; font-weight: 800; line-height: 1.2; }
#total-rincian.text-success { color: #11998e !important; }
#total-rincian.text-danger  { color: #e11d48 !important; }
.info-box { background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%); border-left: 4px solid var(--primary-color); border-radius: 12px; padding: 1rem 1.5rem; margin-top: 0.75rem; }
.alert-custom { border-radius: 15px; border: none; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); padding: 1rem 1.5rem; }
#plafon-over-warning { border-radius: 15px; border: none; border-left: 5px solid #f59e0b; background: linear-gradient(135deg, rgba(245, 158, 11, 0.12), rgba(245, 158, 11, 0.05)); color: #92400e; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08); }
.badge-category { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.5rem 1rem; border-radius: 20px; font-weight: 600; font-size: 0.85rem; }
.section-divider { height: 2px; background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.2), transparent); margin: 1.5rem 0; }
@keyframes slideIn { from { opacity: 0; transform: translateY(20px); } to   { opacity: 1; transform: translateY(0); } }
.animate-slide-in { animation: slideIn 0.5s ease; }
/* 🎯 Tambahan: Input nominal format Rupiah */
.nominal-formatted { text-align: right; font-weight: 600; font-variant-numeric: tabular-nums; letter-spacing: 0.5px; }
@media (max-width: 768px) {
.page-header h1 { font-size: 1.5rem; }
.card-header-modern { flex-direction: column; text-align: center; }
.total-badge { text-align: center; }
}
</style>
    @include('partials.mobile-assets')
</head>
<body>
    @include('partials.application-time')
<div class="page-header">
<div class="container">
<div class="row align-items-center">
<div class="col-md-8">
<h1><i class="bi bi-airplane me-3"></i>Perjalanan Dinas</h1>
<p class="mb-0">Input transaksi perjalanan dinas dengan validasi plafon real-time</p>
</div>
<div class="col-md-4 text-md-end mt-3 mt-md-0">
<a href="{{ route('dashboard.transaksi') }}" class="btn btn-light btn-modern">
<i class="bi bi-arrow-left"></i> Kembali
</a>
</div>
</div>
</div>
</div>
<div class="container" style="max-width: 1100px; margin-bottom: 3rem;">
@if(session('success'))
<div class="alert alert-success alert-custom alert-dismissible fade show mb-4">
<div class="d-flex align-items-center">
<i class="bi bi-check-circle-fill me-3 fs-4"></i>
<div><strong>Berhasil!</strong> {{ session('success') }}</div>
</div>
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif
@if($errors->any())
<div class="alert alert-danger alert-custom alert-dismissible fade show mb-4">
<div class="d-flex align-items-center">
<i class="bi bi-exclamation-circle-fill me-3 fs-4"></i>
<div>
<strong>Gagal Menyimpan:</strong>
<ul class="mb-0 mt-2">
@foreach($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
</div>
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif
@if(!auth()->user()->hasActiveCompany())
<div class="alert alert-warning alert-custom mb-4">
<i class="bi bi-exclamation-triangle-fill me-2"></i>
Company Anda (<strong>{{ auth()->user()->company->code ?? '-' }}</strong>) sedang <strong>tidak aktif</strong>.
Form tetap dapat diisi, namun transaksi akan <strong>ditolak</strong> saat disimpan.
</div>
@endif
<form action="{{ route('transaksi_perjalanan_dinas.store') }}" method="POST" id="form-perjalanan-dinas">
@csrf
<input type="hidden" name="tujuan_dinas_id" id="tujuan_dinas_id" value="{{ old('tujuan_dinas_id') }}" required>
<div class="card-modern animate-slide-in">
<div class="card-header-modern">
<h5><i class="bi bi-signpost-2"></i> Header Perjalanan Dinas</h5>
<span class="badge bg-primary bg-opacity-10 text-primary">Step 1 dari 2</span>
</div>
<div class="card-body p-4">
<div class="row g-4">
<div class="col-md-3">
<label class="form-label"><i class="bi bi-calendar-event text-primary"></i>Tanggal Dinas <span class="text-danger">*</span></label>
<div class="input-group input-with-icon">
<span class="input-group-text"><i class="bi bi-calendar"></i></span>
@php
$initialDate = old('tanggal', \App\Support\AppTime::now()->toDateString());
if (in_array($initialDate, $usedDates, true)) $initialDate = '';
@endphp
<input type="text" id="tanggal_picker" name="tanggal" class="form-control" value="{{ $initialDate }}" placeholder="Pilih tanggal..." required autocomplete="off" aria-describedby="tanggal-help">
</div>
<small id="tanggal-help" class="helper-text">Tanggal yang sudah memiliki transaksi Perjalanan Dinas Anda, termasuk draft, tidak dapat dipilih. Tambahkan rincian biaya pada transaksi yang sudah ada.</small>
<div id="periodWarning" class="alert alert-danger d-none mt-2" style="border-radius:12px;">
<i class="bi bi-lock-fill me-2"></i><span id="periodWarningText"></span>
</div>
</div>
<div class="col-md-4">
<label class="form-label"><i class="bi bi-person-badge text-primary"></i>User (Karyawan)</label>
<div class="input-group input-with-icon">
<span class="input-group-text"><i class="bi bi-lock"></i></span>
<input type="text" class="form-control bg-light" value="{{ Auth::user()->nama ?? Auth::user()->name }} (NIK: {{ Auth::user()->NIK ?? '-' }})" readonly disabled>
</div>
<small class="helper-text"><i class="bi bi-info-circle me-1"></i>Transaksi otomatis dicatat atas nama akun Anda</small>
</div>
<div class="col-md-5">
<label class="form-label"><i class="bi bi-map text-primary"></i>Territory <span class="text-danger">*</span></label>
<select name="teritory" id="teritory-select" class="form-select" required>
<option value="">-- Pilih Territory --</option>
<option value="Jawa" {{ old('teritory') == 'Jawa' ? 'selected' : '' }}>Jawa (Pulau Jawa)</option>
<option value="Luar Jawa" {{ old('teritory') == 'Luar Jawa' ? 'selected' : '' }}>Luar Jawa</option>
</select>
</div>
</div>
<div class="row g-4 mt-1">
<div class="col-md-6">
<label class="form-label"><i class="bi bi-geo text-primary"></i>Provinsi Tujuan <span class="text-danger">*</span></label>
<select id="provinsi-select" class="form-select" required disabled>
<option value="">-- Pilih Territory Terlebih Dahulu --</option>
</select>
<small class="helper-text">*Provinsi akan memfilter pilihan Kota/Kabupaten</small>
</div>
<div class="col-md-6">
<label class="form-label"><i class="bi bi-building text-primary"></i>Kota/Kabupaten Tujuan <span class="text-danger">*</span></label>
<select id="kota-select" class="form-select" required disabled>
<option value="">-- Pilih Provinsi Terlebih Dahulu --</option>
</select>
<small class="helper-text">*Pilih Kota/Kabupaten spesifik sebagai tujuan dinas</small>
</div>
</div>
<div class="mt-4">
<label class="form-label"><i class="bi bi-geo-alt-fill text-primary"></i>Tujuan Dinas Terpilih</label>
<div class="alert alert-info mb-0 preview-box" id="preview-tujuan">
<i class="bi bi-geo-alt fs-5"></i>
<span id="preview-text">Belum ada wilayah yang dipilih.</span>
</div>
</div>
<div class="section-divider"></div>
<div class="row g-4">
<div class="col-md-6">
<label class="form-label"><i class="bi bi-signpost-split text-primary"></i>Jarak Perjalanan (KM) <span class="rule-badge lumpsum">&gt;200 KM = Dapat Lumpsum</span></label>
<div class="input-group input-suffix">
<input type="number" name="jarak_km" id="jarak_km" class="form-control" placeholder="0" value="{{ old('jarak_km', 0) }}" min="0" step="0.1" required>
<span class="input-group-text">KM</span>
</div>
<div id="lumpsum-info" class="status-info"></div>
</div>
<div class="col-md-6">
<label class="form-label"><i class="bi bi-clock-history text-primary"></i>Durasi Perjalanan (Jam) <span class="rule-badge hotel">&gt;8 Jam = Dapat Hotel</span></label>
<div class="input-group input-suffix">
<input type="number" name="durasi_jam" id="durasi_jam" class="form-control" placeholder="Contoh: 12.5" value="{{ old('durasi_jam', 0) }}" min="0" max="24" step="0.5" required>
<span class="input-group-text">Jam</span>
</div>
<div id="hotel-info" class="status-info"></div>
</div>
</div>
<div class="mt-3">
<label class="form-label"><i class="bi bi-file-text text-primary"></i>Deskripsi Perjalanan / Tugas <span class="text-danger">*</span></label>
<textarea name="description" class="form-control" rows="3" placeholder="Contoh: Kunjungan Cabang Surabaya dan Audit" required>{{ old('description') }}</textarea>
</div>
<div class="section-divider"></div>
<div>
    @include('partials.transaction-funding', ['fundingType' => 'perjalanan_dinas'])
    <div id="bs-warning-info" class="alert alert-warning mt-3 d-none">Total rincian biaya melebihi saldo BS gabungan yang tersedia.</div>
</div>
</div>
</div>
<div class="card-modern animate-slide-in" id="card-info-plafon" style="display:none;">
<div class="card-header-modern info">
<h5><i class="bi bi-bar-chart-line"></i> Informasi Plafon Perjalanan Dinas</h5>
<span class="badge bg-info bg-opacity-10 text-info">Real-time</span>
</div>
<div class="card-body p-4">
<div class="row g-3 text-center">
<div class="col-md-4">
<div class="stat-box">
<small class="d-block">Plafon Total</small>
<span id="info-plafon-total" class="value">Rp 0</span>
</div>
</div>
<div class="col-md-4">
<div class="stat-box">
<small class="d-block">Total Input</small>
<span id="info-total-input" class="value">Rp 0</span>
</div>
</div>
<div class="col-md-4">
<div class="stat-box">
<small class="d-block">Sisa Anggaran</small>
<span id="info-sisa-anggaran" class="value">Rp 0</span>
</div>
</div>
</div>
<div id="plafon-status-message" class="mt-3 text-center"></div>
</div>
</div>
<div class="card-modern animate-slide-in" style="animation-delay: 0.1s">
<div class="card-header-modern success">
<h5><i class="bi bi-receipt-cutoff"></i> Rincian Biaya (Detail)</h5>
<div class="d-flex align-items-center gap-3 flex-wrap">
<div class="total-badge mb-0">
<small class="text-muted d-block">Total Rincian</small>
<span id="total-rincian" class="amount text-success">Rp 0</span>
</div>
<button type="button" class="btn btn-success-modern btn-sm" id="btn-tambah-baris">
<i class="bi bi-plus-lg"></i> Tambah Baris
</button>
</div>
</div>
<div class="card-body p-0">
<div class="table-responsive">
<table class="table-modern" id="tabel-detail" data-mobile-entry>
<thead>
<tr>
<th width="30%"><i class="bi bi-tag me-2"></i>Cost Category <span class="text-danger">*</span></th>
<th width="40%"><i class="bi bi-chat-left-text me-2"></i>Remark (Keterangan)</th>
<th width="20%"><i class="bi bi-currency-dollar me-2"></i>Nominal (Rp) <span class="text-danger">*</span></th>
<th width="10%" class="text-center">Aksi</th>
</tr>
</thead>
<tbody>
@php
$oldDetails = array_values(old('details', [[]]));
@endphp
@foreach($oldDetails as $idx => $oldDetail)
<tr id="baris-{{ $idx }}" class="animate-slide-in">
<td>
<select name="details[{{ $idx }}][cost_category_id]" class="form-select cost-category-select" required>
<option value="">-- Pilih Cost Category --</option>
@foreach($cost_categories as $cc)
@php
$categoryName = strtolower($cc->name ?? $cc->description ?? $cc->code ?? '');
$type = 'umum';
if (str_contains($categoryName, 'lumpsum') || str_contains($categoryName, 'uang saku')) $type = 'lumpsum';
elseif (str_contains($categoryName, 'hotel') || str_contains($categoryName, 'akomodasi') || str_contains($categoryName, 'menginap')) $type = 'hotel';
$oldCatId = $oldDetail['cost_category_id'] ?? '';
@endphp
<option value="{{ $cc->id }}" data-type="{{ $type }}" {{ $oldCatId == $cc->id ? 'selected' : '' }}>
{{ $cc->name ?? $cc->description ?? $cc->code }}
</option>
@endforeach
</select>
</td>
<td>
<input type="text" name="details[{{ $idx }}][remark]" class="form-control" placeholder="Opsional (Misal: Tiket Kereta)" value="{{ $oldDetail['remark'] ?? '' }}">
</td>
<td>
@php $oldNominal = $oldDetail['nominal'] ?? ''; @endphp
<input type="text" class="form-control nominal-input nominal-formatted" placeholder="0" inputmode="decimal" autocomplete="off" value="{{ $oldNominal !== '' ? number_format((int)$oldNominal, 0, ',', '.') : '' }}">
<input type="hidden" name="details[{{ $idx }}][nominal]" class="nominal-real" value="{{ $oldNominal }}">
<div id="cost-info-{{ $idx }}" class="mt-1 small"></div>
</td>
<td class="text-center align-middle">
<button type="button" class="btn btn-danger-modern btn-icon btn-sm btn-hapus" data-id="{{ $idx }}"><i class="bi bi-trash"></i></button>
</td>
</tr>
@endforeach
</tbody>
</table>
</div>
</div>
</div>
<div id="plafon-over-warning" class="alert alert-warning d-none mb-4 p-4">
<h6 class="fw-bold"><i class="bi bi-exclamation-triangle-fill me-2"></i>Peringatan Plafon</h6>
<p class="mb-0" id="plafon-over-message"></p>
</div>
<p class="text-muted small">Draft dapat diedit. Konfirmasi mengunci transaksi untuk diperiksa Finance. Saldo BS baru berkurang sesuai nominal yang dikonfirmasi Finance.</p>
<div class="d-grid d-sm-flex gap-2 animate-slide-in" style="animation-delay: 0.2s">
<button type="submit" name="save_action" value="draft" class="btn btn-outline-secondary btn-lg py-3 flex-fill">
<i class="bi bi-save me-2 fs-5"></i> Simpan Draft
</button>
<button type="submit" name="save_action" value="confirm" class="btn btn-primary-modern btn-lg py-3 flex-fill">
<i class="bi bi-check-circle me-2 fs-5"></i> <span data-bs-confirm-label>Simpan &amp; Konfirmasi</span>
</button>
</div>
</form>
</div>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/id.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
let plafonTotal = 0;
let checkPlafonTimeout = null;
let rowIndex = {{ count($oldDetails) }}; // 🎯 Mulai index dari jumlah old details

// 🎯 FORMAT RUPIAH HELPER
function formatRupiah(angka) { return 'Rp ' + new Intl.NumberFormat('id-ID').format(angka); }
function formatRupiahInput(angka) {
if (angka === 0 || angka === '' || angka === null || isNaN(angka)) return '';
return new Intl.NumberFormat('id-ID').format(angka);
}
function unformatRupiah(str) {
if (!str) return 0;
return parseInt(String(str).replace(/\./g, '').replace(/[^0-9]/g, '')) || 0;
}

// 🎯 HITUNG TOTAL - baca dari hidden input .nominal-real
function hitungTotal() {
let total = 0;
$('.nominal-real').each(function() { total += parseFloat($(this).val()) || 0; });
$('#total-rincian').html(formatRupiah(total));
$('#info-total-input').html(formatRupiah(total));
if (plafonTotal > 0) {
const sisa = plafonTotal - total;
$('#info-sisa-anggaran').html(formatRupiah(sisa));
if (sisa < 0) {
$('#info-sisa-anggaran').removeClass('text-info text-success').addClass('text-danger');
$('#plafon-over-warning').removeClass('d-none');
$('#plafon-over-message').html(`Total rincian <strong>${formatRupiah(total)}</strong> melebihi plafon <strong>${formatRupiah(plafonTotal)}</strong>. Selisih: <strong>${formatRupiah(Math.abs(sisa))}</strong>. Transaksi tetap dapat disimpan (Soft Control), namun atasan akan dinotifikasi.`);
} else {
$('#info-sisa-anggaran').removeClass('text-danger').addClass('text-info');
$('#plafon-over-warning').addClass('d-none');
}
}
const sisa = getSisaSaldoBs();
if (sisa !== null && total > sisa) {
$('#bs-warning-info').removeClass('d-none');
$('#total-rincian').removeClass('text-success').addClass('text-danger');
} else {
$('#bs-warning-info').addClass('d-none');
$('#total-rincian').removeClass('text-danger').addClass('text-success');
}
return total;
}
function cekPlafonRealtime() {
const tujuanDinasId = $('#tujuan_dinas_id').val();
const totalNominal = hitungTotal();
const tanggal = $('#tanggal_picker').val() || '{{ \App\Support\AppTime::now()->toDateString() }}';
if (!tujuanDinasId) return;
$.ajax({
url: '{{ route("api.check_plafon_realtime") }}', type: 'POST',
data: { _token: '{{ csrf_token() }}', tujuan_dinas_id: tujuanDinasId, total_nominal: totalNominal, tanggal: tanggal },
success: function(response) {
if (response.plafon_value) {
plafonTotal = response.plafon_value;
$('#info-plafon-total').html(formatRupiah(plafonTotal));
$('#info-sisa-anggaran').html(formatRupiah(plafonTotal - totalNominal));
if (response.is_over) {
$('#plafon-status-message').html(`<span class="badge bg-danger fs-6">⚠️ OVER PLAFON - Selisih: ${formatRupiah(response.selisih)}</span>`);
} else {
$('#plafon-status-message').html(`<span class="badge bg-success fs-6">✅ Dalam Plafon - Sisa: ${formatRupiah(response.sisa || 0)}</span>`);
}
} else {
$('#plafon-status-message').html(`<span class="badge bg-warning text-dark fs-6">${response.message}</span>`);
}
}
});
}
function debounceCekPlafon() { clearTimeout(checkPlafonTimeout); checkPlafonTimeout = setTimeout(cekPlafonRealtime, 500); }
function ambilInfoPlafon() {
const tujuanDinasId = $('#tujuan_dinas_id').val();
const tanggal = $('#tanggal_picker').val() || '{{ \App\Support\AppTime::now()->toDateString() }}';
if (!tujuanDinasId) { $('#card-info-plafon').slideUp(); return; }
$.ajax({
url: '{{ route("api.get_plafon_info") }}', type: 'POST',
data: { _token: '{{ csrf_token() }}', tujuan_dinas_id: tujuanDinasId, tanggal: tanggal },
success: function(response) {
if (response.found) {
plafonTotal = response.plafon_value;
$('#info-plafon-total').html(formatRupiah(plafonTotal));
$('#card-info-plafon').slideDown();
hitungTotal();
} else {
plafonTotal = 0;
$('#card-info-plafon').slideUp();
}
}
});
}
function getSisaSaldoBs() {
    const value = document.getElementById('bs-saldo-info')?.dataset.balance;
    return value === undefined || value === '' ? null : Number(value);
}
document.addEventListener('bs-balance-updated', hitungTotal);
$('#teritory-select').on('change', function() {
var teritory = $(this).val();
var provinsiSelect = $('#provinsi-select');
var kotaSelect = $('#kota-select');
provinsiSelect.prop('disabled', true).html('<option value="">-- Loading Provinsi... --</option>');
kotaSelect.prop('disabled', true).html('<option value="">-- Pilih Provinsi Terlebih Dahulu --</option>');
resetTujuanDinas();
if (teritory) {
$.ajax({
url: '{{ route("api.wilayah.provinsi") }}', type: 'GET', data: { teritory: teritory }, dataType: 'json',
success: function(response) {
provinsiSelect.prop('disabled', false).html('<option value="">-- Pilih Provinsi --</option>');
if (response.length > 0) { $.each(response, function(key, value) { provinsiSelect.append('<option value="' + value.id + '">' + value.nama + '</option>'); }); }
}
});
}
});
$('#provinsi-select').on('change', function() {
var provinsiId = $(this).val();
var kotaSelect = $('#kota-select');
kotaSelect.prop('disabled', true).html('<option value="">-- Loading Kota/Kabupaten... --</option>');
resetTujuanDinas();
if (provinsiId) {
$.ajax({
url: '{{ route("api.wilayah.kota") }}', type: 'GET', data: { provinsi_id: provinsiId }, dataType: 'json',
success: function(response) {
kotaSelect.prop('disabled', false).html('<option value="">-- Pilih Kota/Kabupaten --</option>');
if (response.length > 0) { $.each(response, function(key, value) { kotaSelect.append('<option value="' + value.id + '">' + value.nama + '</option>'); }); }
}
});
}
});
$('#kota-select').on('change', function() {
var kotaId = $(this).val();
var provinsiText = $('#provinsi-select option:selected').text();
var kotaText = $(this).val() ? $(this).find('option:selected').text() : '';
if (kotaId) {
$('#tujuan_dinas_id').val(kotaId);
$('#preview-text').html('<strong>' + kotaText + '</strong>, ' + provinsiText);
$('#preview-tujuan').removeClass('alert-warning alert-info').addClass('alert-success');
ambilInfoPlafon();
} else { resetTujuanDinas(); }
});
function resetTujuanDinas() {
$('#tujuan_dinas_id').val('');
$('#preview-text').text('Belum ada wilayah yang dipilih.');
$('#preview-tujuan').removeClass('alert-info alert-success').addClass('alert-warning');
$('#card-info-plafon').slideUp();
plafonTotal = 0;
}
@if(old('teritory'))
$('#teritory-select').trigger('change');
setTimeout(function() {
@if(old('provinsi_id'))
$('#provinsi-select').val('{{ old("provinsi_id") }}').trigger('change');
setTimeout(function() {
@if(old('tujuan_dinas_id'))
$('#kota-select').val('{{ old("tujuan_dinas_id") }}').trigger('change');
@endif
}, 500);
@endif
}, 500);
@endif
function updateCostCategoryVisibility() {
const jarakKm = parseFloat($('#jarak_km').val()) || 0;
const durasiJam = parseFloat($('#durasi_jam').val()) || 0;
const canLumpsum = jarakKm > 200;
const canHotel = durasiJam > 8;
$('#lumpsum-info').html(canLumpsum ? '<span class="text-success fw-bold">✅ Dapat Lumpsum (Jarak > 200 KM)</span>' : '<span class="text-danger fw-bold">❌ Tidak Dapat Lumpsum (Jarak ≤ 200 KM)</span>');
$('#hotel-info').html(canHotel ? '<span class="text-success fw-bold">✅ Dapat Hotel (Durasi > 8 Jam)</span>' : '<span class="text-danger fw-bold">❌ Tidak Dapat Hotel (Durasi ≤ 8 Jam)</span>');
$('.cost-category-select').each(function() {
const $select = $(this);
const currentVal = $select.val();
$select.find('option[data-type="lumpsum"]').each(function() {
if (canLumpsum) { $(this).prop('disabled', false).show(); }
else { $(this).prop('disabled', true).hide(); if ($(this).val() === currentVal) $select.val('').trigger('change'); }
});
$select.find('option[data-type="hotel"]').each(function() {
if (canHotel) { $(this).prop('disabled', false).show(); }
else { $(this).prop('disabled', true).hide(); if ($(this).val() === currentVal) $select.val('').trigger('change'); }
});
$select.find('option[data-type="umum"]').prop('disabled', false).show();
});
}
$('#jarak_km, #durasi_jam').on('input change', function() { updateCostCategoryVisibility(); });

const costCategoryOptions = `
<option value="">-- Pilih Cost Category --</option>
@foreach($cost_categories as $cc)
@php
$categoryName = strtolower($cc->name ?? $cc->description ?? $cc->code ?? '');
$type = 'umum';
if (str_contains($categoryName, 'lumpsum') || str_contains($categoryName, 'uang saku')) $type = 'lumpsum';
elseif (str_contains($categoryName, 'hotel') || str_contains($categoryName, 'akomodasi') || str_contains($categoryName, 'menginap')) $type = 'hotel';
@endphp
<option value="{{ $cc->id }}" data-type="{{ $type }}">{{ $cc->name ?? $cc->description ?? $cc->code }}</option>
@endforeach
`;

// 🎯 TAMBAH BARIS BARU - dengan input nominal terformat
$('#btn-tambah-baris').click(function() {
let barisBaru = `
<tr id="baris-${rowIndex}" class="animate-slide-in">
<td><select name="details[${rowIndex}][cost_category_id]" class="form-select cost-category-select" required>${costCategoryOptions}</select></td>
<td><input type="text" name="details[${rowIndex}][remark]" class="form-control" placeholder="Opsional"></td>
<td>
<input type="text" class="form-control nominal-input nominal-formatted" placeholder="0" inputmode="decimal" autocomplete="off">
<input type="hidden" name="details[${rowIndex}][nominal]" class="nominal-real" value="0">
<div id="cost-info-${rowIndex}" class="mt-1 small"></div>
</td>
<td class="text-center align-middle"><button type="button" class="btn btn-danger-modern btn-icon btn-sm btn-hapus" data-id="${rowIndex}"><i class="bi bi-trash"></i></button></td>
</tr>`;
$('#tabel-detail tbody').append(barisBaru);
updateCostCategoryVisibility();
rowIndex++;
});

// 🎯 HAPUS BARIS - bekerja untuk SEMUA baris (termasuk baris awal)
$(document).on('click', '.btn-hapus', function() {
let idBaris = $(this).data('id');
$('#baris-' + idBaris).fadeOut(300, function() {
$(this).remove();
hitungTotal();
debounceCekPlafon();
// Cek jika tidak ada baris sama sekali
if ($('#tabel-detail tbody tr').length === 0) {
// Tambahkan baris kosong baru otomatis
$('#btn-tambah-baris').click();
}
});
});

// 🎯 FORMAT INPUT NOMINAL - event listener untuk semua input nominal (existing + baru)
$(document).on('input', '.nominal-formatted', function() {
let $input = $(this);
let raw = $input.val().replace(/\./g, '').replace(/[^0-9]/g, '');
let num = parseInt(raw) || 0;
$input.val(formatRupiahInput(num));
$input.closest('td').find('.nominal-real').val(num);
hitungTotal();
debounceCekPlafon();
});

// Saat blur, pastikan format konsisten
$(document).on('blur', '.nominal-formatted', function() {
let $input = $(this);
let raw = $input.val().replace(/\./g, '').replace(/[^0-9]/g, '');
let num = parseInt(raw) || 0;
$input.val(formatRupiahInput(num));
$input.closest('td').find('.nominal-real').val(num);
});

const tglInput  = document.getElementById('tanggal_picker');
const warning   = document.getElementById('periodWarning');
const submitButtons = document.querySelectorAll('#form-perjalanan-dinas button[name="save_action"]');
const openPeriods = @json($openPeriods);
const usedDates = new Set(@json($usedDates));
const today = @json(\App\Support\AppTime::now()->toDateString());
let periodValidation = 0;

function formatLocalDate(date) {
const y = date.getFullYear();
const m = String(date.getMonth() + 1).padStart(2, '0');
const d = String(date.getDate()).padStart(2, '0');
return `${y}-${m}-${d}`;
}

function getDateWarning(dateStr) {
if (!dateStr) return 'Pilih tanggal transaksi yang belum digunakan.';
if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return 'Pilih tanggal transaksi yang valid.';
if (usedDates.has(dateStr)) {
return 'Anda sudah memiliki transaksi Perjalanan Dinas pada tanggal ini. Pilih tanggal lain atau tambahkan rincian biaya pada transaksi yang sudah ada.';
}
if (dateStr > today) return 'Tanggal transaksi tidak boleh di masa depan.';
const periode = dateStr.slice(0, 7);
if (!openPeriods.includes(periode)) {
return `Periode ${periode} tidak aktif atau sudah DITUTUP. Pilih tanggal di bulan yang berjalan/OPEN.`;
}
return '';
}

function showDateWarning(message) {
document.getElementById('periodWarningText').textContent = message;
warning.classList.toggle('d-none', !message);
submitButtons.forEach(button => button.disabled = Boolean(message));
}

if (tglInput && typeof flatpickr !== 'undefined') {
flatpickr(tglInput, {
dateFormat: "Y-m-d", altInput: true, altFormat: "d F Y", locale: "id", maxDate: today,
defaultDate: tglInput.value || null,
disableMobile: true,
disable: [function(date) {
const dateStr = formatLocalDate(date);
return usedDates.has(dateStr) || !openPeriods.includes(dateStr.slice(0, 7));
}]
});
}
async function validatePeriod(dateStr) {
const currentValidation = ++periodValidation;
const dateWarning = getDateWarning(dateStr);
showDateWarning(dateWarning);
if (dateWarning) return;
const periode = dateStr.slice(0, 7);
try {
const response = await fetch(`/api/periode/status?periode=${periode}`);
if (!response.ok) throw new Error('Status periode tidak dapat dimuat');
const data = await response.json();
if (currentValidation !== periodValidation || dateStr !== tglInput.value) return;
if (!data.open) {
showDateWarning(`Periode ${periode} sudah DITUTUP. Pilih tanggal di periode OPEN.`);
} else {
showDateWarning('');
}
} catch (err) {
if (currentValidation !== periodValidation || dateStr !== tglInput.value) return;
console.warn('Gagal cek status periode:', err);
showDateWarning(getDateWarning(dateStr));
}
}
if (tglInput) {
tglInput.addEventListener('change', () => {
validatePeriod(tglInput.value);
if (!getDateWarning(tglInput.value) && $('#tujuan_dinas_id').val()) { ambilInfoPlafon(); }
});
validatePeriod(tglInput.value);
}
$('#form-perjalanan-dinas').on('submit', function(e) {
const dateWarning = getDateWarning(tglInput.value);
if (dateWarning) {
e.preventDefault();
showDateWarning(dateWarning);
return false;
}
if (!$('#tujuan_dinas_id').val()) {
e.preventDefault();
alert('⚠️ Silakan pilih Kota/Kabupaten tujuan terlebih dahulu!');
$('#kota-select').focus();
return false;
}
// 🎯 Validasi: minimal 1 baris dengan nominal > 0
let validDetails = 0;
$('.nominal-real').each(function() {
if (parseFloat($(this).val()) > 0) validDetails++;
});
if (validDetails === 0) {
e.preventDefault();
alert('⚠️ Minimal 1 rincian biaya dengan nominal harus diisi!');
return false;
}
const sisa = getSisaSaldoBs();
const total = hitungTotal();
// Saldo diperiksa di server saat Konfirmasi.

});
updateCostCategoryVisibility();
$('#jarak_km').trigger('input');
$('#durasi_jam').trigger('input');
hitungTotal();
});
</script>
</body>
</html>

~~~~

## resources/views/transaksi_perjalanan_dinas/show.blade.php

Tabel rincian tersimpan dan form edit; tempat menampilkan foto dan menambahkan multipart pada form edit.

~~~~php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Detail Perjalanan Dinas - {{ $transaksi->transaksi_id }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary-color: #64748b;
            --success-color: #059669;
            --danger-color: #dc2626;
            --warning-color: #d97706;
            --bg-color: #f1f5f9;
            --card-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
        }

        body { font-family: 'Inter', sans-serif; background-color: var(--bg-color); color: var(--text-primary); }
        .page-header { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; padding: 2rem 0; margin-bottom: 2rem; }
        .page-header h1 { font-weight: 600; margin: 0; font-size: 1.75rem; }
        
        .btn-modern { border-radius: 6px; padding: 0.5rem 1rem; font-weight: 500; border: none; display: inline-flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; text-decoration: none; transition: all 0.2s; cursor: pointer; }
        .btn-ghost { background: rgba(255, 255, 255, 0.2); color: white; border: 1px solid rgba(255, 255, 255, 0.3); }
        .btn-ghost:hover { background: rgba(255, 255, 255, 0.3); color: white; }
        
        .card-modern { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 8px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); margin-bottom: 1.5rem; }
        .card-header-modern { background: #f8fafc; border-bottom: 1px solid var(--border-color); padding: 1.25rem 1.5rem; display: flex; align-items: center; justify-content: space-between; }
        .card-header-modern h5 { margin: 0; font-weight: 600; color: var(--text-primary); font-size: 1rem; }

        .detail-label { font-size: 0.75rem; font-weight: 600; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem; }
        .detail-value { font-size: 0.95rem; font-weight: 500; color: var(--text-primary); }
        
        .form-control, .form-select { border: 1px solid var(--border-color); border-radius: 6px; padding: 0.625rem 0.75rem; font-size: 0.875rem; }
        .form-control:focus, .form-select:focus { border-color: var(--primary-color); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }

        .badge-soft-success { background: #d1fae5; color: var(--success-color); padding: 0.35rem 0.75rem; border-radius: 6px; font-weight: 600; font-size: 0.8rem; }
        .badge-soft-danger { background: #fee2e2; color: var(--danger-color); padding: 0.35rem 0.75rem; border-radius: 6px; font-weight: 600; font-size: 0.8rem; }
        .badge-soft-info { background: #dbeafe; color: var(--primary-color); padding: 0.35rem 0.75rem; border-radius: 6px; font-weight: 600; font-size: 0.8rem; }
        .badge-soft-warning { background: #fef3c7; color: var(--warning-color); padding: 0.35rem 0.75rem; border-radius: 6px; font-weight: 600; font-size: 0.8rem; }

        .stat-box { background: #f8fafc; border: 1px solid var(--border-color); border-radius: 6px; padding: 1rem; text-align: center; }
        .stat-box small { color: var(--text-secondary); font-weight: 500; font-size: 0.75rem; text-transform: uppercase; }
        .stat-box .value { font-size: 1.125rem; font-weight: 600; margin-top: 0.25rem; display: block; }

        .table-modern { width: 100%; border-collapse: collapse; }
        .table-modern th { background: #f8fafc; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-secondary); padding: 0.75rem 1rem; border-bottom: 1px solid var(--border-color); }
        .table-modern td { padding: 0.875rem 1rem; border-bottom: 1px solid var(--border-color); font-size: 0.875rem; vertical-align: middle; }
        .table-modern tbody tr:hover { background: #f8fafc; }
        .table-modern tfoot td { background: #f8fafc; font-weight: 700; font-size: 0.95rem; }

        .btn-action-sm { border: none; border-radius: 5px; padding: 0.3rem 0.6rem; font-size: 0.75rem; font-weight: 600; display: inline-flex; align-items: center; gap: 0.25rem; cursor: pointer; }

        .to-delete { text-decoration: line-through; opacity: 0.5; background: #fee2e2 !important; }
        .to-delete td { color: var(--danger-color); }

        /* 🎯 Format Nominal Rupiah */
        .nominal-formatted { text-align: right; font-weight: 600; font-variant-numeric: tabular-nums; }
    </style>
    @include('partials.mobile-assets')
</head>
<body>
    @include('partials.application-time')
    <div class="page-header">
        <div class="container" style="max-width: 1000px;">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1><i class="bi bi-airplane me-2"></i>Detail Perjalanan Dinas</h1>
                    <p class="mb-0">ID: <strong>{{ $transaksi->transaksi_id }}</strong></p>
                </div>
                <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                    <a href="{{ route('transaksi_perjalanan_dinas.index') }}" class="btn btn-ghost btn-modern">
                        <i class="bi bi-arrow-left"></i> Kembali ke Daftar
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container" style="max-width: 1000px; margin-bottom: 3rem;">
        @include('partials.finance-correction-notice', ['financeSourceType' => 'PD'])
        @if(session('success'))
            <div class="alert alert-success mb-4" style="border-radius: 6px; border: none;">
                <i class="bi bi-check-circle me-2"></i> {{ session('success') }}
            </div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger mb-4" style="border-radius: 6px; border: none;">
                <strong>Gagal:</strong>
                <ul class="mb-0 mt-1">
                    @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
                </ul>
            </div>
        @endif

        <!-- ========================================== -->
        <!-- 🎯 MODE 1: TAMPILAN DETAIL (Default)       -->
        <!-- ========================================== -->
        @php
            $canEdit = $transaksi->status === 'DRAFT'
                && app(\App\Services\PeriodService::class)->isOpen($transaksi->periode)
                && auth()->user()->canAccessTransaction($transaksi);
            $isEditMode = $canEdit && (request('edit') == 1 || old('_transaction_edit') === $transaksi->transaksi_id);
        @endphp
        @if(!$isEditMode)
        @include('partials.travel-confirmation')
        @include('partials.bs-finance-check-status', ['transaction' => $transaksi, 'jenis' => 'PD'])
        @include('bs-usage-approvals.actions')
        @include('bs-usage-approvals.history')
        <div id="view-mode">
            <div class="card-modern">
                <div class="card-header-modern">
                    <h5><i class="bi bi-info-circle me-2"></i>Informasi Transaksi</h5>
                    @if($canEdit)
                    <a href="{{ route('transaksi_perjalanan_dinas.show', $transaksi->transaksi_id) }}?edit=1" class="btn btn-warning">
                        <i class="bi bi-pencil-square"></i> Edit Transaksi
                    </a>
                    @endif
                </div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="detail-label">Tanggal Dinas</div>
                            <div class="detail-value"><i class="bi bi-calendar3 me-2 text-muted"></i>{{ \Carbon\Carbon::parse($transaksi->tanggal)->format('d F Y') }}</div>
                        </div>
                        <div class="col-md-4">
                            <div class="detail-label">User (Karyawan)</div>
                            <div class="detail-value"><i class="bi bi-person me-2 text-muted"></i>{{ $transaksi->user->nama ?? $transaksi->user->name ?? '-' }}</div>
                        </div>
                        <div class="col-md-4">
                            <div class="detail-label">Pemilik Saldo BS</div>
                            <div class="detail-value">
                                @if($transaksi->bsCashOwnerId())
                                    <span class="badge-soft-info">{{ $transaksi->bsOwner?->nama ?? $transaksi->bonSementara?->user?->nama ?? '-' }}</span>
                                @else
                                    <span class="text-muted">Arsip tanpa BS</span>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Tujuan Dinas</div>
                            <div class="detail-value">
                                <i class="bi bi-geo-alt me-2 text-muted"></i>
                                {{ $transaksi->tujuanDinas->nama ?? '-' }}
                                @if($transaksi->tujuanDinas && $transaksi->tujuanDinas->parent)
                                    , {{ $transaksi->tujuanDinas->parent->nama }}
                                @endif
                                @if($transaksi->tujuanDinas)
                                    <span class="badge-soft-info ms-2">{{ $transaksi->tujuanDinas->teritory }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="detail-label">Jarak</div>
                            <div class="detail-value"><i class="bi bi-signpost-split me-2 text-muted"></i>{{ $transaksi->jarak_km }} KM</div>
                        </div>
                        <div class="col-md-3">
                            <div class="detail-label">Durasi</div>
                            <div class="detail-value"><i class="bi bi-clock me-2 text-muted"></i>{{ $transaksi->durasi_jam }} Jam</div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Total Pengeluaran</div>
                            <div class="detail-value" style="font-size: 1.5rem; font-weight: 700; color: var(--primary-color);">
                                Rp {{ number_format($transaksi->details->sum('nominal'), 0, ',', '.') }}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Status Plafon</div>
                            <div class="detail-value">
                                @if($transaksi->is_over_plafon)
                                    <span class="badge-soft-danger">⚠️ OVER PLAFON (Selisih: Rp {{ number_format($transaksi->selisih_plafon, 0, ',', '.') }})</span>
                                @elseif($transaksi->plafon_value)
                                    <span class="badge-soft-success">✓ Dalam Plafon (Sisa: Rp {{ number_format($transaksi->plafon_value - $transaksi->details->sum('nominal'), 0, ',', '.') }})</span>
                                @else
                                    <span class="badge-soft-info">- Tidak ada data plafon</span>
                                @endif
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="detail-label">Deskripsi Kegiatan</div>
                            <div class="detail-value p-3" style="background: #f8fafc; border-radius: 6px; border: 1px solid var(--border-color);">
                                {{ $transaksi->description }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card Rincian Biaya -->
            <div class="card-modern">
                <div class="card-header-modern">
                    <h5><i class="bi bi-list-ul me-2"></i>Rincian Biaya ({{ $transaksi->details->count() }} Item)</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table-modern">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th style="width: 30%;">Kategori Biaya</th>
                                    <th style="width: 35%;">Keterangan</th>
                                    <th style="width: 20%;" class="text-end">Nominal</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $total = 0; @endphp
                                @forelse($transaksi->details as $i => $d)
                                    @php $total += $d->nominal; @endphp
                                    <tr>
                                        <td>{{ $i + 1 }}</td>
                                        <td>{{ $d->costCategory->name ?? $d->costCategory->description ?? '-' }}</td>
                                        <td>{{ $d->remark ?? '-' }}</td>
                                        <td class="text-end fw-bold">Rp {{ number_format($d->nominal, 0, ',', '.') }}</td>
                                    </tr>
                                @empty
                                    <tr><td colspan="4" class="text-center text-muted py-4">Belum ada rincian biaya.</td></tr>
                                @endforelse
                            </tbody>
                            @if($total > 0)
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end">TOTAL</td>
                                    <td class="text-end" style="color: var(--primary-color);">Rp {{ number_format($total, 0, ',', '.') }}</td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                </div>
            </div>

        </div>
        @else
        <div id="edit-mode">
            <form action="{{ route('transaksi_perjalanan_dinas.update', $transaksi->transaksi_id) }}" method="POST" id="form-edit-pd" data-transaction-editor="travel" data-provinces-url="{{ route('api.wilayah.provinsi') }}" data-cities-url="{{ route('api.wilayah.kota') }}">
                @csrf
                @method('PUT')
                <input type="hidden" name="_transaction_edit" value="{{ $transaksi->transaksi_id }}">

                <div class="card-modern">
                    <div class="card-header-modern" style="background: #fffbeb; border-bottom-color: #fcd34d;">
                        <h5 style="color: var(--warning-color);"><i class="bi bi-pencil-square me-2"></i>Mode Edit Data</h5>
                        <a href="{{ route('transaksi_perjalanan_dinas.show', $transaksi->transaksi_id) }}" class="btn btn-outline-secondary">Batal</a>
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-4">
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">ID Transaksi</label>
                                <input type="text" class="form-control" value="{{ $transaksi->transaksi_id }}" disabled>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Tanggal Dinas <span class="text-danger">*</span></label>
                                <input type="date" name="tanggal" class="form-control" value="{{ old('tanggal', \Carbon\Carbon::parse($transaksi->tanggal)->format('Y-m-d')) }}" required>
                            </div>
                            <div class="col-md-4">
                                @include('partials.transaction-funding', ['fundingType' => 'perjalanan_dinas', 'fundingDocument' => $transaksi])
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Jarak (KM) <span class="text-danger">*</span></label>
                                <input type="number" name="jarak_km" id="edit-jarak" class="form-control" value="{{ old('jarak_km', $transaksi->jarak_km) }}" min="0" max="99999999.99" step="0.01" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Durasi (Jam) <span class="text-danger">*</span></label>
                                <input type="number" name="durasi_jam" id="edit-durasi" class="form-control" value="{{ old('durasi_jam', $transaksi->durasi_jam) }}" min="0" max="24" step="0.01" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Territory <span class="text-danger">*</span></label>
                                <select name="teritory" id="edit-teritory" class="form-select" required>
                                    <option value="Jawa" {{ $currentTerritory == 'Jawa' ? 'selected' : '' }}>Jawa</option>
                                    <option value="Luar Jawa" {{ $currentTerritory == 'Luar Jawa' ? 'selected' : '' }}>Luar Jawa</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Provinsi <span class="text-danger">*</span></label>
                                <select name="provinsi_id" id="edit-provinsi" class="form-select" required>
                                    <option value="">-- Pilih Provinsi --</option>
                                    @foreach($provinces as $p)
                                        <option value="{{ $p->id }}" {{ $currentProvinceId == $p->id ? 'selected' : '' }}>{{ $p->nama }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Kota/Kabupaten <span class="text-danger">*</span></label>
                                <select name="tujuan_dinas_id" id="edit-kota" class="form-select" required>
                                    <option value="">-- Pilih Kota --</option>
                                    @foreach($cities as $c)
                                        <option value="{{ $c->id }}" {{ old('tujuan_dinas_id', $transaksi->tujuan_dinas_id) == $c->id ? 'selected' : '' }}>{{ $c->nama }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Deskripsi Kegiatan <span class="text-danger">*</span></label>
                                <textarea name="description" class="form-control" rows="3" maxlength="255" required>{{ old('description', $transaksi->description) }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>

                @include('partials.transaction-edit-details', ['requireRemark' => false, 'cancelUrl' => route('transaksi_perjalanan_dinas.show', $transaksi->transaksi_id)])
            </form>
        </div>
        @endif
    </div>

    <script src="{{ asset('js/transaction-editor.js') }}?v={{ filemtime(public_path('js/transaction-editor.js')) }}" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

~~~~

## app/Http/Controllers/TransaksiPerjalananDinasController.php

Validasi dan penyimpanan melalui store, update, storeDetail; penghapusan melalui destroy dan destroyDetail.

~~~~php
<?php

namespace App\Http\Controllers;

use App\Services\DocumentNumberService;

use Illuminate\Http\Request;
use App\Models\TransaksiPerjalananDinasHeader;
use App\Models\TransaksiPerjalananDinasDetail;
use App\Models\User;
use App\Models\SettingPlafonPerjalananDinas;
use App\Models\CostCategory;
use App\Models\WilayahDistance;
use App\Models\Periode;
use App\Services\BonSementaraService;
use App\Services\PlafonService;
use App\Notifications\TransaksiOverPlafon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class TransaksiPerjalananDinasController extends Controller
{
    public function create()
    {
        $cost_categories = CostCategory::all();
        $dbPeriods = Periode::pluck('status', 'periode')->toArray();
        $currentMonth = \App\Support\AppTime::now()->format('Y-m');

        $openPeriods = [];
        foreach ($dbPeriods as $periode => $status) {
            if ($status === 'OPEN') {
                $openPeriods[] = $periode;
            }
        }

        if (!isset($dbPeriods[$currentMonth])) {
            $openPeriods[] = $currentMonth;
        }

        $usedDates = TransaksiPerjalananDinasHeader::where('user_id', Auth::id())
            ->distinct()
            ->orderBy('tanggal')
            ->pluck('tanggal')
            ->all();

        return view('transaksi_perjalanan_dinas.create', compact('cost_categories', 'openPeriods', 'usedDates'));
    }

    public function getProvinsiByTeritory(Request $request)
    {
        $teritory = $request->get('teritory');
        $provinsis = \App\Models\Wilayah::where('teritory', $teritory)
            ->whereNull('parent_id')
            ->select('id', 'nama')
            ->orderBy('nama', 'asc')
            ->get();
        return response()->json($provinsis);
    }

    public function getKotaByProvinsi(Request $request)
    {
        $provinsiId = $request->get('provinsi_id');
        $kotas = \App\Models\Wilayah::where('parent_id', $provinsiId)
            ->select('id', 'nama')
            ->orderBy('nama', 'asc')
            ->get();
        return response()->json($kotas);
    }

    public function checkPlafonRealtime(Request $request, PlafonService $plafonService)
    {
        $request->validate([
            'tujuan_dinas_id' => 'required|exists:wilayah,id',
            'total_nominal'    => 'required|numeric|decimal:0,2|min:0|max:9999999999999.99',
        ]);

        $user = Auth::user();
        $tujuanDinasId = $request->tujuan_dinas_id;
        $totalNominal = (float) $request->total_nominal;
        $tanggal = $request->tanggal ?? \App\Support\AppTime::now()->format('Y-m-d');

        $cek = $plafonService->checkPerjalananDinas($user, $tujuanDinasId, $tanggal, $totalNominal);
        return response()->json($cek);
    }

    public function getPlafonInfo(Request $request, PlafonService $plafonService)
    {
        $request->validate(['tujuan_dinas_id' => 'required|exists:wilayah,id']);

        $user = Auth::user();
        $tujuanDinasId = $request->tujuan_dinas_id;
        $tanggal = $request->tanggal ?? \App\Support\AppTime::now()->format('Y-m-d');

        $plafon = $plafonService->getPlafonPerjalananDinas($user, $tujuanDinasId, $tanggal);

        if ($plafon) {
            return response()->json([
                'found'         => true,
                'plafon_value'  => (float) $plafon->default_value,
                'description'   => $plafon->description,
                'tanggal_berlaku' => $plafon->tanggal_berlaku,
                'message'       => '✅ Plafon ditemukan: Rp ' . number_format($plafon->default_value, 0, ',', '.'),
            ]);
        }

        return response()->json([
            'found'         => false,
            'plafon_value'  => 0,
            'message'       => '⚠️ Plafon untuk rute & level ini belum disetting.',
        ]);
    }

    public function store(Request $request, BonSementaraService $bsService, PlafonService $plafonService)
    {
        $request->validate([
            'save_action' => 'sometimes|required|in:draft,confirm',
            'tanggal' => 'required|date',
            'description' => 'required|string|max:255',
            'tujuan_dinas_id' => 'required|exists:wilayah,id',
            'teritory' => 'required|in:Jawa,Luar Jawa',
            'jarak_km' => 'required|numeric|decimal:0,2|min:0|max:99999999.99',
            'durasi_jam' => 'required|numeric|min:0|max:24',
            ...\App\Services\TransactionFundingService::rules(),
            'details' => 'required|array|min:1',
            'details.*.cost_category_id' => 'required|exists:cost_category,id',
            'details.*.remark' => 'required|string|max:255',
            'details.*.nominal' => 'required|numeric|decimal:0,2|min:0|max:9999999999999.99',
        ]);

        $tujuanWilayah = \App\Models\Wilayah::find($request->tujuan_dinas_id);
        if ($tujuanWilayah && $tujuanWilayah->teritory !== $request->teritory) {
            return redirect()->back()
                ->withErrors(['tujuan_dinas_id' => '❌ Wilayah tujuan tidak sesuai dengan Territory yang dipilih!'])
                ->withInput();
        }

        $bsOwnerId = app(\App\Services\TransactionFundingService::class)->resolve($request, true);

        try {
            DB::beginTransaction();
            $activeUserId = Auth::id();
            $user = auth()->user();

            foreach ($request->details as $index => $detail) {
                $costCategory = CostCategory::find($detail['cost_category_id']);
                $categoryName = strtolower($costCategory->name ?? $costCategory->nama ?? $costCategory->description ?? '');

                if (str_contains($categoryName, 'lumpsum') || str_contains($categoryName, 'uang saku')) {
                    if ($request->jarak_km <= 200) {
                        DB::rollBack();
                        return redirect()->back()
                            ->withErrors([
                                'details.' . $index . '.cost_category_id' =>
                                ' Lumpsum HANYA untuk perjalanan > 200 KM. Jarak Anda: ' . $request->jarak_km . ' KM'
                            ])
                            ->withInput();
                    }
                }

                if (str_contains($categoryName, 'hotel') || str_contains($categoryName, 'akomodasi')) {
                    if ($request->durasi_jam <= 8) {
                        DB::rollBack();
                        return redirect()->back()
                            ->withErrors([
                                'details.' . $index . '.cost_category_id' =>
                                ' Hotel/Akomodasi HANYA untuk perjalanan > 8 jam. Durasi Anda: ' . $request->durasi_jam . ' jam'
                            ])
                            ->withInput();
                    }
                }
            }

            $header = TransaksiPerjalananDinasHeader::where('tanggal', $request->tanggal)
                ->where('user_id', $activeUserId)
                ->first();

            if ($header) {
                throw \Illuminate\Validation\ValidationException::withMessages(['tanggal' => 'Transaksi pada tanggal ini sudah ada. Buka transaksi tersebut untuk menambah rincian draft.']);
            } else {
                $transaksi_id = app(DocumentNumberService::class)->next('PD', $request->tanggal);
                $header = TransaksiPerjalananDinasHeader::create([
                    'transaksi_id'    => $transaksi_id,
                    'tanggal'         => $request->tanggal,
                    'user_id'         => $activeUserId,
                    'bs_owner_id' => $bsOwnerId,
                    'periode'         => app(\App\Services\PeriodService::class)->ofDate($request->tanggal),
                    'status'          => 'DRAFT',
                    'description'     => $request->description,
                    'tujuan_dinas_id' => $request->tujuan_dinas_id,
                    'jarak_km'        => $request->jarak_km,
                    'durasi_jam'      => $request->durasi_jam,
                ]);
                $pesan_sukses = 'Draft Perjalanan Dinas (' . $transaksi_id . ') disimpan. Buka detail untuk Konfirmasi.';
            }

            foreach ($request->details as $detail) {
                TransaksiPerjalananDinasDetail::create([
                    'transaksi_id'     => $transaksi_id,
                    'cost_category_id' => $detail['cost_category_id'],
                    'remark'           => $detail['remark'],
                    'nominal'          => $detail['nominal'],
                ]);
            }

            $header->refresh();
            $totalBaru = $header->details()->sum('nominal');

            $cek = $plafonService->checkPerjalananDinas($user, $header->tujuan_dinas_id, $header->tanggal, $totalBaru);
            $wasOver = (bool) $header->is_over_plafon;

            $header->update([
                'is_over_plafon' => $cek['is_over'] ? 1 : 0,
                'plafon_value'   => $cek['plafon_value'],
                'selisih_plafon' => $cek['selisih'],
            ]);

            if ($cek['is_over'] && !$wasOver && $user->atasan_user_id) {
                $atasan = User::find($user->atasan_user_id);
                \App\Services\BsNotifications::send($atasan, new TransaksiOverPlafon(
                    $transaksi_id . ' (Perjalanan Dinas)',
                    $totalBaru, $cek['plafon_value'], $cek['selisih'],
                    route('transaksi_perjalanan_dinas.show', $transaksi_id)
                ));
            }

            if ($request->input('save_action', 'draft') === 'confirm') {
                $status = app(\App\Services\BsValidationService::class)->finalize($header);
                $pesan_sukses = $status === 'PENDING_OWNER'
                    ? 'Permintaan pemakaian BS dikirim kepada pemohon. Saldo belum berkurang sampai disetujui.'
                    : 'Transaksi Perjalanan Dinas (' . $transaksi_id . ') dikonfirmasi dan siap diperiksa Finance. Saldo BS berkurang setelah konfirmasi Finance.';
            }

            DB::commit();
            return redirect()->route('transaksi_perjalanan_dinas.index')->with('success', $pesan_sukses);
        } catch (\Illuminate\Validation\ValidationException $e) {
            DB::rollBack();
            return redirect()->back()->withErrors($e->errors())->withInput();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()->withErrors(['error' => 'Transaksi Gagal: ' . $e->getMessage()])->withInput();
        }
    }

    public function validateTransaction($id)
    {
        $transaksi = TransaksiPerjalananDinasHeader::where('transaksi_id', $id)->firstOrFail();
        $status = app(\App\Services\BsValidationService::class)->finalize($transaksi);
        return redirect()->route('transaksi_perjalanan_dinas.show', $transaksi->transaksi_id)
            ->with('success', $status === 'PENDING_OWNER'
                ? 'Permintaan pemakaian BS dikirim kepada pemohon. Saldo belum berkurang sampai disetujui.'
                : 'Transaksi dikonfirmasi dan siap diperiksa Finance. Saldo BS berkurang setelah konfirmasi Finance.');
    }

    public function withdraw(Request $request, $id)
    {
        return $this->returnToDraft($request, $id, false);
    }

    public function revise(Request $request, $id)
    {
        return $this->returnToDraft($request, $id, true);
    }

    private function returnToDraft(Request $request, $id, bool $rejected)
    {
        $request->validate(['approval_version' => 'required|integer|min:1']);
        $transaksi = TransaksiPerjalananDinasHeader::where('transaksi_id', $id)->firstOrFail();
        app(\App\Services\BsValidationService::class)->returnToDraft($transaksi, (int) $request->approval_version, $rejected);
        return redirect()->route('transaksi_perjalanan_dinas.show', $id)
            ->with('success', 'Transaksi kembali menjadi draft. Perbaiki rincian lalu ajukan kembali untuk persetujuan.');
    }

    public function index()
    {
        $query = TransaksiPerjalananDinasHeader::with(['user', 'tujuanDinas'])->withExists('financeChecks');

        if (!auth()->user()->canSeeAllTransactions()) {
            $query->visibleTo(auth()->user());
        }

        $transaksis = $query->orderBy('tanggal', 'desc')->paginate(10);
        return view('transaksi_perjalanan_dinas.index', compact('transaksis'));
    }

    public function show($id)
    {
        $transaksi = TransaksiPerjalananDinasHeader::with(['user', 'details', 'tujuanDinas.parent', 'bonSementara', 'bsOwner', 'approvalLogs.actor'])->withExists('financeChecks')
            ->where('transaksi_id', $id)->firstOrFail();

        if (!auth()->user()->canViewBsTransaction($transaksi)) {
            abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
        }

        $cost_categories = CostCategory::all();

    

        $currentTerritory = old('teritory', $transaksi->tujuanDinas->teritory ?? 'Jawa');
        if (!in_array($currentTerritory, ['Jawa', 'Luar Jawa'], true)) {
            $currentTerritory = $transaksi->tujuanDinas->teritory ?? 'Jawa';
        }
        $provinces = \App\Models\Wilayah::where('teritory', $currentTerritory)->whereNull('parent_id')->get();

        $currentProvinceId = old('provinsi_id', $transaksi->tujuanDinas->parent_id ?? null);
        $cities = [];
        if ($currentProvinceId) {
            $cities = \App\Models\Wilayah::where('parent_id', $currentProvinceId)->get();
        }

        return view('transaksi_perjalanan_dinas.show', compact(
            'transaksi', 'cost_categories', 'provinces', 'cities', 'currentTerritory', 'currentProvinceId'
        ));
    }

    // 🎯 PERBAIKAN: Tambah guard status DRAFT
    public function update(Request $request, $id, BonSementaraService $bsService, PlafonService $plafonService)
    {
        $transaksi = TransaksiPerjalananDinasHeader::where('transaksi_id', $id)->firstOrFail();

        if (!auth()->user()->canAccessTransaction($transaksi)) {
            abort(403);
        }

        // 🎯 GUARD: Hanya DRAFT yang bisa di-edit
        if ($transaksi->status !== 'DRAFT') {
            return back()->withErrors(['error' => 'Hanya transaksi dengan status DRAFT yang dapat diedit. Transaksi ini sudah dikonfirmasi.']);
        }

        // 🎯 GUARD: Periode harus OPEN
        app(\App\Services\PeriodService::class)->assertOpen($transaksi->periode);

        $request->validate([
            'tanggal' => 'required|date',
            'description' => 'required|string|max:255',
            'teritory' => 'required|in:Jawa,Luar Jawa',
            'tujuan_dinas_id' => 'required|exists:wilayah,id',
            'jarak_km' => 'required|numeric|decimal:0,2|min:0|max:99999999.99',
            'durasi_jam' => 'required|numeric|min:0|max:24',
            ...\App\Services\TransactionFundingService::rules(),
            'details' => 'nullable|array',
            'details.*.cost_category_id' => 'required_with:details|exists:cost_category,id',
            'details.*.remark' => 'nullable|string|max:255',
            'details.*.nominal' => 'required_with:details|numeric|decimal:0,2|min:0|max:9999999999999.99',
            'new_details' => 'nullable|array',
            'new_details.*.cost_category_id' => 'required_with:new_details|exists:cost_category,id',
            'new_details.*.remark' => 'nullable|string|max:255',
            'new_details.*.nominal' => 'required_with:new_details|numeric|decimal:0,2|min:0|max:9999999999999.99',
            'delete_details' => 'nullable|array',
            'delete_details.*' => 'integer|distinct',
        ]);

        app(\App\Services\PeriodService::class)->assertOpen(\Carbon\Carbon::parse($request->tanggal)->format('Y-m'));

        $tujuanWilayah = \App\Models\Wilayah::find($request->tujuan_dinas_id);
        if ($tujuanWilayah && $tujuanWilayah->teritory !== $request->teritory) {
            return back()->withErrors(['tujuan_dinas_id' => 'Wilayah tujuan tidak sesuai dengan Territory yang dipilih.']);
        }

        $bsOwnerId = app(\App\Services\TransactionFundingService::class)->resolve($request, true, $transaksi);

        DB::beginTransaction();
        try {
            $transaksi->update([
                'tanggal' => $request->tanggal,
                'description' => $request->description,
                'tujuan_dinas_id' => $request->tujuan_dinas_id,
                'jarak_km' => $request->jarak_km,
                'durasi_jam' => $request->durasi_jam,
                'bs_owner_id' => $bsOwnerId,
                'periode' => \Carbon\Carbon::parse($request->tanggal)->format('Y-m'),
            ]);

            $validateRules = function($catId, $jarak, $durasi) {
                $cat = CostCategory::find($catId);
                $name = strtolower($cat->name ?? $cat->description ?? '');
                if ((str_contains($name, 'lumpsum') || str_contains($name, 'uang saku')) && $jarak <= 200) {
                    throw new \Exception("Lumpsum hanya untuk jarak > 200 KM.");
                }
                if ((str_contains($name, 'hotel') || str_contains($name, 'akomodasi')) && $durasi <= 8) {
                    throw new \Exception("Hotel hanya untuk durasi > 8 Jam.");
                }
            };

            if ($request->has('details')) {
                foreach ($request->details as $detailId => $data) {
                    $detail = TransaksiPerjalananDinasDetail::find($detailId);
                    if ($detail && $detail->transaksi_id == $transaksi->transaksi_id) {
                        $validateRules($data['cost_category_id'], $request->jarak_km, $request->durasi_jam);
                        $detail->update([
                            'cost_category_id' => $data['cost_category_id'],
                            'remark' => $data['remark'],
                            'nominal' => $data['nominal'],
                        ]);
                    }
                }
            }

            if ($request->has('delete_details') && is_array($request->delete_details)) {
                TransaksiPerjalananDinasDetail::whereIn('id', $request->delete_details)
                    ->where('transaksi_id', $transaksi->transaksi_id)
                    ->delete();
            }

            if ($request->has('new_details')) {
                foreach ($request->new_details as $data) {
                    $validateRules($data['cost_category_id'], $request->jarak_km, $request->durasi_jam);
                    TransaksiPerjalananDinasDetail::create([
                        'transaksi_id' => $transaksi->transaksi_id,
                        'cost_category_id' => $data['cost_category_id'],
                        'remark' => $data['remark'],
                        'nominal' => $data['nominal'],
                    ]);
                }
            }

            $transaksi->refresh();
            $totalBaru = $transaksi->details()->sum('nominal');
            $cek = $plafonService->checkPerjalananDinas($transaksi->user, $transaksi->tujuan_dinas_id, $transaksi->tanggal, $totalBaru);

            $transaksi->update([
                'is_over_plafon' => $cek['is_over'] ? 1 : 0,
                'plafon_value' => $cek['plafon_value'],
                'selisih_plafon' => $cek['selisih'],
            ]);

            DB::commit();
            return redirect()->route('transaksi_perjalanan_dinas.show', $transaksi->transaksi_id)
                ->with('success', 'Transaksi berhasil diperbarui!');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error' => 'Gagal update: ' . $e->getMessage()])->withInput();
        }
    }

    // 🎯 PERBAIKAN: Tambah guard status DRAFT
    public function storeDetail(Request $request, $id, BonSementaraService $bsService, PlafonService $plafonService)
    {
        $request->validate([
            'details' => 'required|array|min:1',
            'details.*.cost_category_id' => 'required|exists:cost_category,id',
            'details.*.remark' => 'required|string|max:255',
            'details.*.nominal' => 'required|numeric|decimal:0,2|min:0|max:9999999999999.99',
        ]);

        try {
            DB::beginTransaction();
            $header = TransaksiPerjalananDinasHeader::where('transaksi_id', $id)->firstOrFail();

            if (!auth()->user()->canAccessTransaction($header)) {
                abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
            }

            // 🎯 GUARD: Hanya DRAFT yang bisa ditambah detail
            if ($header->status !== 'DRAFT') {
                return back()->withErrors(['error' => 'Tidak dapat menambah rincian. Transaksi sudah dikonfirmasi.']);
            }

            // 🎯 GUARD: Periode harus OPEN
            app(\App\Services\PeriodService::class)->assertOpen($header->periode);

            

            foreach ($request->details as $index => $detail) {
                $costCategory = CostCategory::find($detail['cost_category_id']);
                $categoryName = strtolower($costCategory->name ?? $costCategory->nama ?? $costCategory->description ?? '');

                if (str_contains($categoryName, 'lumpsum') || str_contains($categoryName, 'uang saku')) {
                    if ($header->jarak_km <= 200) {
                        DB::rollBack();
                        return redirect()->back()->withErrors([
                            'details.' . $index . '.cost_category_id' =>
                            '❌ Lumpsum HANYA untuk perjalanan > 200 KM. Jarak transaksi ini: ' . $header->jarak_km . ' KM'
                        ])->withInput();
                    }
                }

                if (str_contains($categoryName, 'hotel') || str_contains($categoryName, 'akomodasi')) {
                    if ($header->durasi_jam <= 8) {
                        DB::rollBack();
                        return redirect()->back()->withErrors([
                            'details.' . $index . '.cost_category_id' =>
                            '❌ Hotel/Akomodasi HANYA untuk perjalanan > 8 jam. Durasi transaksi ini: ' . $header->durasi_jam . ' jam'
                        ])->withInput();
                    }
                }
            }

            foreach ($request->details as $detail) {
                TransaksiPerjalananDinasDetail::create([
                    'transaksi_id'     => $header->transaksi_id,
                    'cost_category_id' => $detail['cost_category_id'],
                    'remark'           => $detail['remark'],
                    'nominal'          => $detail['nominal'],
                ]);
            }

            $header->refresh();
            $totalBaru = $header->details()->sum('nominal');

            $cek = $plafonService->checkPerjalananDinas($header->user, $header->tujuan_dinas_id, $header->tanggal, $totalBaru);
            $wasOver = (bool) $header->is_over_plafon;

            $header->update([
                'is_over_plafon' => $cek['is_over'] ? 1 : 0,
                'plafon_value'   => $cek['plafon_value'],
                'selisih_plafon' => $cek['selisih'],
            ]);

            if ($cek['is_over'] && !$wasOver && $header->user->atasan_user_id) {
                $atasan = User::find($header->user->atasan_user_id);
                \App\Services\BsNotifications::send($atasan, new TransaksiOverPlafon(
                    $header->transaksi_id . ' (Perjalanan Dinas)',
                    $totalBaru, $cek['plafon_value'], $cek['selisih'],
                    route('transaksi_perjalanan_dinas.show', $header->transaksi_id)
                ));
            }

            DB::commit();
            return redirect()->back()->with('success', 'Rincian biaya berhasil ditambahkan ke Transaksi (' . $id . ')!');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()->withErrors(['error' => 'Gagal Menambah Rincian: ' . $e->getMessage()]);
        }
    }

    // 🎯 PERBAIKAN: Tambah guard status DRAFT
    public function destroy($id)
    {
        $transaksi = TransaksiPerjalananDinasHeader::where('transaksi_id', $id)->firstOrFail();

        if (!auth()->user()->canAccessTransaction($transaksi)) {
            abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
        }

        // 🎯 GUARD: Hanya DRAFT yang bisa dihapus
        if ($transaksi->status !== 'DRAFT') {
            return back()->withErrors(['error' => 'Tidak dapat menghapus transaksi yang sudah dikonfirmasi.']);
        }

            $periode = $transaksi->periode;

        $transaksi->details()->delete();
        $transaksi->delete();

        return redirect()->route('transaksi_perjalanan_dinas.index')
            ->with('success', 'Transaksi Perjalanan Dinas berhasil dihapus!');
    }

    public function getAutoNominal(Request $request, PlafonService $plafonService)
    {
        $costCategoryId = $request->cost_category_id;
        $jarakKm = (float) $request->jarak_km;
        $durasiJam = (float) $request->durasi_jam;
        $tujuanDinasId = $request->tujuan_dinas_id;
        $user = Auth::user();

        $costCategory = CostCategory::find($costCategoryId);
        $categoryName = strtolower($costCategory->name ?? $costCategory->description ?? '');

        if (str_contains($categoryName, 'lumpsum') || str_contains($categoryName, 'uang saku')) {
            if ($jarakKm <= 200) {
                return response()->json([
                    'nominal' => 0, 'is_valid' => false, 'is_readonly' => false,
                    'message' => "❌ Lumpsum hanya untuk jarak > 200 KM. Jarak Anda: {$jarakKm} KM"
                ]);
            }
        } elseif (str_contains($categoryName, 'hotel') || str_contains($categoryName, 'akomodasi') || str_contains($categoryName, 'menginap')) {
            if ($durasiJam <= 8) {
                return response()->json([
                    'nominal' => 0, 'is_valid' => false, 'is_readonly' => false,
                    'message' => "❌ Hotel hanya untuk durasi > 8 Jam. Durasi Anda: {$durasiJam} Jam"
                ]);
            }
        }

        if ($tujuanDinasId) {
            $plafon = $plafonService->getPlafonPerjalananDinas($user, $tujuanDinasId, now());
            if ($plafon) {
                return response()->json([
                    'nominal' => 0, 'is_valid' => true, 'is_readonly' => false,
                    'plafon_total' => (float) $plafon->default_value,
                    'message' => "ℹ️ Silakan input nominal manual. Plafon Total Perjalanan: Rp " . number_format($plafon->default_value, 0, ',', '.')
                ]);
            }
        }

        return response()->json([
            'nominal' => 0, 'is_valid' => true, 'is_readonly' => false,
            'message' => "ℹ️ Kategori Umum. Silakan input nominal secara manual."
        ]);
    }

    public function export(Request $request)
    {
        $periode = $request->get('periode');
        $query = TransaksiPerjalananDinasHeader::with(['user', 'details', 'tujuanDinas', 'bonSementara', 'bsOwner']);

        if (!auth()->user()->canSeeAllTransactions()) {
            $query->visibleTo(auth()->user());
        }

        if ($periode) $query->where('periode', $periode);

        $headers = $query->where('status', 'VALIDATED')->orderBy('tanggal')->get();
        $categories = \App\Models\CostCategory::pluck('nama', 'id');

        $headings = ['Transaksi ID', 'Tanggal', 'Periode', 'User', 'Tujuan Dinas', 'Jarak (KM)', 'Durasi (Jam)', 'Pemilik Saldo BS', 'Cost Category', 'Remark', 'Nominal', 'Plafon', 'Status Plafon'];
        $rows = [];
        $total = 0;

        foreach ($headers as $h) {
            foreach ($h->details as $d) {
                $total += (float) $d->nominal;
                $rows[] = [
                    $h->transaksi_id,
                    \Carbon\Carbon::parse($h->tanggal)->format('d/m/Y'),
                    str_replace('-', '', $h->periode ?? ''),
                    $h->user->nama ?? '',
                    $h->tujuanDinas->nama ?? '',
                    (float) $h->jarak_km,
                    (float) $h->durasi_jam,
                    $h->bsOwner?->nama ?? $h->bonSementara?->user?->nama ?? 'Arsip tanpa BS',
                    $categories[$d->cost_category_id] ?? '',
                    $d->remark,
                    (float) $d->nominal,
                    $h->plafon_value ? (float) $h->plafon_value : '',
                    $h->is_over_plafon ? 'OVER' : ($h->plafon_value ? 'SESUAI' : '-'),
                ];
            }
        }
        $rows[] = ['TOTAL', '', '', '', '', '', '', '', '', '', (float) $total, '', ''];

        return \Maatwebsite\Excel\Facades\Excel::download(
            new \App\Exports\LaporanTableExport($headings, $rows, ['K', 'L']),
            'laporan-perjalanan-dinas-' . ($periode ?: 'semua-periode') . '.xlsx'
        );
    }

    // 🎯 PERBAIKAN: Tambah guard status header
    public function destroyDetail(Request $request, $detailId)
    {
        $request->validate(['reason' => 'required|string|max:255']);

        $detail = TransaksiPerjalananDinasDetail::with(['header', 'costCategory'])->findOrFail($detailId);
        $header = $detail->header;
        $user = auth()->user();

        if (!$user->canAccessTransaction($header)) {
            return response()->json(['message' => 'Anda tidak memiliki akses untuk menghapus detail ini.'], 403);
        }

        // 🎯 GUARD: Hanya DRAFT yang bisa dihapus detailnya
        if ($header->status !== 'DRAFT') {
            return response()->json([
                'message' => 'Gagal: Transaksi sudah dikonfirmasi. Detail tidak dapat dihapus.'
            ], 403);
        }

        $periodService = app(\App\Services\PeriodService::class);
        if ($periodService->statusOf($header->periode) !== 'OPEN') {
            return response()->json([
                'message' => 'Gagal: Periode transaksi ini sudah CLOSE. Detail tidak dapat dihapus.'
            ], 403);
        }

        

        try {
            DB::beginTransaction();

            $oldValue = [
                'cost_category' => $detail->costCategory->name ?? $detail->cost_category_id,
                'remark'        => $detail->remark,
                'nominal'       => $detail->nominal,
            ];

            $detail->delete();

            $newTotal = $header->details()->sum('nominal');
            $plafonService = app(PlafonService::class);
            $cek = $plafonService->checkPerjalananDinas($header->user, $header->tujuan_dinas_id, $header->tanggal, $newTotal);

            $header->update([
                'is_over_plafon' => $cek['is_over'] ? 1 : 0,
                'plafon_value'   => $cek['plafon_value'] ?? 0,
                'selisih_plafon' => $cek['selisih'] ?? 0,
            ]);

            \App\Models\AuditLog::create([
                'user_id'    => $user->id,
                'action'     => 'DELETE_DETAIL',
                'table_name' => 'transaksi_perjalanan_dinas_detail',
                'record_id'  => $detail->id,
                'reason'     => $request->reason,
                'old_value'  => json_encode($oldValue),
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Detail berhasil dihapus. Total draft telah diperbarui.',
                'new_total' => $newTotal,
                'is_over' => $cek['is_over'],
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('Gagal hapus detail transaksi: ' . $e->getMessage());
            return response()->json(['message' => 'Gagal menghapus detail: ' . $e->getMessage()], 500);
        }
    }
}

~~~~

## app/Models/TransaksiPerjalananDinasDetail.php

Model tabel transaksi_perjalanan_dinas_detail; penyimpanan metadata foto per item.

~~~~php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes; // 🎯 TAMBAHKAN

class TransaksiPerjalananDinasDetail extends Model
{
    use HasFactory, SoftDeletes; // 🎯 TAMBAHKAN SoftDeletes

    protected $table = 'transaksi_perjalanan_dinas_detail';
    public $timestamps = false;
    
    // 🎯 PENTING: Beritahu Laravel hanya pakai deleted_at, jangan cari updated_at
    const DELETED_AT = 'deleted_at'; 

    protected $fillable = [
        'transaksi_id',
        'cost_category_id',
        'remark',
        'nominal'
    ];

    public function header()
    {
        return $this->belongsTo(TransaksiPerjalananDinasHeader::class, 'transaksi_id', 'transaksi_id');
    }

    public function costCategory()
    {
        return $this->belongsTo(CostCategory::class, 'cost_category_id', 'id');
    }
}
~~~~

## app/Models/TransaksiPerjalananDinasHeader.php

Relasi details dan identitas transaksi induk untuk pemeriksaan akses.

~~~~php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TransaksiPerjalananDinasHeader extends Model
{
    use HasFactory, \App\Models\Concerns\UsesBsBalance;

    protected $table = 'transaksi_perjalanan_dinas_header';
    public $timestamps = false;
    protected $casts = ['validated_at' => 'datetime', 'submitted_at' => 'datetime', 'owner_reviewed_at' => 'datetime', 'approval_version' => 'integer'];
    protected $attributes = ['status' => 'DRAFT'];

    protected $fillable = [
        'status', 'validated_at', 'validated_by', 'bs_owner_id',
        'approval_version', 'submitted_at', 'submitted_by', 'owner_reviewed_at', 'owner_reviewed_by', 'owner_rejection_reason',
        'transaksi_id',
        'document_no',
        'tanggal',
        'no_referensi_bs',
        'bs_id',
        'user_id',
        'tujuan_dinas_id',   // ✅ diperbaiki dari 'tujuan_dinas'
        'jarak_km',          // ✅ ditambah
        'durasi_jam',        // ✅ ditambah
        'description',
        'periode',
        'is_over_plafon',
        'plafon_value',      // ✅ ditambah (dipakai di $header->update())
        'selisih_plafon',    // ✅ ditambah
    ];

    public function details()
    {
        return $this->hasMany(TransaksiPerjalananDinasDetail::class, 'transaksi_id', 'transaksi_id');
    }

    public function financeChecks()
    {
        return $this->hasMany(BsUsageCheck::class, 'transaksi_pemakaian_id')->where('jenis_transaksi', 'PD');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function bonSementara()
    {
        return $this->belongsTo(PengajuanBs::class, 'bs_id', 'id');
    }

    public function tujuanDinas()
    {
        return $this->belongsTo(Wilayah::class, 'tujuan_dinas_id', 'id');
    }

    public function approvalLogs()
    {
        return $this->hasMany(BsUsageApprovalLog::class, 'transaction_id')->orderBy('id');
    }

    public function needsOwnerApproval(): bool
    {
        return $this->bsCashOwnerId() !== null && $this->bsCashOwnerId() !== (int) $this->user_id;
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'DRAFT' => 'Draft',
            'PENDING_OWNER' => 'Menunggu Persetujuan Pemohon',
            'REJECTED_OWNER' => 'Ditolak Pemohon',
            'VALIDATED' => 'Dikonfirmasi',
            default => $this->status,
        };
    }
}

~~~~
