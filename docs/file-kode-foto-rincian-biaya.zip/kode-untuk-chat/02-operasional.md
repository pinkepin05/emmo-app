# Operasional — modul dengan alur rincian serupa

Salinan kode saat pemetaan 8 Oktober 2026. Fitur foto per rincian belum diimplementasikan.

## resources/views/transaksi_operasional/create.blade.php

Form pembuatan, template baris dinamis dan reindexRows; indeks input foto harus mengikuti baris yang benar.

~~~~php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Input Transaksi Operasional</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- 🎯 TAMBAHAN: Flatpickr CSS untuk Datepicker Modern -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            --danger-gradient: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%);
            --primary-color: #667eea;
            --success-color: #11998e;
            --bg-color: #f0f4f8;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-color);
            background-image: radial-gradient(#667eea 0.5px, transparent 0.5px), radial-gradient(#667eea 0.5px, var(--bg-color) 0.5px);
            background-size: 20px 20px;
            background-position: 0 0, 10px 10px;
            min-height: 100vh;
        }

        .page-header {
            background: var(--primary-gradient);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(102, 126, 234, 0.3);
        }

        .page-header h1 { font-weight: 800; margin: 0; font-size: 2rem; }
        .page-header p { margin: 0.5rem 0 0 0; opacity: 0.9; }

        .card-modern {
            background: white;
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            overflow: visible;
            margin-bottom: 2rem;
        }

        .card-header-modern {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
            padding: 1.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-radius: 20px 20px 0 0;
        }

        .card-header-modern.success {
            background: linear-gradient(135deg, rgba(17, 153, 142, 0.1) 0%, rgba(56, 239, 125, 0.1) 100%);
            border-bottom-color: rgba(17, 153, 142, 0.2);
        }

        .card-header-modern.sticky-detail {
            position: sticky;
            top: 0;
            z-index: 1020;
            background: linear-gradient(135deg, #e6f7f4 0%, #eafcf0 100%);
            transition: box-shadow 0.25s ease, border-radius 0.25s ease;
        }
        .card-header-modern.sticky-detail.is-stuck {
            box-shadow: 0 8px 24px rgba(17, 153, 142, 0.22);
            border-radius: 0;
        }

        .card-header-modern h5 {
            margin: 0;
            font-weight: 700;
            color: #2d3748;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .card-header-modern h5 i {
            font-size: 1.5rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .card-header-modern.success h5 i {
            background: var(--success-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .form-label { font-weight: 600; color: #4a5568; margin-bottom: 0.5rem; font-size: 0.9rem; }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 0.75rem 1rem;
            font-size: 0.95rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .form-control:disabled { background: #f7fafc; border-color: #e2e8f0; }

        .input-group-text {
            background: white;
            border: 2px solid #e2e8f0;
            border-right: none;
            border-radius: 12px 0 0 12px;
            color: var(--primary-color);
            font-weight: 600;
        }

        .input-with-icon .form-control { border-radius: 0 12px 12px 0; }

        .btn-modern {
            border-radius: 12px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary-modern {
            background: var(--primary-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            border-radius: 15px;
            font-weight: 700;
            letter-spacing: 0.3px;
        }

        .btn-primary-modern:hover,
        .btn-primary-modern:focus,
        .btn-primary-modern:active {
            background: var(--primary-gradient);
            color: white;
            transform: none;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-success-modern {
            background: var(--success-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
            transition: all 0.3s ease;
        }

        .btn-success-modern:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(17, 153, 142, 0.5);
            color: white;
        }

        .btn-danger-modern {
            background: var(--danger-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(238, 9, 121, 0.4);
            transition: all 0.3s ease;
        }

        .btn-danger-modern:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(238, 9, 121, 0.5);
            color: white;
        }

        .table-modern { width: 100%; border-collapse: separate; border-spacing: 0; }

        .table-modern thead th {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            border-bottom: 2px solid #e2e8f0;
            padding: 1rem;
            font-weight: 700;
            color: #2d3748;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        .table-modern tbody td {
            padding: 1rem;
            border-bottom: 1px solid #f0f4f8;
            vertical-align: middle;
        }

        .table-modern tbody tr:hover { background: rgba(102, 126, 234, 0.02); }

        .total-badge {
            background: linear-gradient(135deg, rgba(17, 153, 142, 0.1) 0%, rgba(56, 239, 125, 0.1) 100%);
            border: 2px solid var(--success-color);
            border-radius: 15px;
            padding: 1rem 1.5rem;
            text-align: right;
        }

        .total-badge .amount {
            font-size: 1.75rem;
            font-weight: 800;
            background: var(--success-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .info-box {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            border-left: 4px solid var(--primary-color);
            border-radius: 12px;
            padding: 1rem 1.5rem;
            margin-top: 1rem;
        }

        .alert-custom {
            border-radius: 15px;
            border: none;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
        }

        .btn-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0;
        }

        .section-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.2), transparent);
            margin: 1.5rem 0;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-slide-in { animation: slideIn 0.5s ease; }

        @media (max-width: 768px) {
            .page-header h1 { font-size: 1.5rem; }
            .card-header-modern { flex-direction: column; gap: 1rem; text-align: center; }
            .total-badge { text-align: center; margin-bottom: 1rem; width: 100%; }
            .total-badge .amount { font-size: 1.3rem; }
        }
    </style>
    @include('partials.mobile-assets')
</head>
<body>
    @include('partials.application-time')
    <!-- Page Header -->
    <div class="page-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1><i class="bi bi-receipt me-3"></i>Transaksi Operasional</h1>
                    <p class="mb-0">Input dan kelola transaksi area sales dengan mudah</p>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <a href="{{ route('dashboard.transaksi') }}" class="btn btn-light btn-modern">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container" style="max-width: 1100px; margin-bottom: 3rem;">

        @if(session('success'))
            <div class="alert alert-success alert-custom alert-dismissible fade show mb-4">
                <div class="d-flex align-items-center">
                    <i class="bi bi-check-circle-fill me-3 fs-4"></i>
                    <div><strong>Berhasil!</strong> {{ session('success') }}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if($errors->any())
            <div class="alert alert-danger alert-custom alert-dismissible fade show mb-4">
                <div class="d-flex align-items-center">
                    <i class="bi bi-exclamation-circle-fill me-3 fs-4"></i>
                    <div>
                        <strong>Gagal Menyimpan:</strong>
                        <ul class="mb-0 mt-2">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <form action="{{ route('transaksi_operasional.store') }}" method="POST" id="form-operasional">
            @csrf

            <!-- Card 1: Data Header -->
            <div class="card-modern animate-slide-in">
                <div class="card-header-modern">
                    <h5><i class="bi bi-clipboard-data"></i> Data Header Transaksi</h5>
                    <span class="badge bg-primary bg-opacity-10 text-primary">Step 1 dari 2</span>
                </div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <label class="form-label">
                                <i class="bi bi-calendar-event me-2 text-primary"></i>Tanggal Transaksi
                            </label>
                            <div class="input-group input-with-icon">
                                <span class="input-group-text"><i class="bi bi-calendar"></i></span>
                                <!-- 🎯 UBAH: type="text" agar Flatpickr bisa mengambil alih -->
                                @php
                                    $initialDate = old('tanggal', \App\Support\AppTime::now()->toDateString());
                                    if (in_array($initialDate, $usedDates, true)) $initialDate = '';
                                @endphp
                                <input type="text" id="tanggal_picker" name="tanggal" class="form-control" value="{{ $initialDate }}" placeholder="Pilih tanggal..." required autocomplete="off" aria-describedby="tanggal-help">
                            </div>
                            <small id="tanggal-help" class="text-muted mt-1 d-block">Tanggal yang sudah memiliki transaksi Anda, termasuk draft, tidak dapat dipilih. Tambahkan rincian biaya pada transaksi yang sudah ada.</small>
                            <div id="periodWarning" class="alert alert-danger d-none mt-2" style="border-radius:12px;">
                                <i class="bi bi-lock-fill me-2"></i><span id="periodWarningText"></span>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">
                                <i class="bi bi-person-badge me-2 text-primary"></i>User (Karyawan)
                            </label>
                            <div class="input-group input-with-icon">
                                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                <input type="text" class="form-control bg-light" value="{{ Auth::user()->nama ?? Auth::user()->name }} (NIK: {{ Auth::user()->NIK ?? '-' }})" readonly disabled>
                            </div>
                            <small class="text-muted mt-1 d-block"><i class="bi bi-info-circle me-1"></i>Transaksi otomatis dicatat atas nama akun Anda</small>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">
                                <i class="bi bi-file-text me-2 text-primary"></i>Deskripsi (Tujuan) <span class="text-muted fw-normal small">(Opsional)</span>
                            </label>
                            <div class="input-group input-with-icon">
                                <span class="input-group-text"><i class="bi bi-tag"></i></span>
                                <input type="text" name="description" class="form-control"
                                       placeholder="Contoh: Kunjungan Toko ABC"
                                       value="{{ old('description') }}">
                            </div>
                            <small class="text-muted mt-1 d-block"><i class="bi bi-info-circle me-1"></i>Kosongkan jika tidak perlu.</small>
                        </div>
                    </div>

                    <div class="section-divider"></div>

                   <div class="mt-4">
    @include('partials.transaction-funding', ['fundingType' => 'operasional_sales'])
    <div id="bs-warning-info" class="alert alert-warning mt-3 d-none">Total rincian biaya melebihi saldo BS gabungan yang tersedia.</div>
</div>
</div>
</div>

            <!-- Card 2: Rincian Biaya (dengan sticky header) -->
            <div class="card-modern animate-slide-in" style="animation-delay: 0.1s">
                <div id="sticky-sentinel" style="height: 0;"></div>

                <div class="card-header-modern success sticky-detail" id="detail-header">
                    <h5><i class="bi bi-receipt-cutoff"></i> Rincian Biaya (Detail)</h5>
                    <div class="d-flex align-items-center gap-3">
                        <div class="total-badge mb-0">
                            <small class="text-muted d-block">Total Rincian</small>
                            <span id="total-rincian" class="amount">Rp 0</span>
                        </div>
                        <button type="button" class="btn btn-success-modern btn-sm" id="btn-tambah-baris">
                            <i class="bi bi-plus-lg"></i> Tambah Baris
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table-modern" id="tabel-detail" data-mobile-entry>
                            <thead>
                                <tr>
                                    <th width="30%"><i class="bi bi-tag me-2"></i>Cost Category <span class="text-danger">*</span></th>
                                    <th width="35%"><i class="bi bi-chat-left-text me-2"></i>Remark (Keterangan)</th>
                                    <th width="25%"><i class="bi bi-currency-dollar me-2"></i>Nominal (Rp) <span class="text-danger">*</span></th>
                                    <th width="10%" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $oldDetails = array_values(old('details', [[]])); @endphp
                                @foreach($oldDetails as $idx => $oldDetail)
                                <tr id="baris-{{ $idx }}" class="animate-slide-in">
                                    <td>
                                        <select name="details[{{ $idx }}][cost_category_id]" class="form-select" required>
                                            <option value="">-- Pilih Cost Category --</option>
                                            @foreach($cost_categories as $cc)
                                                <option value="{{ $cc->id }}" @selected(($oldDetail['cost_category_id'] ?? '') == $cc->id)>{{ $cc->name ?? $cc->nama ?? $cc->code }}</option>
                                            @endforeach
                                        </select>
                                    </td>
                                    <td>
                                        <input type="text" name="details[{{ $idx }}][remark]" class="form-control" placeholder="Misal: Bensin Motor" value="{{ $oldDetail['remark'] ?? '' }}" required>
                                    </td>
                                    <td>
                                        @php $oldNominal = $oldDetail['nominal'] ?? ''; @endphp
                                        <div class="input-group input-with-icon">
                                            <span class="input-group-text">Rp</span>
                                            <input type="text" inputmode="numeric" autocomplete="off"
                                                   class="form-control nominal-display" placeholder="0" value="{{ $oldNominal !== '' ? number_format((float) $oldNominal, 0, ',', '.') : '' }}" required>
                                            <input type="hidden" name="details[{{ $idx }}][nominal]" class="nominal-hidden" value="{{ $oldNominal }}">
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-danger-modern btn-icon btn-sm btn-hapus" data-id="{{ $idx }}" title="Hapus baris">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <p class="text-muted small">Draft dapat diedit. Konfirmasi mengunci transaksi untuk diperiksa Finance. Saldo BS baru berkurang sesuai nominal yang dikonfirmasi Finance.</p>
            <div class="d-grid d-sm-flex gap-2 animate-slide-in" style="animation-delay: 0.2s">
                <button type="submit" name="save_action" value="draft" class="btn btn-outline-secondary btn-lg py-3 flex-fill">
                    <i class="bi bi-save me-2 fs-5"></i> Simpan Draft
                </button>
                <button type="submit" name="save_action" value="confirm" class="btn btn-primary-modern btn-lg py-3 flex-fill">
                    <i class="bi bi-check-circle me-2 fs-5"></i> Simpan &amp; Konfirmasi
                </button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- 🎯 TAMBAHAN: Flatpickr JS & Locale Indonesia -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/id.js"></script>

    <script>
        $(document).ready(function() {

            // ============================================================
            // 🎯 1. STICKY HEADER DETECTION
            // ============================================================
            const sentinel     = document.getElementById('sticky-sentinel');
            const detailHeader = document.getElementById('detail-header');
            if (sentinel && detailHeader && 'IntersectionObserver' in window) {
                new IntersectionObserver((entries) => {
                    detailHeader.classList.toggle('is-stuck', !entries[0].isIntersecting);
                }, { threshold: 1 }).observe(sentinel);
            }

            // ============================================================
            // 🎯 2. FORMAT & LIMIT NOMINAL
            // ============================================================
            const MAX_DIGITS   = 9;
            const formatRibuan = d => d.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            const bersih       = v => String(v).replace(/\D/g, '').replace(/^0+/, '').slice(0, MAX_DIGITS);

            function syncNominal(el) {
                const caret       = el.selectionStart || 0;
                const digitBefore = el.value.slice(0, caret).replace(/\D/g, '').length;
                const digits      = bersih(el.value);

                el.value = digits ? formatRibuan(digits) : '';

                let count = 0, pos = 0;
                for (let i = 0; i < el.value.length; i++) {
                    if (count >= digitBefore) break;
                    if (/\d/.test(el.value[i])) count++;
                    pos = i + 1;
                }
                el.setSelectionRange(pos, pos);

                const hidden = el.closest('td').querySelector('.nominal-hidden');
                if (hidden) hidden.value = digits;
            }

            $(document).on('input', '.nominal-display', function() {
                syncNominal(this);
                hitungTotal();
            });

            // ============================================================
            // 🎯 3. LOGIC TOTAL & WARNING BS
            // ============================================================
            function getSisaSaldoBs() {
    const value = document.getElementById('bs-saldo-info')?.dataset.balance;
    return value === undefined || value === '' ? null : Number(value);
}

            function hitungTotal() {
                let total = 0;
                $('.nominal-hidden').each(function() {
                    total += parseFloat(this.value) || 0;
                });
                $('#total-rincian').html('Rp ' + new Intl.NumberFormat('id-ID').format(total));

                const sisa = getSisaSaldoBs();
                if (sisa !== null && total > sisa) {
                    $('#bs-warning-info').removeClass('d-none');
                    $('#total-rincian').css('background', 'linear-gradient(135deg, #ee0979 0%, #ff6a00 100%)')
                                       .css('-webkit-background-clip', 'text')
                                       .css('-webkit-text-fill-color', 'transparent');
                } else {
                    $('#bs-warning-info').addClass('d-none');
                    $('#total-rincian').css('background', 'var(--success-gradient)')
                                       .css('-webkit-background-clip', 'text')
                                       .css('-webkit-text-fill-color', 'transparent');
                }
                return total;
            }

            document.addEventListener('bs-balance-updated', hitungTotal);

            // ============================================================
            // 🎯 4. DYNAMIC ROWS
            // ============================================================
            let rowIndex = {{ count($oldDetails) }};

            const costCategoryOptions = `
                <option value="">-- Pilih Cost Category --</option>
                @foreach($cost_categories as $cc)
                    <option value="{{ $cc->id }}">{{ $cc->name ?? $cc->nama ?? $cc->code }}</option>
                @endforeach
            `;

            function reindexRows() {
                $('#tabel-detail tbody tr').each(function(i) {
                    $(this).attr('id', 'baris-' + i);
                    $(this).find('select').attr('name', 'details[' + i + '][cost_category_id]');
                    $(this).find('input[type="text"][name^="details"]').attr('name', 'details[' + i + '][remark]');
                    $(this).find('.nominal-hidden').attr('name', 'details[' + i + '][nominal]');
                    $(this).find('.btn-hapus').attr('data-id', i);
                });
                rowIndex = $('#tabel-detail tbody tr').length;
            }

            $('#btn-tambah-baris').click(function() {
                const current = rowIndex;
                let barisBaru = `
                    <tr id="baris-${current}" class="animate-slide-in">
                        <td>
                            <select name="details[${current}][cost_category_id]" class="form-select" required>
                                ${costCategoryOptions}
                            </select>
                        </td>
                        <td>
                            <input type="text" name="details[${current}][remark]" class="form-control" placeholder="Tambahan keterangan..." required>
                        </td>
                        <td>
                            <div class="input-group input-with-icon">
                                <span class="input-group-text">Rp</span>
                                <input type="text" inputmode="numeric" autocomplete="off"
                                       class="form-control nominal-display" placeholder="0" required>
                                <input type="hidden" name="details[${current}][nominal]" class="nominal-hidden" value="">
                            </div>
                        </td>
                        <td class="text-center">
                            <button type="button" class="btn btn-danger-modern btn-icon btn-sm btn-hapus" data-id="${current}" title="Hapus baris">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;

                $('#tabel-detail tbody').append(barisBaru);
                rowIndex++;
                hitungTotal();

                const el = document.getElementById('baris-' + current);
                if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => el.querySelector('select')?.focus({ preventScroll: true }), 400);
                }
            });

            $(document).on('click', '.btn-hapus', function() {
                const $row = $(this).closest('tr');
                if ($row.hasClass('removing')) return;

                if ($('#tabel-detail tbody tr').not('.removing').length <= 1) {
                    alert('⚠️ Minimal harus ada 1 baris rincian biaya.');
                    return;
                }

                $row.addClass('removing').fadeOut(300, function() {
                    $(this).remove();
                    reindexRows();
                    hitungTotal();
                });
            });

            // ============================================================
            // 🎯 5. VALIDASI SUBMIT
            // ============================================================
            $('#form-operasional').on('submit', function(e) {
                const dateWarning = getDateWarning(tglInput.value);
                if (dateWarning) {
                    e.preventDefault();
                    showDateWarning(dateWarning);
                    return false;
                }

                let nominalValid = true;
                $('.nominal-display').each(function() {
                    const digits = bersih(this.value);
                    $(this).closest('td').find('.nominal-hidden').val(digits);
                    if (!digits) nominalValid = false;
                });
                if (!nominalValid) {
                    e.preventDefault();
                    alert('⚠️ Nominal tidak boleh kosong atau nol.');
                    return false;
                }

                const sisa  = getSisaSaldoBs();
                const total = hitungTotal();

                // Saldo diperiksa di server saat Konfirmasi.

            });

            hitungTotal();

            // ============================================================
            // 🎯 6. PERIOD LOCK FRONTEND (DENGAN FLATPICKR)
            // ============================================================
            const tglInput  = document.getElementById('tanggal_picker');
            const warning   = document.getElementById('periodWarning');
            const submitButtons = document.querySelectorAll('#form-operasional button[name="save_action"]');
            
            // 🎯 Daftar periode OPEN dari backend (diinject dari Controller)
            const openPeriods = @json($openPeriods);
            const usedDates = new Set(@json($usedDates));
            const today = @json(\App\Support\AppTime::now()->toDateString());
            let periodValidation = 0;

            function formatLocalDate(date) {
                const y = date.getFullYear();
                const m = String(date.getMonth() + 1).padStart(2, '0');
                const d = String(date.getDate()).padStart(2, '0');
                return `${y}-${m}-${d}`;
            }

            function getDateWarning(dateStr) {
                if (!dateStr) return 'Pilih tanggal transaksi yang belum digunakan.';
                if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return 'Pilih tanggal transaksi yang valid.';
                if (usedDates.has(dateStr)) {
                    return 'Anda sudah memiliki transaksi pada tanggal ini. Pilih tanggal lain atau tambahkan rincian biaya pada transaksi yang sudah ada.';
                }
                if (dateStr > today) return 'Tanggal transaksi tidak boleh di masa depan.';
                const periode = dateStr.slice(0, 7);
                if (!openPeriods.includes(periode)) {
                    return `Periode ${periode} tidak aktif atau sudah DITUTUP. Pilih tanggal di bulan yang berjalan/OPEN.`;
                }
                return '';
            }

            function showDateWarning(message) {
                document.getElementById('periodWarningText').textContent = message;
                warning.classList.toggle('d-none', !message);
                submitButtons.forEach(button => button.disabled = Boolean(message));
            }

            if (tglInput && typeof flatpickr !== 'undefined') {
                flatpickr(tglInput, {
                    dateFormat: "Y-m-d",
                    altInput: true,
                    altFormat: "d F Y", // Tampilan user: 03 September 2026
                    locale: "id",       // Bahasa Indonesia
                    maxDate: today,
                    defaultDate: tglInput.value || null,
                    disableMobile: true,
                    disable: [
                        function(date) {
                            const dateStr = formatLocalDate(date);
                            return usedDates.has(dateStr) || !openPeriods.includes(dateStr.slice(0, 7));
                        }
                    ]
                });
            }

            async function validatePeriod(dateStr) {
                const currentValidation = ++periodValidation;
                const dateWarning = getDateWarning(dateStr);
                showDateWarning(dateWarning);
                if (dateWarning) return;
                const periode = dateStr.slice(0, 7);

                try {
                    // Validasi ganda ke API untuk memastikan sinkronisasi real-time
                    const response = await fetch(`/api/periode/status?periode=${periode}`);
                    if (!response.ok) throw new Error('Status periode tidak dapat dimuat');
                    const data = await response.json();
                    if (currentValidation !== periodValidation || dateStr !== tglInput.value) return;
                    if (!data.open) {
                        showDateWarning(`Periode ${periode} sudah DITUTUP. Pilih tanggal di periode OPEN.`);
                    } else {
                        showDateWarning('');
                    }
                } catch (err) {
                    if (currentValidation !== periodValidation || dateStr !== tglInput.value) return;
                    console.warn('Gagal cek status periode:', err);
                    // Fallback: jika API gagal tapi frontend bilang open, biarkan saja (backend akan catch juga)
                    showDateWarning(getDateWarning(dateStr));
                }
            }

            if (tglInput) {
                tglInput.addEventListener('change', () => validatePeriod(tglInput.value));
                validatePeriod(tglInput.value);
            }
        });
    </script>
</body>
</html>

~~~~

## resources/views/transaksi_operasional/show.blade.php

Tabel rincian tersimpan dan form edit Operasional.

~~~~php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Detail Operasional Area Sales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --purple-gradient: linear-gradient(135deg, #6f42c1 0%, #9b5de5 100%);
            --success-gradient: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            --danger-gradient: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%);
            --purple-color: #6f42c1;
            --bg-color: #f0f4f8;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-color);
            background-image: radial-gradient(#6f42c1 0.5px, transparent 0.5px), radial-gradient(#6f42c1 0.5px, var(--bg-color) 0.5px);
            background-size: 20px 20px;
            background-position: 0 0, 10px 10px;
            min-height: 100vh;
        }

        .text-muted { color: #718096 !important; }

        /* 🎯 Page Header */
        .page-header {
            background: var(--purple-gradient);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(111, 66, 193, 0.3);
        }
        .page-header h1 { font-weight: 800; margin: 0; font-size: 2rem; }
        .page-header p  { margin: 0.5rem 0 0 0; opacity: 0.9; }
        .page-header .id-chip {
            display: inline-block;
            background: rgba(255, 255, 255, 0.18);
            border: 1px solid rgba(255, 255, 255, 0.35);
            padding: 0.3rem 0.9rem;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            margin-top: 0.6rem;
        }

        .btn-modern {
            border-radius: 12px;
            padding: 0.6rem 1.25rem;
            font-weight: 600;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            text-decoration: none;
        }
        .btn-ghost {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.4);
            backdrop-filter: blur(4px);
        }
        .btn-ghost:hover { background: rgba(255, 255, 255, 0.25); color: white; }

        /* 🎯 Card statis — TANPA hover */
        .card-modern {
            background: white;
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .card-header-modern {
            background: linear-gradient(135deg, rgba(111, 66, 193, 0.1) 0%, rgba(155, 93, 229, 0.1) 100%);
            border-bottom: 2px solid rgba(111, 66, 193, 0.12);
            padding: 1.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .card-header-modern.success {
            background: linear-gradient(135deg, rgba(17, 153, 142, 0.1) 0%, rgba(56, 239, 125, 0.1) 100%);
            border-bottom-color: rgba(17, 153, 142, 0.2);
        }
        .card-header-modern h5 {
            margin: 0;
            font-weight: 700;
            color: #2d3748;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }
        .card-header-modern h5 i {
            font-size: 1.5rem;
            background: var(--purple-gradient);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .card-header-modern.success h5 i {
            background: var(--success-gradient);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }

        .count-badge {
            background: rgba(111, 66, 193, 0.12);
            color: var(--purple-color);
            font-weight: 700;
            font-size: 0.78rem;
            padding: 0.45rem 0.9rem;
            border-radius: 20px;
        }

        /* 🎯 Info tiles (rangkuman) */
        .info-tile {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 15px;
            padding: 1.1rem 1.25rem;
            height: 100%;
        }
        .info-tile .label {
            color: #718096;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.72rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            margin-bottom: 0.5rem;
        }
        .info-tile .label i { color: #9b5de5; }
        .info-tile .value {
            font-weight: 700;
            color: #2d3748;
            font-size: 0.98rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .code-badge {
            background: rgba(111, 66, 193, 0.1);
            color: var(--purple-color);
            font-weight: 800;
            padding: 0.35rem 0.8rem;
            border-radius: 10px;
            font-size: 0.92rem;
            letter-spacing: 0.5px;
        }

        .avatar {
            width: 34px; height: 34px; border-radius: 50%;
            background: var(--purple-gradient);
            color: white; font-weight: 700; font-size: 0.85rem;
            display: inline-flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }

        /* 🎯 Tabel modern */
        .table-modern { width: 100%; border-collapse: separate; border-spacing: 0; }
        .table-modern thead th {
            background: linear-gradient(135deg, rgba(111, 66, 193, 0.05) 0%, rgba(155, 93, 229, 0.05) 100%);
            border-bottom: 2px solid #e2e8f0;
            padding: 1rem 1.25rem;
            font-weight: 700;
            color: #2d3748;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        .table-modern tbody td {
            padding: 1.1rem 1.25rem;
            border-bottom: 1px solid #f0f4f8;
            vertical-align: middle;
            color: #4a5568;
        }
        .table-modern tbody tr:hover { background: rgba(111, 66, 193, 0.03); }
        .table-modern tbody tr:last-child td { border-bottom: none; }

        .table-modern tfoot td {
            background: linear-gradient(135deg, rgba(111, 66, 193, 0.08) 0%, rgba(155, 93, 229, 0.08) 100%);
            border-top: 2px solid rgba(111, 66, 193, 0.2);
            padding: 1.1rem 1.25rem;
            font-weight: 800;
            color: #2d3748;
        }
        .total-value {
            color: var(--purple-color);
            font-size: 1.1rem;
            font-weight: 800;
        }

        .row-num {
            width: 28px; height: 28px; border-radius: 50%;
            background: rgba(111, 66, 193, 0.1);
            color: var(--purple-color);
            font-weight: 700; font-size: 0.82rem;
            display: inline-flex; align-items: center; justify-content: center;
        }

        .category-chip {
            background: rgba(155, 93, 229, 0.1);
            color: var(--purple-color);
            font-weight: 600;
            padding: 0.4rem 0.85rem;
            border-radius: 20px;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }

        .nominal-cell { font-weight: 700; color: #2d3748; white-space: nowrap; }

        /* 🎯 Empty state */
        .empty-state { text-align: center; padding: 3.5rem 1rem; }
        .empty-state .icon-circle {
            width: 80px; height: 80px; border-radius: 50%;
            background: linear-gradient(135deg, rgba(111, 66, 193, 0.12), rgba(155, 93, 229, 0.12));
            display: inline-flex; align-items: center; justify-content: center;
            margin-bottom: 1rem;
        }
        .empty-state .icon-circle i {
            font-size: 2.2rem;
            background: var(--purple-gradient);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .empty-state h6 { font-weight: 700; color: #2d3748; }

        /* 🎯 Form inputs */
        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 0.7rem 1rem;
            font-size: 0.95rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--purple-color);
            box-shadow: 0 0 0 4px rgba(111, 66, 193, 0.1);
        }

        .btn-success-modern {
            background: var(--success-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
            transition: all 0.3s ease;
        }
        .btn-success-modern:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(17, 153, 142, 0.5); color: white; }

        .btn-danger-modern {
            background: var(--danger-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(238, 9, 121, 0.4);
            transition: all 0.3s ease;
        }
        .btn-danger-modern:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(238, 9, 121, 0.5); color: white; }

        .btn-icon {
            width: 40px; height: 40px; border-radius: 10px;
            display: inline-flex; align-items: center; justify-content: center; padding: 0;
        }

        /* 🎯 Tombol submit utama — statis, TANPA hover */
        .btn-submit-success {
            background: var(--success-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
            border-radius: 15px;
            font-weight: 700;
            letter-spacing: 0.3px;
            border: none;
        }
        .btn-submit-success:hover, .btn-submit-success:focus, .btn-submit-success:active {
            background: var(--success-gradient);
            color: white;
            transform: none;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
        }

        .alert-custom {
            border-radius: 15px; border: none;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
        }

        .info-box {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            border-left: 4px solid #667eea;
            border-radius: 12px;
            padding: 1rem 1.5rem;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .animate-slide-in { animation: slideIn 0.5s ease; }

        @media (max-width: 768px) {
            .page-header h1 { font-size: 1.5rem; }
            .card-header-modern { flex-direction: column; align-items: flex-start; }
        }
    </style>
    @include('partials.mobile-assets')
</head>
<body>
    @include('partials.application-time')
    @php
    $isPeriodClosed = !app(\App\Services\PeriodService::class)->isOpen($transaksi->periode);
    $isDraft = $transaksi->status === 'DRAFT' && auth()->user()->canAccessTransaction($transaksi);
    $isEditMode = $isDraft && !$isPeriodClosed && (request('edit') == 1 || old('_transaction_edit') === $transaksi->transaksi_id);
@endphp

<!-- PAGE HEADER (Tambahkan tombol Edit di pojok kanan atas) -->
<div class="page-header">
    <div class="container" style="max-width: 1000px;">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1><i class="bi bi-receipt me-3"></i>Detail Nota Operasional</h1>
                <p class="mb-0">Rangkuman nota & mutasi pengeluaran item biaya</p>
                <span class="id-chip"><i class="bi bi-hash me-1"></i>{{ $transaksi->transaksi_id }}</span>
                
                @if($isEditMode)
                    <span class="id-chip" style="background: rgba(13, 110, 253, 0.2); border-color: rgba(13, 110, 253, 0.4); color: #0d6efd;">
                        <i class="bi bi-pencil-square me-1"></i> MODE EDIT
                    </span>
                @elseif($transaksi->status === 'DRAFT')
                    <span class="id-chip" style="background: rgba(255, 193, 7, 0.2); border-color: rgba(255, 193, 7, 0.4); color: #ffc107;">
                        <i class="bi bi-file-earmark-text me-1"></i> DRAFT
                    </span>
                @else
                    <span class="id-chip" style="background: rgba(25, 135, 84, 0.2); border-color: rgba(25, 135, 84, 0.4); color: #198754;">
                        <i class="bi bi-check-circle-fill me-1"></i> Dikonfirmasi
                    </span>
                @endif
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0 d-flex justify-content-lg-end gap-2 flex-wrap">
                {{-- 🎯 TOMBOL EDIT --}}
                @if($isDraft && !$isPeriodClosed && !$isEditMode)
                    <a href="{{ route('transaksi_operasional.show', $transaksi->id) }}?edit=1" class="btn btn-modern" style="background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4);">
                        <i class="bi bi-pencil-square"></i> Edit Transaksi
                    </a>
                @endif
                <a href="{{ route('transaksi_operasional.index') }}" class="btn btn-ghost btn-modern">
                    <i class="bi bi-arrow-left"></i> Kembali ke Daftar
                </a>
            </div>
        </div>
    </div>
</div>

    <div class="container" style="max-width: 1000px; margin-bottom: 3rem;">
        @include('partials.finance-correction-notice', ['financeSourceType' => 'OPR'])
        
        @if(session('success'))
            <div class="alert alert-success alert-custom alert-dismissible fade show mb-4">
                <div class="d-flex align-items-center">
                    <i class="bi bi-check-circle-fill me-3 fs-4"></i>
                    <div><strong>Berhasil!</strong> {{ session('success') }}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if($errors->any())
            <div class="alert alert-danger alert-custom alert-dismissible fade show mb-4">
                <div class="d-flex align-items-center">
                    <i class="bi bi-exclamation-circle-fill me-3 fs-4"></i>
                    <div>
                        <strong>Gagal:</strong>
                        <ul class="mb-0 mt-2">
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if(!$isEditMode)
        <div id="view-mode">
        <!-- 🎯 CARD 1: RANGKUMAN NOTA -->
        <div class="card-modern animate-slide-in">
            <div class="card-header-modern">
                <h5>
                    <i class="bi bi-pin-map"></i> Rangkuman Nota Operasional Sales
                    <span class="count-badge">{{ $transaksi->details->count() }} Item Biaya</span>
                </h5>
            </div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="info-tile">
                            <div class="label"><i class="bi bi-hash"></i>ID Transaksi</div>
                            <div class="value"><span class="code-badge">{{ $transaksi->transaksi_id }}</span></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-tile">
                            <div class="label"><i class="bi bi-calendar-event"></i>Tanggal Transaksi</div>
                            <div class="value"><i class="bi bi-calendar3 text-muted"></i>{{ \Carbon\Carbon::parse($transaksi->tanggal)->format('d F Y') }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-tile">
                            <div class="label"><i class="bi bi-person-badge"></i>Sales Terkait</div>
                            <div class="value">
                                <span class="avatar">{{ strtoupper(substr($transaksi->user->name ?? $transaksi->user->nama ?? '-', 0, 1)) }}</span>
                                {{ $transaksi->user->name ?? $transaksi->user->nama ?? '-' }}
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-tile">
                            <div class="label"><i class="bi bi-wallet2"></i>Pemilik Saldo BS</div>
                            <div class="value">
                                @if($transaksi->bsCashOwnerId())
                                    <span class="code-badge">{{ $transaksi->bsOwner?->nama ?? $transaksi->bonSementara?->user?->nama ?? '-' }}</span>
                                @else
                                    <span class="text-muted">Arsip tanpa BS</span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-tile">
                            <div class="label"><i class="bi bi-chat-left-text"></i>Keterangan Umum</div>
                            <div class="value">{{ $transaksi->description ?? '-' }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 🎯 CARD 2: MUTASI PENGELUARAN -->
        <div class="card-modern animate-slide-in" style="animation-delay: 0.1s">
            <div class="card-header-modern">
                <h5><i class="bi bi-bar-chart-line"></i> Mutasi Pengeluaran Item Biaya</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table-modern">
                        <thead>
                            <tr>
                                <th width="8%" class="text-center">No.</th>
                                <th width="30%"><i class="bi bi-tag me-2"></i>Kategori Biaya</th>
                                <th width="40%"><i class="bi bi-chat-left-text me-2"></i>Keterangan Item (Remark)</th>
                                <th width="22%" class="text-end"><i class="bi bi-currency-dollar me-2"></i>Nominal Pengeluaran</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $totalKeseluruhan = 0; @endphp
                            
                            @forelse($transaksi->details as $index => $detail)
                                @php $totalKeseluruhan += $detail->nominal; @endphp
                                <tr>
                                    <td class="text-center"><span class="row-num">{{ $index + 1 }}</span></td>
                                    <td>
                                        <span class="category-chip">
                                            <i class="bi bi-tag-fill"></i>
                                            {{ $detail->costCategory->nama ?? $detail->costCategory->nama ?? 'Kategori #'.$detail->cost_category_id }}
                                        </span>
                                    </td>
                                    <td>{{ $detail->remark }}</td>
                                    <td class="text-end nominal-cell">Rp {{ number_format($detail->nominal, 0, ',', '.') }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4">
                                        <div class="empty-state">
                                            <div class="icon-circle"><i class="bi bi-inbox"></i></div>
                                            <h6>Rincian item biaya kosong</h6>
                                            <p class="text-muted mb-0">
                                                @if($transaksi->status === 'DRAFT')
                                                    Klik Edit Transaksi untuk menambahkan rincian biaya.
                                                @else
                                                    Tidak ada rincian biaya pada transaksi ini.
                                                @endif
                                            </p>
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                        @if($totalKeseluruhan > 0)
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end">TOTAL KESELURUHAN NOTA :</td>
                                <td class="text-end"><span class="total-value">Rp {{ number_format($totalKeseluruhan, 0, ',', '.') }}</span></td>
                            </tr>
                        </tfoot>
                        @endif
                    </table>
                </div>
            </div>
        </div>

        </div>
        @endif

        <!-- 🎯 CARD 3 & 4: FORM TAMBAH RINCIAN & KONFIRMASI (Hanya untuk DRAFT) -->
        @php
            $isPeriodClosed = !app(\App\Services\PeriodService::class)->isOpen($transaksi->periode);
            $isDraft = $transaksi->status === 'DRAFT' && auth()->user()->canAccessTransaction($transaksi);
        @endphp

       @include('partials.bs-finance-check-status', ['transaction' => $transaksi, 'jenis' => 'OPR'])
       @if($isDraft && !$isPeriodClosed)
    
    @if($isEditMode)
        {{-- ================= MODE EDIT ================= --}}
        <form action="{{ route('transaksi_operasional.update', $transaksi->id) }}" method="POST" id="form-edit-operasional" data-transaction-editor="operational">
            @csrf
            @method('PUT')
            <input type="hidden" name="_transaction_edit" value="{{ $transaksi->transaksi_id }}">

            {{-- Card Edit Header --}}
            <div class="card-modern animate-slide-in">
                <div class="card-header-modern success">
                    <h5><i class="bi bi-pencil-square"></i> Edit Informasi Utama</h5>
                    <div class="d-flex gap-2">
                        <a href="{{ route('transaksi_operasional.show', $transaksi->id) }}" class="btn btn-modern" style="background: #f0f4f8; color: #4a5568;">
                            <i class="bi bi-x-lg"></i> Batal
                        </a>
                        <button type="submit" class="btn btn-success-modern btn-modern">
                            <i class="bi bi-check-lg"></i> Simpan Perubahan
                        </button>
                    </div>
                </div>
                <div class="card-body p-4">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-bold text-muted">Tanggal Transaksi</label>
                            <input type="date" name="tanggal" value="{{ old('tanggal', \Carbon\Carbon::parse($transaksi->tanggal)->format('Y-m-d')) }}" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            @include('partials.transaction-funding', ['fundingType' => 'operasional_sales', 'fundingDocument' => $transaksi])
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold text-muted">Deskripsi Kegiatan</label>
                            <input type="text" name="description" value="{{ old('description', $transaksi->description) }}" class="form-control" maxlength="255" placeholder="Masukkan deskripsi...">
                        </div>
                    </div>
                </div>
            </div>

            @include('partials.transaction-edit-details', ['requireRemark' => true, 'cancelUrl' => route('transaksi_operasional.show', $transaksi->id)])
        </form>

    @else
        {{-- ================= MODE VIEW NORMAL (Kode Asli Anda) ================= --}}
        <div class="card-modern animate-slide-in" style="animation-delay: 0.3s">
            <div class="card-header-modern" style="background: linear-gradient(135deg, rgba(17, 153, 142, 0.15) 0%, rgba(56, 239, 125, 0.15) 100%); border-bottom-color: rgba(17, 153, 142, 0.3);">
                <h5 style="color: #11998e;"><i class="bi bi-check-circle"></i> Konfirmasi Transaksi</h5>
            </div>
            <div class="card-body p-4">
                <div class="info-box mb-3">
                    <i class="bi bi-info-circle me-2 text-primary"></i>
                    <small class="text-muted">
                        <strong>Perhatian:</strong> Konfirmasi mengunci transaksi untuk diperiksa Finance. Saldo BS berkurang sesuai nominal yang dikonfirmasi Finance. Transaksi final tidak dapat diedit atau dihapus.
                    </small>
                </div>
                <form action="{{ route('transaksi_operasional.validate', $transaksi->id) }}" method="POST">
                    @csrf
                    <div class="d-grid">
                        <button type="submit" class="btn btn-submit-success btn-lg py-3"
                                onclick="return confirm('Konfirmasi transaksi ini? Pemakaian BS akan dibukukan. Transaksi final tidak dapat diedit atau dihapus.')">
                            <i class="bi bi-check-circle-fill me-2 fs-5"></i> Konfirmasi
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif

@elseif($isDraft && $isPeriodClosed)
    {{-- TAMPILAN: DRAFT tapi Periode Sudah CLOSED --}}
    <div class="card-modern animate-slide-in" style="animation-delay: 0.2s">
        <div class="card-header-modern" style="background: linear-gradient(135deg, rgba(238, 9, 121, 0.1) 0%, rgba(255, 106, 0, 0.1) 100%); border-bottom-color: rgba(238, 9, 121, 0.2);">
            <h5 style="color: #ee0979;"><i class="bi bi-lock-fill"></i> Periode Sudah Di-Close</h5>
        </div>
        <div class="card-body p-4 text-center">
            <p class="text-muted mb-3">
                Draft transaksi ini <strong>tidak dapat diedit maupun dikonfirmasi</strong> karena periode 
                <span class="code-badge" style="background: rgba(238, 9, 121, 0.1); color: #ee0979;">{{ $transaksi->periode }}</span> 
                sudah di-close oleh Finance.
            </p>
        </div>
    </div>

@else
    {{-- TAMPILAN: SUDAH VALIDATED --}}
    <div class="card-modern animate-slide-in" style="animation-delay: 0.2s">
        <div class="card-header-modern" style="background: linear-gradient(135deg, rgba(25, 135, 84, 0.1) 0%, rgba(32, 168, 107, 0.1) 100%); border-bottom-color: rgba(25, 135, 84, 0.2);">
            <h5 style="color: #198754;"><i class="bi bi-lock-fill"></i> Transaksi Sudah Dikonfirmasi</h5>
        </div>
        <div class="card-body p-4 text-center">
            <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, rgba(25, 135, 84, 0.1), rgba(32, 168, 107, 0.1)); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 1rem;">
                <i class="bi bi-check-circle-fill" style="font-size: 2.5rem; color: #198754;"></i>
            </div>
            <p class="text-muted mb-2">Waktu Konfirmasi: <strong>{{ \App\Support\AppTime::format($transaksi->validated_at) }}</strong></p>
            <p class="text-muted mb-0">
                Transaksi ini <strong>sudah dikonfirmasi</strong>. {{ $transaksi->bsCashOwnerId() ? 'Pengurangan saldo BS mengikuti hasil konfirmasi Finance terakhir.' : 'Arsip tanpa BS.' }}
                Tidak ada perubahan yang dapat dilakukan lagi.
            </p>
        </div>
    </div>
@endif
    </div>

    <script src="{{ asset('js/transaction-editor.js') }}?v={{ filemtime(public_path('js/transaction-editor.js')) }}" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

~~~~

## app/Http/Controllers/TransaksiOperasionalController.php

Validasi, simpan, edit, tambah rincian, dan hapus transaksi Operasional.

~~~~php
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TransaksiOperasionalHeader; 
use App\Models\TransaksiOperasionalDetail; 
use App\Models\User;
use App\Models\CostCategory;

use App\Services\BonSementaraService; 
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth; 
use App\Traits\FiltersByPeriod;
use App\Services\PeriodService;
use App\Services\DocumentNumberService;
use Carbon\Carbon;

class TransaksiOperasionalController extends Controller
{
    use FiltersByPeriod;

    public function create()
    {
        $cost_categories = CostCategory::all();
        
        // 🎯 LOGIC: Ambil daftar bulan yang statusnya OPEN
        $dbPeriods = \App\Models\Periode::pluck('status', 'periode')->toArray(); // Sesuaikan 'period' jika nama kolom Anda 'periode'
        $currentMonth = \App\Support\AppTime::now()->format('Y-m');
        
        $openPeriods = [];
        foreach ($dbPeriods as $periode => $status) {
            if ($status === 'OPEN') {
                $openPeriods[] = $periode;
            }
        }
        
        // 🎯 Jika bulan saat ini belum ada record di database, default-nya dianggap OPEN
        if (!isset($dbPeriods[$currentMonth])) {
            $openPeriods[] = $currentMonth;
        }

        $usedDates = TransaksiOperasionalHeader::where('user_id', Auth::id())
            ->distinct()
            ->orderBy('tanggal')
            ->pluck('tanggal')
            ->all();

        return view('transaksi_operasional.create', compact('cost_categories', 'openPeriods', 'usedDates'));
    }
public function store(Request $request, BonSementaraService $bsService)
{
    // 1. Validasi Input Dasar
    $request->validate([
        'save_action' => 'sometimes|required|in:draft,confirm',
        'tanggal' => 'required|date',
        'description' => 'nullable|string|max:255',
        ...\App\Services\TransactionFundingService::rules(),
        'details' => 'required|array|min:1',
        'details.*.cost_category_id' => 'required|exists:cost_category,id',
        'details.*.remark' => 'required|string|max:255',
        'details.*.nominal' => 'required|numeric|decimal:0,2|min:0|max:9999999999999.99',
    ]);

    // 2. Validasi Periode (Pastikan periode OPEN)
    app(PeriodService::class)->assertOpen(substr($request->input('tanggal'), 0, 7));

    $activeUserId = Auth::id();

    // 3. 🎯 VALIDASI E2: 1 Transaksi per Tanggal per User (STRICT REJECT)
    $headerAda = TransaksiOperasionalHeader::where('tanggal', $request->tanggal)
                                           ->where('user_id', $activeUserId) 
                                           ->first();

    if ($headerAda) {
        return back()->withErrors([
            'tanggal' => 'Anda sudah memiliki transaksi Operasional Area Sales pada tanggal ' . $request->tanggal . '. Silakan buka transaksi yang sudah ada (ID: ' . $headerAda->transaksi_id . ') untuk menambahkan detail biaya.'
        ])->withInput();
    }
// 4. 🎯 VALIDASI BS (BON SEMENTARA)
$bsOwnerId = app(\App\Services\TransactionFundingService::class)->resolve($request, false);

    // 🎯 CATATAN: Validasi saldo BS TIDAK dilakukan saat draft
    // Saldo diperiksa saat konfirmasi, termasuk Simpan & Konfirmasi.

    try {
        DB::beginTransaction();

        $transaksi_id = app(DocumentNumberService::class)->next('OAS', $request->tanggal);
        
        $header = TransaksiOperasionalHeader::create([
            'transaksi_id' => $transaksi_id,
            'tanggal'      => $request->tanggal,
            'user_id'      => $activeUserId,
            'bs_owner_id' => $bsOwnerId,
            'periode'      => substr($request->tanggal, 0, 7), 
            'description'  => $request->description ?: null,
            'status'       => 'DRAFT', // 🎯 SIMPAN SEBAGAI DRAFT
        ]);

        foreach ($request->details as $detail) {
            TransaksiOperasionalDetail::create([
                'transaksi_id'     => $transaksi_id,
                'cost_category_id' => $detail['cost_category_id'],
                'remark'           => $detail['remark'],
                'nominal'          => $detail['nominal'],
            ]);
        }
        
        $confirm = $request->input('save_action', 'draft') === 'confirm';
        if ($confirm) {
            app(\App\Services\BsValidationService::class)->finalize($header);
        }

        DB::commit();
        
        return redirect()->route('transaksi_operasional.index')
            ->with('success', $confirm
                ? 'Transaksi Operasional (' . $transaksi_id . ') dikonfirmasi dan siap diperiksa Finance. Saldo BS berkurang setelah konfirmasi Finance.'
                : 'Draft Transaksi Operasional (' . $transaksi_id . ') berhasil disimpan. Klik Konfirmasi untuk mengirim pengajuan ke Finance.');

    } catch (\Illuminate\Validation\ValidationException $e) {
        DB::rollBack();
        return redirect()->back()->withErrors($e->errors())->withInput();
    } catch (\Exception $e) {
        DB::rollback();
        return redirect()->back()->withErrors(['error' => 'Transaksi Gagal: ' . $e->getMessage()])->withInput();
    }
}

   public function show($id)
{
    $transaksi = TransaksiOperasionalHeader::with(['user', 'details', 'bonSementara', 'bsOwner'])->withExists('financeChecks')->findOrFail($id);

    if (!auth()->user()->canViewBsTransaction($transaksi)) {
        abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
    }

    $cost_categories = CostCategory::all();
    
    // 🎯 TAMBAHKAN INI: Ambil list BS untuk dropdown edit


    return view('transaksi_operasional.show', compact('transaksi', 'cost_categories'));
}


// 🎯 METHOD BARU: UPDATE TRANSAKSI (MODE EDIT)
public function update(Request $request, $id)
{
    $transaksi = TransaksiOperasionalHeader::with('details')->findOrFail($id);

    // 1. Cek Authorization
    if (!auth()->user()->canAccessTransaction($transaksi)) {
        abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
    }

    // 2. Cek Status
    if ($transaksi->status !== 'DRAFT') {
        return back()->withErrors(['error' => 'Hanya transaksi dengan status DRAFT yang dapat diedit.']);
    }

    // 4. Validasi Input
    $request->validate([
        'tanggal' => 'required|date',
        'description' => 'nullable|string|max:255',
        ...\App\Services\TransactionFundingService::rules(),
        'details' => 'nullable|array',
        'details.*.cost_category_id' => 'required_with:details|exists:cost_category,id',
        'details.*.remark' => 'required_with:details|string|max:255',
        'details.*.nominal' => 'required_with:details|numeric|decimal:0,2|min:0|max:9999999999999.99',
        'new_details' => 'nullable|array',
        'new_details.*.cost_category_id' => 'required_with:new_details|exists:cost_category,id',
        'new_details.*.remark' => 'required_with:new_details|string|max:255',
        'new_details.*.nominal' => 'required_with:new_details|numeric|decimal:0,2|min:0|max:9999999999999.99',
        'delete_details' => 'nullable|array',
        'delete_details.*' => 'integer|distinct',
    ]);

    app(PeriodService::class)->assertOpen($transaksi->periode);
    app(PeriodService::class)->assertOpen(\Carbon\Carbon::parse($request->tanggal)->format('Y-m'));

    // Periksa hak penggunaan saldo sebelum mengubah draft.
    $bsOwnerId = app(\App\Services\TransactionFundingService::class)->resolve($request, false, $transaksi);

    // 6. Cek Duplikasi Tanggal (Kecuali transaksi ini sendiri)
    $headerAda = TransaksiOperasionalHeader::where('tanggal', $request->tanggal)
        ->where('user_id', $transaksi->user_id)
        ->where('id', '!=', $transaksi->id)
        ->first();
    if ($headerAda) {
        return back()->withErrors(['tanggal' => 'Anda sudah memiliki transaksi pada tanggal ' . $request->tanggal . ' (ID: ' . $headerAda->transaksi_id . ').'])->withInput();
    }

    DB::beginTransaction();
    try {
        // A. Update Header
        $transaksi->update([
            'tanggal' => $request->tanggal,
            'bs_owner_id' => $bsOwnerId,
            'periode' => substr($request->tanggal, 0, 7),
            'description' => $request->description ?: null,
        ]);

        // B. Update Existing Details
        if ($request->has('details')) {
            foreach ($request->details as $detailId => $data) {
                $detail = TransaksiOperasionalDetail::find($detailId);
                if ($detail && $detail->transaksi_id == $transaksi->transaksi_id) {
                    $detail->update([
                        'cost_category_id' => $data['cost_category_id'],
                        'remark' => $data['remark'],
                        'nominal' => $data['nominal'],
                    ]);
                }
            }
        }

        // C. Hapus Details yang ditandai (dicoret di UI)
        if ($request->has('delete_details') && is_array($request->delete_details)) {
            TransaksiOperasionalDetail::whereIn('id', $request->delete_details)
                ->where('transaksi_id', $transaksi->transaksi_id)
                ->delete();
        }

        // D. Tambah New Details (baris baru yang ditambah saat edit)
        if ($request->has('new_details')) {
            foreach ($request->new_details as $data) {
                TransaksiOperasionalDetail::create([
                    'transaksi_id' => $transaksi->transaksi_id,
                    'cost_category_id' => $data['cost_category_id'],
                    'remark' => $data['remark'],
                    'nominal' => $data['nominal'],
                ]);
            }
        }

        DB::commit();
        // 🎯 Kembali ke halaman detail (Mode View) setelah berhasil
        return redirect()->route('transaksi_operasional.show', $transaksi->id)->with('success', 'Transaksi berhasil diperbarui!');
    } catch (\Exception $e) {
        DB::rollBack();
        return back()->withErrors(['error' => 'Gagal memperbarui transaksi: ' . $e->getMessage()])->withInput();
    }
}


    /**
 * 🎯 VALIDATE: Mengubah status DRAFT menjadi VALIDATED dan trigger cash flow
 */
    public function validateTransaction($id)
    {
        $transaksi = TransaksiOperasionalHeader::findOrFail($id);
        app(\App\Services\BsValidationService::class)->finalize($transaksi);
        return redirect()->route('transaksi_operasional.show', $transaksi->id)
            ->with('success', 'Transaksi dikonfirmasi dan siap diperiksa Finance. Saldo BS berkurang setelah konfirmasi Finance.');
    }



       public function storeDetail(Request $request, $id, BonSementaraService $bsService)
{
    $request->validate([
        'details' => 'required|array|min:1',
        'details.*.cost_category_id' => 'required|exists:cost_category,id',
        'details.*.remark' => 'required|string|max:255',
        'details.*.nominal' => 'required|numeric|decimal:0,2|min:0|max:9999999999999.99',
    ]);

    $header = TransaksiOperasionalHeader::findOrFail($id);

    // 🎯 GUARD: Hanya bisa tambah detail jika masih DRAFT
    if ($header->status !== 'DRAFT') {
        return back()->withErrors(['error' => 'Tidak dapat menambah rincian. Transaksi sudah dikonfirmasi.']);
    }

    // 🎯 VALIDASI PERIODE: Pastikan periode transaksi TIDAK di-close
    app(PeriodService::class)->assertOpen($header->periode);

    try {
        DB::beginTransaction();

        if (!auth()->user()->canAccessTransaction($header)) {
            abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
        }

        // 🎯 CATATAN: Validasi saldo BS TIDAK dilakukan saat tambah detail draft
        // Validasi saldo dilakukan saat VALIDATE

        foreach ($request->details as $detail) {
            TransaksiOperasionalDetail::create([
                'transaksi_id'     => $header->transaksi_id,
                'cost_category_id' => $detail['cost_category_id'],
                'remark'           => $detail['remark'],
                'nominal'          => $detail['nominal'],
            ]);
        }

        DB::commit();
        
        // 🎯 JANGAN TRIGGER CASH FLOW SAAT TAMBAH DETAIL DRAFT!
        
        return redirect()->back()->with('success', 'Rincian biaya berhasil ditambahkan ke Draft Transaksi (' . $header->transaksi_id . '). Klik "Konfirmasi" untuk mengirim pengajuan ke Finance.');

    } catch (\Exception $e) {
        DB::rollback();
        return redirect()->back()->withErrors(['error' => 'Gagal Menambah Rincian: ' . $e->getMessage()]);
    }
}
    public function index(Request $request)
    {
        $periode = $request->query('periode');

        $query = TransaksiOperasionalHeader::with('user')->withExists('financeChecks')->orderBy('tanggal', 'desc');

        if (!auth()->user()->canSeeAllTransactions()) {
            $query->visibleTo(auth()->user());
        }

        $this->filterPeriod($query, $periode);

        $transaksis = $query->paginate(10)->withQueryString();

        return view('transaksi_operasional.index', compact('transaksis', 'periode'));
    }

   public function destroy($id)
{
    $transaksi = TransaksiOperasionalHeader::with('bonSementara', 'details')->findOrFail($id);

    if (!auth()->user()->canAccessTransaction($transaksi)) {
        abort(403, 'Anda tidak memiliki akses ke transaksi ini.');
    }

    // 🎯 GUARD: Hanya bisa hapus jika masih DRAFT
    if ($transaksi->status !== 'DRAFT') {
        return back()->withErrors(['error' => 'Tidak dapat menghapus transaksi yang sudah dikonfirmasi.']);
    }

    // Simpan data SEBELUM delete
    $periode = $transaksi->periode;

    DB::beginTransaction();

    try {
        $transaksi->details()->delete();
        $transaksi->delete();

        DB::commit();

        // 🎯 JANGAN TRIGGER CASH FLOW SAAT HAPUS DRAFT!
        // Karena draft tidak pernah mempengaruhi cash flow
        
        return redirect()->route('transaksi_operasional.index')
            ->with('success', 'Draft Transaksi Operasional berhasil dihapus!');

    } catch (\Exception $e) {
        DB::rollBack();
        return redirect()->back()
            ->withErrors(['error' => 'Gagal menghapus transaksi: ' . $e->getMessage()]);
    }
}
    public function export(Request $request)
    {
        $periode = $request->filled('periode') ? app(\App\Services\PeriodService::class)->normalize($request->query('periode')) : null;

        $query = TransaksiOperasionalHeader::with(['user', 'details', 'bonSementara', 'bsOwner']);
        if (!auth()->user()->canSeeAllTransactions()) {
            $query->visibleTo(auth()->user());
        }
        if ($periode) $query->where('periode', $periode);

        $headers = $query->where('status', 'VALIDATED')->orderBy('tanggal')->get();
        $categories = \App\Models\CostCategory::pluck('nama', 'id');

        $headings = ['Transaksi ID', 'Tanggal', 'Periode', 'User', 'Pemilik Saldo BS', 'Cost Category', 'Remark', 'Nominal'];
        $rows = [];
        $total = 0;

        foreach ($headers as $h) {
            foreach ($h->details as $d) {
                $total += (float) $d->nominal;
                $rows[] = [
                    $h->transaksi_id,
                    \Carbon\Carbon::parse($h->tanggal)->format('d/m/Y'),
                    str_replace('-', '', $h->periode ?? ''),
                    $h->user->nama ?? '',
                    $h->bsOwner?->nama ?? $h->bonSementara?->user?->nama ?? 'Arsip tanpa BS',
                    $categories[$d->cost_category_id] ?? '',
                    $d->remark,
                    (float) $d->nominal,
                ];
            }
        }
        $rows[] = ['TOTAL', '', '', '', '', '', '', (float) $total];

        return \Maatwebsite\Excel\Facades\Excel::download(
            new \App\Exports\LaporanTableExport($headings, $rows, ['H']),
            'laporan-operasional-sales-' . ($periode ?: 'semua-periode') . '.xlsx'
        );
    }
}

~~~~

## app/Models/TransaksiOperasionalDetail.php

Model tabel transaksi_operasional_area_sales_detail; penyimpanan metadata foto per item.

~~~~php
<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TransaksiOperasionalDetail extends Model
{
    //

    use HasFactory;

    protected $table = 'transaksi_operasional_area_sales_detail';

    public $timestamps = false;

    protected $fillable = [
        'transaksi_id',
        'cost_category_id',
        'remark',
        'nominal'
    ];


    // Relasi ke Header

    public function header()
    {
        return $this->belongsTo(TransaksiOperasionalHeader::class, 'transaksi_id', 'transaksi_id');
    }

    public function costCategory()
    {
        return $this->belongsTo(CostCategory::class, 'cost_category_id', 'id');
    }


}

~~~~

## app/Models/TransaksiOperasionalHeader.php

Relasi details dan identitas transaksi induk.

~~~~php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TransaksiOperasionalHeader extends Model
{
    use HasFactory, \App\Models\Concerns\UsesBsBalance;

    protected $table = 'transaksi_operasional_area_sales_header';
    public $timestamps = false;

    protected $casts = ['validated_at' => 'datetime'];

    // 🎯 PERBAIKAN 3: Tambahkan 'bs_id' agar bisa di-save via create() / update()
    protected $fillable = [
        'validated_at', 'validated_by', 'bs_owner_id',
        'transaksi_id',
        'tanggal',
        'user_id',
        'bs_id', 
        'periode',
        'description',
        'status', // 🎯 TAMBAHKAN INI
    ];

    public function details()
    {
        return $this->hasMany(TransaksiOperasionalDetail::class, 'transaksi_id', 'transaksi_id');
    }

    public function financeChecks()
    {
        return $this->hasMany(BsUsageCheck::class, 'transaksi_pemakaian_id')->where('jenis_transaksi', 'OPR');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function bonSementara() {
        return $this->belongsTo(PengajuanBs::class, 'bs_id');
    }
}

~~~~
