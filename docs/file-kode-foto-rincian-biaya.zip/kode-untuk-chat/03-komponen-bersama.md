# Komponen bersama, penyimpanan, dan akses

Salinan kode saat pemetaan 8 Oktober 2026. Fitur foto per rincian belum diimplementasikan.

## resources/views/partials/transaction-edit-details.blade.php

Header tabel edit, rincian lama, rincian baru, dan template penambahan baris.

~~~~php
@php
    $deletedIds = array_map('strval', old('delete_details', []));
    $newDetails = old('new_details', []);
@endphp
<div class="card-modern">
    <div class="card-header-modern">
        <h5><i class="bi bi-list-ul me-2"></i>Edit Rincian Biaya</h5>
        <button type="button" class="btn btn-success" data-add-expense>Tambah Rincian Biaya</button>
    </div>
    <div class="card-body p-0">
        <p class="text-muted small p-3 mb-0">Ubah, tambah, atau tandai rincian untuk dihapus. Semua perubahan disimpan setelah Anda menekan Simpan Perubahan.</p>
        <div class="table-responsive">
            <table class="table-modern" data-mobile-entry>
                <thead><tr><th>Kategori Biaya</th><th>Keterangan</th><th>Nominal (Rp)</th><th>Aksi</th></tr></thead>
                <tbody data-expense-rows>
                    @foreach($transaksi->details as $detail)
                        @include('partials.transaction-edit-row', [
                            'prefix' => 'details['.$detail->id.']', 'existingId' => $detail->id,
                            'values' => old('details.'.$detail->id, $detail->toArray()),
                            'deleted' => in_array((string) $detail->id, $deletedIds, true),
                        ])
                    @endforeach
                    @foreach($newDetails as $key => $values)
                        @include('partials.transaction-edit-row', ['prefix' => 'new_details['.$key.']', 'existingId' => null, 'deleted' => false])
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="p-3 text-end fw-bold">Total rincian setelah perubahan: <output data-expense-total aria-live="polite"></output></div>
    </div>
</div>
<template data-expense-template>
    @include('partials.transaction-edit-row', ['prefix' => 'new_details[__INDEX__]', 'existingId' => null, 'deleted' => false, 'values' => []])
</template>
<div class="d-flex flex-wrap gap-2 mb-4">
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    <a href="{{ $cancelUrl }}" class="btn btn-outline-secondary">Batal</a>
</div>

~~~~

## resources/views/partials/transaction-edit-row.blade.php

Isi setiap baris edit; tempat input foto, foto tersimpan, dan tindakan penggantian/penghapusan.

~~~~php
<tr data-expense-row @if($existingId) data-existing-id="{{ $existingId }}" @endif class="{{ $deleted ? 'opacity-50' : '' }}">
    <td>
        <select name="{{ $prefix }}[cost_category_id]" class="form-select cat-select" required @disabled($deleted) aria-label="Kategori biaya">
            <option value="">-- Pilih Kategori Biaya --</option>
            @foreach($cost_categories as $category)
                @php
                    $categoryLabel = $category->name ?? $category->nama ?? $category->description ?? $category->code;
                    $categoryName = strtolower($categoryLabel ?? '');
                    $categoryType = str_contains($categoryName, 'lumpsum') || str_contains($categoryName, 'uang saku') ? 'lumpsum'
                        : (str_contains($categoryName, 'hotel') || str_contains($categoryName, 'akomodasi') ? 'hotel' : 'umum');
                @endphp
                <option value="{{ $category->id }}" data-type="{{ $categoryType }}" @selected((string) ($values['cost_category_id'] ?? '') === (string) $category->id)>{{ $categoryLabel }}</option>
            @endforeach
        </select>
    </td>
    <td><input type="text" name="{{ $prefix }}[remark]" value="{{ $values['remark'] ?? '' }}" class="form-control" maxlength="255" @required($requireRemark) @disabled($deleted) aria-label="Keterangan biaya"></td>
    <td><input type="number" name="{{ $prefix }}[nominal]" value="{{ $values['nominal'] ?? '' }}" class="form-control" inputmode="decimal" min="0" max="9999999999999.99" step="0.01" required @disabled($deleted) aria-label="Nominal biaya dalam rupiah" data-expense-amount></td>
    <td>
        @if($existingId)
            <input type="checkbox" name="delete_details[]" value="{{ $existingId }}" hidden @checked($deleted) data-delete-expense>
        @endif
        <button type="button" class="btn {{ $deleted ? 'btn-outline-secondary' : 'btn-outline-danger' }}" data-remove-expense>{{ $deleted ? 'Batalkan Hapus' : 'Hapus' }}</button>
    </td>
</tr>

~~~~

## public/js/transaction-editor.js

Tambah baris, indeks new_details, hapus/batalkan hapus dan input yang dinonaktifkan.

~~~~javascript
(() => {
    document.querySelectorAll('[data-transaction-editor]').forEach(form => {
        const rows = form.querySelector('[data-expense-rows]');
        const template = form.querySelector('[data-expense-template]');
        const total = form.querySelector('[data-expense-total]');
        let nextIndex = Math.max(-1, ...[...rows.querySelectorAll('[name^="new_details["]')].map(input => Number(input.name.match(/^new_details\[(\d+)\]/)?.[1] ?? -1))) + 1;
        const money = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 2 });
        const updateTotal = () => {
            const cents = [...rows.querySelectorAll('[data-expense-amount]:not(:disabled)')]
                .reduce((sum, input) => sum + Math.round((Number(input.value) || 0) * 100), 0);
            total.textContent = money.format(cents / 100);
        };
        const applyCategoryRules = () => {
            if (form.dataset.transactionEditor !== 'travel') return;
            const distance = Number(form.elements.jarak_km.value) || 0;
            const duration = Number(form.elements.durasi_jam.value) || 0;
            rows.querySelectorAll('.cat-select').forEach(select => {
                [...select.options].forEach(option => {
                    option.disabled = (option.dataset.type === 'lumpsum' && distance <= 200)
                        || (option.dataset.type === 'hotel' && duration <= 8);
                });
                const invalid = select.selectedOptions[0]?.disabled;
                select.setCustomValidity(invalid ? 'Kategori tidak sesuai jarak atau durasi perjalanan. Pilih kategori lain atau ubah informasi perjalanan.' : '');
            });
        };
        form.querySelector('[data-add-expense]').addEventListener('click', () => {
            const content = template.content.cloneNode(true);
            content.querySelectorAll('[name]').forEach(input => { input.name = input.name.replace('__INDEX__', String(nextIndex)); });
            nextIndex++;
            rows.append(content);
            applyCategoryRules();
            updateTotal();
            rows.lastElementChild.querySelector('select').focus();
        });
        rows.addEventListener('click', event => {
            const button = event.target.closest('[data-remove-expense]');
            if (!button) return;
            const row = button.closest('[data-expense-row]');
            const deleted = row.querySelector('[data-delete-expense]');
            if (deleted) {
                deleted.checked = !deleted.checked;
                row.classList.toggle('opacity-50', deleted.checked);
                row.querySelectorAll('input:not([data-delete-expense]), select').forEach(input => { input.disabled = deleted.checked; });
                button.textContent = deleted.checked ? 'Batalkan Hapus' : 'Hapus';
                button.classList.toggle('btn-outline-secondary', deleted.checked);
                button.classList.toggle('btn-outline-danger', !deleted.checked);
            } else {
                row.remove();
            }
            updateTotal();
        });
        form.addEventListener('input', () => { updateTotal(); applyCategoryRules(); });
        form.addEventListener('change', applyCategoryRules);
        updateTotal();
        applyCategoryRules();

        const territory = form.querySelector('#edit-teritory');
        const province = form.querySelector('#edit-provinsi');
        const city = form.querySelector('#edit-kota');
        if (!territory || !province || !city) return;
        let provinceRequest;
        let cityRequest;
        const reset = (select, message) => { select.replaceChildren(new Option(message, '')); };
        const loadOptions = async (select, url, controller, placeholder) => {
            reset(select, 'Memuat pilihan...');
            select.setCustomValidity('Tunggu sampai pilihan wilayah selesai dimuat.');
            try {
                const response = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } });
                if (!response.ok) throw new Error('Gagal memuat wilayah');
                const data = await response.json();
                reset(select, placeholder);
                data.forEach(item => select.add(new Option(item.nama, item.id)));
                select.setCustomValidity('');
            } catch (error) {
                if (error.name === 'AbortError') return;
                reset(select, 'Gagal memuat. Pilih ulang wilayah di atas.');
                select.setCustomValidity('Pilihan wilayah gagal dimuat. Pilih ulang wilayah di atas.');
            }
        };
        territory.addEventListener('change', () => {
            provinceRequest?.abort(); cityRequest?.abort();
            reset(city, '-- Pilih Provinsi Terlebih Dahulu --');
            city.setCustomValidity('');
            provinceRequest = new AbortController();
            loadOptions(province, form.dataset.provincesUrl + '?teritory=' + encodeURIComponent(territory.value), provinceRequest, '-- Pilih Provinsi --');
        });
        province.addEventListener('change', () => {
            cityRequest?.abort();
            reset(city, '-- Pilih Kota/Kabupaten --');
            city.setCustomValidity('');
            if (!province.value) return;
            cityRequest = new AbortController();
            loadOptions(city, form.dataset.citiesUrl + '?provinsi_id=' + encodeURIComponent(province.value), cityRequest, '-- Pilih Kota/Kabupaten --');
        });
    });
})();

~~~~

## routes/web.php

Route simpan/edit/tambah/hapus rincian dan lokasi penambahan endpoint lihat/unduh foto.

~~~~php
<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\LevelController;
use App\Http\Controllers\PositionController;
use App\Http\Controllers\CostCategoryController;
use App\Http\Controllers\WilayahController;
use App\Http\Controllers\EventHourGroupController;
use App\Http\Controllers\SettingPlafonPerjalananDinasController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\WeekdayGroupController;
use App\Http\Controllers\PlafonEventDalamKotaController;
use App\Http\Controllers\PlafonEventLuarKotaController;
use App\Http\Controllers\TransaksiOperasionalController;
use App\Http\Controllers\TransaksiPerjalananDinasController;
use App\Http\Controllers\PerongkosanEventDalamKotaController;
use App\Http\Controllers\PerongkosanEventLuarKotaController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PengajuanBsController;
use App\Http\Controllers\ApprovalAtasanController;
use App\Http\Controllers\ApprovalFinanceController;
use App\Http\Controllers\PeriodeController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\LaporanBsController;
use App\Http\Controllers\CashFlowController;
use App\Http\Controllers\AccessManagementController;

Route::get('/', function () {
    return view('welcome');
});

// ==========================================
// 1. BLOK TAMU (Hanya untuk yang BELUM Login)
// ==========================================
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('proses_login');
});

// ==========================================
// 2. BLOK KARYAWAN UMUM (Harus Login)
// ==========================================
Route::middleware('auth')->group(function () {

    Route::middleware('permission:akses.approval-finance')
        ->prefix('pengecekan-pemakaian-bs')->name('bs-usage-checks.')->group(function () {
            Route::get('/', [\App\Http\Controllers\BsUsageCheckController::class, 'index'])->name('index');
            Route::get('/laporan', [\App\Http\Controllers\BsUsageCheckController::class, 'report'])->name('report');
            Route::get('/hasil/{check}', [\App\Http\Controllers\BsUsageCheckController::class, 'show'])->whereNumber('check')->name('show');
            Route::get('/{jenis}/{source}/create', [\App\Http\Controllers\BsUsageCheckController::class, 'create'])
                ->whereIn('jenis', ['OPR', 'PD', 'EDK', 'ELK'])->whereNumber('source')->name('create');
            Route::post('/{jenis}/{source}', [\App\Http\Controllers\BsUsageCheckController::class, 'store'])
                ->whereIn('jenis', ['OPR', 'PD', 'EDK', 'ELK'])->whereNumber('source')->name('store');
        });

    Route::get('/api/bs-balance', [\App\Http\Controllers\BsBalanceController::class, 'balances'])->name('bs-balance.balances');

    Route::middleware(['permission:akses.pengajuan-bs|akses.transaksi-perjalanan-dinas|akses.cash-flow', 'bs.atomic'])
        ->prefix('persetujuan-pemakaian-bs')->name('bs-usage-approvals.')->group(function () {
            Route::get('/', [\App\Http\Controllers\BsUsageApprovalController::class, 'index'])->name('index');
            Route::get('/{id}', [\App\Http\Controllers\BsUsageApprovalController::class, 'show'])->whereNumber('id')->name('show');
            Route::post('/{id}/approve', [\App\Http\Controllers\BsUsageApprovalController::class, 'approve'])->whereNumber('id')->name('approve');
            Route::post('/{id}/reject', [\App\Http\Controllers\BsUsageApprovalController::class, 'reject'])->whereNumber('id')->name('reject');
        });

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/dashboard', function () {
        if (!auth()->user()->canAccessPortal()) {
            return redirect()->route('dashboard.transaksi');
        }

        return view('dashboard.portal');
    })->name('dashboard');

    Route::get('/dashboard/transaksi', function (Request $request) {
        if ($request->filled('pemakaian_jenis')) {
            return app(\App\Http\Controllers\TransactionRecapController::class)
                ->index($request, app(\App\Services\BsUsageDashboardService::class));
        }
        $bsUsageDashboard = app(\App\Services\BsUsageDashboardService::class)->data($request);

        return view('dashboard.transaksi', compact('bsUsageDashboard'));
    })->name('dashboard.transaksi');

    Route::get('/laporan-transaksi', [\App\Http\Controllers\TransactionRecapController::class, 'index'])->name('transaction-recap.index');
    Route::get('/laporan-transaksi/modul/{jenis}', [\App\Http\Controllers\TransactionRecapController::class, 'module'])
        ->whereIn('jenis', ['OPR', 'PD', 'EDK', 'ELK'])->name('transaction-recap.module');
    Route::get('/laporan-transaksi/{jenis}/{source}', [\App\Http\Controllers\TransactionRecapController::class, 'show'])
        ->whereIn('jenis', ['OPR', 'PD', 'EDK', 'ELK'])->whereNumber('source')->name('transaction-recap.show');
    Route::post('/konfirmasi-event/{jenis}/{source}', [\App\Http\Controllers\TransactionRecapController::class, 'confirmEvent'])
        ->whereIn('jenis', ['EDK', 'ELK'])->whereNumber('source')->name('transaction-recap.confirm-event');
    Route::post('/perbaiki-pengajuan/{jenis}/{source}', [\App\Http\Controllers\TransactionRecapController::class, 'correct'])
        ->whereIn('jenis', ['OPR', 'PD'])->whereNumber('source')->name('transaction-recap.correct');

    Route::get('/api/periode/status', function (Request $request) {
        $periode = $request->query('periode', now()->format('Y-m'));
        $status  = app(\App\Services\PeriodService::class)->statusOf($periode);

        return response()->json([
            'periode' => $periode,
            'status'  => $status,
            'open'    => $status === 'OPEN',
        ]);
    });

    Route::get('/api/wilayah-provinsi', [TransaksiPerjalananDinasController::class, 'getProvinsiByTeritory'])->name('api.wilayah.provinsi');
    Route::get('/api/wilayah-kota', [TransaksiPerjalananDinasController::class, 'getKotaByProvinsi'])->name('api.wilayah.kota');
    Route::get('/api/event-luar-wilayah-provinsi', [PerongkosanEventLuarKotaController::class, 'getProvinsiByTeritory'])->name('api.event_luar.wilayah.provinsi');
    Route::get('/api/event-luar-wilayah-kota', [PerongkosanEventLuarKotaController::class, 'getKotaByProvinsi'])->name('api.event_luar.wilayah.kota');
    Route::get('/api/plafon-wilayah-provinsi', [SettingPlafonPerjalananDinasController::class, 'getProvinsiByTeritory'])->name('api.plafon.wilayah.provinsi');

    Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');

    // ==========================================
    // MODUL PENGAJUAN BS (permission: akses.pengajuan-bs)
    // ==========================================
    // Access is checked per submission for applicants, supervisors, and Finance.
    Route::get('/pengajuan-bs/{bs}/lampiran', \App\Http\Controllers\PengajuanBsAttachmentController::class)
        ->whereNumber('bs')->name('pengajuan-bs.attachment');

    Route::middleware(['permission:akses.pengajuan-bs', 'bs.atomic'])->group(function () {
        Route::get('/pengajuan-bs/export', [PengajuanBsController::class, 'export'])->name('pengajuan-bs.export');

        Route::resource('pengajuan-bs', PengajuanBsController::class)
            ->except(['show', 'edit', 'update', 'destroy', 'store']);

        Route::get('/pengajuan-bs/{bs}', [PengajuanBsController::class, 'show'])->name('pengajuan-bs.show');

        Route::post('/pengajuan-bs', [PengajuanBsController::class, 'store'])
            ->name('pengajuan-bs.store')
            ->middleware(['company.active', 'atasan.active']);
    });

    // ==========================================
    // MODUL TRANSAKSI OPERASIONAL (permission: akses.transaksi-operasional)
    // ==========================================
    Route::middleware(['permission:akses.transaksi-operasional', 'bs.atomic'])->group(function () {
        Route::get('/transaksi-operasional/export', [TransaksiOperasionalController::class, 'export'])->name('transaksi_operasional.export');

        Route::resource('transaksi-operasional', TransaksiOperasionalController::class)
            ->names('transaksi_operasional')
            ->except(['store', 'update']);

        Route::post('/transaksi-operasional', [TransaksiOperasionalController::class, 'store'])
            ->name('transaksi_operasional.store')
            ->middleware(['company.active', 'atasan.active']);

        Route::put('/transaksi-operasional/{transaksi_operasional}', [TransaksiOperasionalController::class, 'update'])
            ->name('transaksi_operasional.update')
            ->middleware(['company.active', 'atasan.active']);

        Route::post('/transaksi-operasional/{id}/add-detail', [TransaksiOperasionalController::class, 'storeDetail'])
            ->name('transaksi_operasional.store_detail')
            ->middleware(['company.active', 'atasan.active']);

        Route::post('/transaksi-operasional/{id}/validate', [TransaksiOperasionalController::class, 'validateTransaction'])
            ->name('transaksi_operasional.validate')
            ->middleware(['company.active', 'atasan.active']);
    });

    // ==========================================
    // MODUL TRANSAKSI PERJALANAN DINAS (permission: akses.transaksi-perjalanan-dinas)
    // ==========================================
    Route::middleware(['permission:akses.transaksi-perjalanan-dinas', 'bs.atomic'])->group(function () {
        Route::get('/transaksi-perjalanan-dinas/export', [TransaksiPerjalananDinasController::class, 'export'])->name('transaksi_perjalanan_dinas.export');

        Route::resource('transaksi-perjalanan-dinas', TransaksiPerjalananDinasController::class)
            ->parameters(['transaksi-perjalanan-dinas' => 'transaksi_perjalanan_dinas'])
            ->names('transaksi_perjalanan_dinas')
            ->except(['store', 'update']);

        Route::post('/transaksi-perjalanan-dinas', [TransaksiPerjalananDinasController::class, 'store'])
            ->name('transaksi_perjalanan_dinas.store')
            ->middleware(['company.active', 'atasan.active']);

        Route::put('/transaksi-perjalanan-dinas/{transaksi_perjalanan_dinas}', [TransaksiPerjalananDinasController::class, 'update'])
            ->name('transaksi_perjalanan_dinas.update')
            ->middleware(['company.active', 'atasan.active']);

        Route::delete('/transaksi-perjalanan-dinas/detail/{id}', [TransaksiPerjalananDinasController::class, 'destroyDetail'])
            ->name('transaksi_perjalanan_dinas.destroy_detail')
            ->middleware(['company.active', 'atasan.active']);

        Route::post('/transaksi-perjalanan-dinas/{id}/validate', [TransaksiPerjalananDinasController::class, 'validateTransaction'])
            ->name('transaksi_perjalanan_dinas.validate')
            ->middleware(['company.active', 'atasan.active']);

        Route::post('/transaksi-perjalanan-dinas/{id}/withdraw', [TransaksiPerjalananDinasController::class, 'withdraw'])
            ->name('transaksi_perjalanan_dinas.withdraw');
        Route::post('/transaksi-perjalanan-dinas/{id}/revise', [TransaksiPerjalananDinasController::class, 'revise'])
            ->name('transaksi_perjalanan_dinas.revise');

        Route::post('/transaksi-perjalanan-dinas/{id}/add-detail', [TransaksiPerjalananDinasController::class, 'storeDetail'])
            ->name('transaksi_perjalanan_dinas.store_detail')
            ->middleware(['company.active', 'atasan.active']);
    });

    Route::post('/api/calculate-cost-nominal', [TransaksiPerjalananDinasController::class, 'getAutoNominal'])->name('api.calculate_cost_nominal');

    // ==========================================
    // MODUL EVENT DALAM KOTA (permission: akses.event-dalam-kota)
    // ==========================================
    Route::middleware(['permission:akses.event-dalam-kota', 'event.atomic'])->group(function () {
        Route::get('/event-dalam-kota/export', [PerongkosanEventDalamKotaController::class, 'export'])->name('perongkosan_event_dalam_kota.export');

        Route::resource('event-dalam-kota', PerongkosanEventDalamKotaController::class)
            ->names('perongkosan_event_dalam_kota')
            ->except(['store', 'update']);

        Route::post('/event-dalam-kota', [PerongkosanEventDalamKotaController::class, 'store'])
            ->name('perongkosan_event_dalam_kota.store')
            ->middleware(['company.active', 'atasan.active']);

        Route::put('/event-dalam-kota/{event_dalam_kota}', [PerongkosanEventDalamKotaController::class, 'update'])
            ->name('perongkosan_event_dalam_kota.update')
            ->middleware(['company.active', 'atasan.active']);
    });

    // ==========================================
    // MODUL EVENT LUAR KOTA (permission: akses.event-luar-kota)
    // ==========================================
    Route::middleware(['permission:akses.event-luar-kota', 'event.atomic'])->group(function () {
        Route::get('/event-luar-kota/export', [PerongkosanEventLuarKotaController::class, 'export'])->name('perongkosan_event_luar_kota.export');

        Route::resource('event-luar-kota', PerongkosanEventLuarKotaController::class)
            ->names('perongkosan_event_luar_kota')
            ->except(['store', 'update']);

        Route::post('/event-luar-kota', [PerongkosanEventLuarKotaController::class, 'store'])
            ->name('perongkosan_event_luar_kota.store')
            ->middleware(['company.active', 'atasan.active']);

        Route::put('/event-luar-kota/{event_luar_kota}', [PerongkosanEventLuarKotaController::class, 'update'])
            ->name('perongkosan_event_luar_kota.update')
            ->middleware(['company.active', 'atasan.active']);
    });

    // ==========================================
    // APPROVAL ATASAN (dikunci RELASI atasan, bukan role)
    // ==========================================
    Route::middleware(['can:approval-atasan', 'bs.atomic'])->group(function () {
        Route::prefix('approval-atasan')->name('approval-atasan.')->group(function () {
            Route::get('/', [ApprovalAtasanController::class, 'index'])->name('index');
            Route::get('/{bs}/detail', [ApprovalAtasanController::class, 'detail'])->name('detail');
            Route::post('/{bs}/approve', [ApprovalAtasanController::class, 'approve'])->name('approve');
            Route::post('/{bs}/reject', [ApprovalAtasanController::class, 'reject'])->name('reject');
        });
    });

    // ==========================================
    // APPROVAL FINANCE (permission divisi Finance)
    // ==========================================
    Route::middleware(['permission:akses.approval-finance', 'bs.atomic'])->group(function () {
        Route::prefix('approval-finance')->name('approval-finance.')->group(function () {
            Route::get('/', [ApprovalFinanceController::class, 'index'])->name('index');
            Route::get('/{bs}/detail', [ApprovalFinanceController::class, 'detail'])->name('detail');
            Route::post('/{bs}/disburse', [ApprovalFinanceController::class, 'disburse'])->name('disburse');
            Route::post('/{bs}/reject', [ApprovalFinanceController::class, 'reject'])->name('reject');
        });
    });

    // ==========================================
    // CASH FLOW
    // ==========================================
    Route::middleware(['permission:akses.cash-flow'])->group(function () {
        Route::get('/cash-flow', [CashFlowController::class, 'index'])->name('cash-flow.index');
        Route::get('/cash-flow/export', [CashFlowController::class, 'export'])->name('cash-flow.export');
        Route::get('/cash-flow/{periode}/export', [CashFlowController::class, 'exportPeriod'])->name('cash-flow.export-period');
        Route::get('/cash-flow/{periode}', [CashFlowController::class, 'show'])->name('cash-flow.show');

        /* ==========================================================
           🆕 HTMX PARTIAL: Pagination transaksi tanpa reload halaman
           Dipanggil oleh link paginator di HTMX (hx-get),
           mengembalikan hanya potongan HTML section Uang Masuk/Keluar.
        ========================================================== */
        Route::get('/cash-flow/{periode}/transactions', [CashFlowController::class, 'transactionsPartial'])
            ->name('cash-flow.transactions-partial');
    });

    // NOTIFIKASI
    Route::get('/notifications/unread', [NotificationController::class, 'unread'])->name('notifications.unread');
    Route::post('/notifications/read-all', [NotificationController::class, 'readAll'])->name('notifications.read_all');
    Route::post('/notifications/{id}/read', [NotificationController::class, 'read'])->name('notifications.read');

    // ==========================================
    // LAPORAN PERTANGGUNGJAWABAN BS
    // ==========================================
    Route::middleware(['permission:akses.laporan-bs'])->group(function () {
        Route::get('/laporan-bs', [LaporanBsController::class, 'index'])->name('laporan-bs.index');
        Route::get('/laporan-bs/export', [LaporanBsController::class, 'export'])->name('laporan-bs.export');
        Route::post('/laporan-bs/{bs}/settle', [LaporanBsController::class, 'settle'])->name('laporan-bs.settle');
    });

    // API UNTUK INFO PLAFON
    Route::post('/api/get-plafon-info', [TransaksiPerjalananDinasController::class, 'getPlafonInfo'])->name('api.get_plafon_info');
    Route::post('/api/check-plafon-realtime', [TransaksiPerjalananDinasController::class, 'checkPlafonRealtime'])->name('api.check_plafon_realtime');
    Route::post('/api/event-dalam-kota/plafon-info', [PerongkosanEventDalamKotaController::class, 'getPlafonInfo'])->name('api.event_dalam_kota.plafon_info');
    Route::post('/api/event-luar-kota/plafon-info', [PerongkosanEventLuarKotaController::class, 'getPlafonInfo'])->name('api.event_luar_kota.plafon_info');
});

// ==========================================
// 3. BLOK VVIP ADMINISTRATOR
// ==========================================
Route::middleware(['auth', 'permission:akses.master-data'])->group(function () {

    Route::get('/dashboard/master-data', function () {
        $counts = [
            'roles'             => DB::table('roles')->count(),
            'users'             => DB::table('user')->count(),
            'companies'         => DB::table('company')->count(),
            'levels'            => DB::table('level')->count(),
            'positions'         => DB::table('position')->count(),
            'wilayah'           => DB::table('wilayah')->count(),
            'cost_categories'   => DB::table('cost_category')->count(),
            'week_day_groups'   => DB::table('weekday_group')->count(),
            'event_hours'       => DB::table('event_hour_group')->count(),
            'plafon_dinas'      => DB::table('setting_plafon_perjalanan_dinas')->count(),
            'plafon_dalam'      => DB::table('setting_plafon_event_marketing_dalam_kota')->count(),
            'plafon_luar'       => DB::table('setting_plafon_event_marketing_luar_kota')->count(),
            'periode'           => DB::table('periode')->count(),
        ];

        $periods = DB::table('periode')->orderBy('periode', 'desc')->get();

        return view('dashboard.master_data', compact('counts', 'periods'));
    })->name('dashboard.master_data');

    Route::resource('roles', RoleController::class);
    Route::resource('users', UserController::class);
    Route::resource('companies', CompanyController::class);
    Route::resource('levels', LevelController::class);
    Route::resource('positions', PositionController::class);
    Route::resource('cost_categories', CostCategoryController::class);
    Route::resource('wilayah', WilayahController::class);
    Route::get('/api/wilayah-search', [WilayahController::class, 'search'])->name('api.wilayah.search');
    Route::resource('event_hour_groups', EventHourGroupController::class);
    Route::resource('setting_plafon_perjalanan_dinas', SettingPlafonPerjalananDinasController::class);
    Route::resource('weekday_groups', WeekdayGroupController::class);
    Route::resource('plafon-event-dalam-kota', PlafonEventDalamKotaController::class);
    Route::resource('plafon-event-luar-kota', PlafonEventLuarKotaController::class);

    // ACCESS MANAGEMENT (halaman pengaturan hak akses menu per Role / User Right Group)
    Route::middleware(['permission:akses.access-management'])->group(function () {
        Route::get('/access-management', [AccessManagementController::class, 'index'])->name('access-management.index');
        Route::put('/access-management/{role}', [AccessManagementController::class, 'update'])->name('access-management.update');
    });

    Route::get('/periode', [PeriodeController::class, 'index'])->name('periode.index');
    Route::post('/periode/{periode}/close', [PeriodeController::class, 'close'])->name('periode.close');
    Route::get('/periode/{periode}', [PeriodeController::class, 'show'])->name('periode.show');
    Route::post('/periode/{periode}/reopen', [PeriodeController::class, 'reopen'])->name('periode.reopen');
});

~~~~

## config/filesystems.php

Konfigurasi disk penyimpanan; sudah ada contoh disk privat bs_attachments.

~~~~php
<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application for file storage.
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Below you may configure as many filesystem disks as necessary, and you
    | may even configure multiple disks for the same driver. Examples for
    | most supported storage drivers are configured here for reference.
    |
    | Supported drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => storage_path('app/private'),
            'serve' => true,
            'throw' => false,
            'report' => false,
        ],

        'reimbursement_proofs' => [
            'driver' => 'local',
            'root' => storage_path('app/private/reimbursement-proofs'),
            'visibility' => 'private',
            'serve' => false,
            'throw' => true,
        ],

        'bs_attachments' => [
            'driver' => 'local',
            'root' => storage_path('app/private/bs-attachments'),
            'visibility' => 'private',
            'serve' => false,
            'throw' => true,
        ],

        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
            'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => false,
            'report' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];

~~~~

## app/Http/Middleware/AtomicBsRequest.php

Transaksi database luar dan cleanup upload BS; relevan untuk rollback/retry penyimpanan foto rincian.

~~~~php
<?php

namespace App\Http\Middleware;

use App\Models\PengajuanBs;
use App\Models\TransaksiOperasionalHeader;
use App\Models\TransaksiPerjalananDinasDetail;
use App\Models\TransaksiPerjalananDinasHeader;
use App\Services\PeriodService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AtomicBsRequest
{
    public function handle(Request $request, Closure $next)
    {
        if ($request->isMethodSafe()) {
            return $next($request);
        }

        $periods = app(PeriodService::class);
        $name = $request->route()->getName();
        $header = null;
        $id = $request->route('id');
        if (str_starts_with($name, 'bs-usage-approvals.')) {
            $header = TransaksiPerjalananDinasHeader::findOrFail($id);
        } elseif (str_starts_with($name, 'transaksi_operasional.')) {
            $id ??= $request->route('transaksi_operasional');
            if ($id) $header = TransaksiOperasionalHeader::findOrFail($id);
        } elseif (str_starts_with($name, 'transaksi_perjalanan_dinas.')) {
            $id ??= $request->route('transaksi_perjalanan_dinas');
            if ($name === 'transaksi_perjalanan_dinas.destroy_detail') {
                $header = TransaksiPerjalananDinasDetail::findOrFail($id)->header;
            } elseif ($id) {
                $header = TransaksiPerjalananDinasHeader::where('transaksi_id', $id)->firstOrFail();
            }
        }

        $keys = [];
        if ($header) $keys[] = $header->periode;
        if ($request->has('tanggal')) {
            $request->validate(['tanggal' => 'required|date_format:Y-m-d']);
            $keys[] = $periods->ofDate($request->tanggal);
        }
        if (!$keys) $keys[] = $periods->current();
        $keys = array_unique(array_map($periods->normalize(...), $keys));
        sort($keys);
        $bs = $request->route('bs');
        $request->validate(['bs_owner_id' => 'nullable|integer|exists:user,id']);
        $bsIds = array_filter([$bs instanceof PengajuanBs ? $bs->id : null, $header?->bs_id]);
        // Resolve owner IDs before BEGIN; acquire locks before any consistent-read
        // balance query so MySQL REPEATABLE READ cannot retain a pre-lock balance.
        $owners = PengajuanBs::whereIn('id', $bsIds)->pluck('user_id')
            ->push($request->user()->id, $header?->user_id, $header?->bsCashOwnerId(), $request->input('bs_owner_id'))
            ->filter()->map(fn ($id) => (int) $id)->unique()->sort();

        $transaction = function () use ($request, $next, $periods, $keys, $header, $bs, $bsIds, $owners, $name) {
            foreach ($keys as $key) $periods->lockOpen($key);

            foreach ($owners as $owner) DB::table('user')->where('id', $owner)->lockForUpdate()->first();
            foreach (PengajuanBs::whereIn('id', $bsIds)->orderBy('id')->lockForUpdate()->get() as $locked) {
                if ($bs instanceof PengajuanBs && (int) $bs->id === (int) $locked->id) {
                    $request->route()->setParameter('bs', $locked);
                }
            }

            if ($header) {
                $locked = $header->newQuery()->whereKey($header->getKey())->lockForUpdate()->firstOrFail();
                if (!in_array($locked->periode, $keys, true) || (string) $locked->bs_id !== (string) $header->bs_id
                    || $locked->bsCashOwnerId() !== $header->bsCashOwnerId() || (int) $locked->user_id !== (int) $header->user_id) {
                    throw ValidationException::withMessages(['error' => 'Transaksi berubah. Muat ulang halaman dan ulangi tindakan.']);
                }
                $requiredStatus = 'DRAFT';
                if (in_array($name, ['bs-usage-approvals.approve', 'bs-usage-approvals.reject'], true)) {
                    abort_unless((int) $request->user()->id === $locked->bsCashOwnerId() && $locked->needsOwnerApproval(), 403);
                    $requiredStatus = 'PENDING_OWNER';
                } elseif (in_array($name, ['transaksi_perjalanan_dinas.withdraw', 'transaksi_perjalanan_dinas.revise'], true)) {
                    abort_unless((int) $request->user()->id === (int) $locked->user_id, 403);
                    $requiredStatus = str_ends_with($name, '.withdraw') ? 'PENDING_OWNER' : 'REJECTED_OWNER';
                } else {
                    abort_unless($request->user()->canAccessTransaction($locked), 403);
                }
                if ($locked->status !== $requiredStatus) {
                    throw ValidationException::withMessages(['error' => 'Status transaksi berubah atau tindakan tidak tersedia. Muat ulang dan periksa rincian terbaru.']);
                }
            }

            $response = $next($request);
            // Laravel's routing pipeline may render an exception into a response.
            // Roll back the outer unit of work when a controller failed.
            if ($response->getStatusCode() >= 400) {
                throw new \Illuminate\Http\Exceptions\HttpResponseException($response);
            }
            return $response;
        };

        try {
            return DB::transaction($transaction, 3);
        } finally {
            app(\App\Services\BsAttachmentService::class)->discardPending($request);
        }
    }
}

~~~~

## app/Models/User.php

Aturan akses transaksi yang dapat digunakan saat mengizinkan akses foto.

~~~~php
<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Notifications\Notifiable;
use App\Models\Company;
use App\Models\Role;
use App\Models\Level;
use App\Models\Position;
use App\Models\Wilayah;

class User extends Authenticatable
{
    use HasRoles, Notifiable;

    protected $table = 'user';
    public $timestamps = false;

    protected $fillable = [
        'NIK', 'nama', 'company_id', 'roles_id', 'level_id', 'position_id',
        'homebase_id', 'kost', 'bbm', 'uang_makan', 'hari_kerja_user',
        'atasan_user_id', 'username', 'password', 'is_active',
    ];

    public function company() { return $this->belongsTo(Company::class, 'company_id'); }
    public function role() { return $this->belongsTo(Role::class, 'roles_id'); }
    public function level() { return $this->belongsTo(Level::class, 'level_id', 'id'); }
    public function position() { return $this->belongsTo(Position::class, 'position_id'); }
    public function homebase() { return $this->belongsTo(Wilayah::class, 'homebase_id', 'id'); }
    public function atasan() { return $this->belongsTo(User::class, 'atasan_user_id'); }
    public function bawahan() { return $this->hasMany(User::class, 'atasan_user_id'); }
    public function pengajuanBs() { return $this->hasMany(PengajuanBs::class, 'user_id'); }
    public function bsMembers() { return $this->belongsToMany(PengajuanBs::class, 'pengajuan_bs_members', 'user_id', 'pengajuan_bs_id'); }

    public function canAccessPortal(): bool
    {
        return in_array($this->role?->code, ['ADMIN', 'ADMINISTRATOR'], true);
    }

    public function dashboardRouteName(): string
    {
        return $this->canAccessPortal() ? 'dashboard' : 'dashboard.transaksi';
    }

    public function canSeeAllTransactions(): bool
    {
         return in_array($this->role->code ?? '', ['ADMIN', 'DIR', 'FINANCE']);
    }

    public function canAccessTransaction($transaksi): bool
    {
        return $this->canSeeAllTransactions() || $transaksi->user_id === $this->id;
    }

    public function canViewBsTransaction($transaksi): bool
    {
        return $this->canAccessTransaction($transaksi)
            || $transaksi->bsCashOwnerId() === (int) $this->id;
    }

    public function hasActiveCompany(): bool
    {
        if (!$this->relationLoaded('company')) {
            $this->load('company');
        }

        return $this->company !== null && $this->company->isActive();
    }

    public function isActive(): bool
    {
        $value = $this->is_active;

        if (is_string($value)) {
            return in_array(strtoupper(trim($value)), ['Y', 'YES', '1', 'TRUE', 'AKTIF'], true);
        }

        return (bool) $value;
    }

    public function hasActiveAtasan(): bool
    {
        if (!$this->relationLoaded('atasan')) {
            $this->load('atasan');
        }

        if (!$this->atasan) {
            return true;
        }

        return $this->atasan->isActive();
    }
}

~~~~

## app/Models/Concerns/UsesBsBalance.php

Konteks status transaksi, pemilik BS, dan hubungan pemeriksaan Finance.

~~~~php
<?php

namespace App\Models\Concerns;

use App\Models\User;
use Illuminate\Database\Eloquent\Builder;

trait UsesBsBalance
{
    public function bsOwner()
    {
        return $this->belongsTo(User::class, 'bs_owner_id');
    }

    public function bsCashOwnerId(): ?int
    {
        $owner = $this->bs_owner_id ?? $this->bonSementara?->user_id;
        return $owner === null ? null : (int) $owner;
    }

    public function scopeForBsOwner(Builder $query, int $ownerId): Builder
    {
        return $query->where(fn ($q) => $q->where('bs_owner_id', $ownerId)
            ->orWhere(fn ($legacy) => $legacy->whereNull('bs_owner_id')
                ->whereHas('bonSementara', fn ($bs) => $bs->where('user_id', $ownerId))));
    }

    public function scopeVisibleTo(Builder $query, User $user): Builder
    {
        return $query->when(!$user->canSeeAllTransactions(), fn ($q) => $q
            ->where(fn ($visible) => $visible->where('user_id', $user->id)
                ->orWhere(fn ($owned) => $owned->forBsOwner((int) $user->id))));
    }
}

~~~~

## resources/views/partials/mobile-assets.blade.php

Pemuatan aset mobile bersama.

~~~~php
{{-- Shared by both the sidebar layout and standalone module pages. --}}
<link rel="stylesheet" href="{{ asset('css/mobile.css') }}?v={{ filemtime(public_path('css/mobile.css')) }}">
<script src="{{ asset('js/mobile.js') }}?v={{ filemtime(public_path('js/mobile.js')) }}" defer></script>

~~~~

## public/css/mobile.css

Layout tabel/form pada layar kecil; periksa saat menambah kolom foto.

~~~~css
/* Mobile rules shared by the Blade layouts. Keep wide data tables scrollable. */
html {
    -webkit-text-size-adjust: 100%;
    text-size-adjust: 100%;
    scroll-padding-top: 6rem;
}

body { min-height: 100svh; }
.app-layout { grid-template-columns: var(--sidebar-width) minmax(0, 1fr); min-height: 100svh; }
.content-wrapper, .table-responsive { min-width: 0; }
.table-responsive { max-width: 100%; overscroll-behavior-x: contain; }
.table-responsive:focus-visible { outline: 2px solid #3b82f6; outline-offset: 2px; }

@media (min-width: 992px) {
    html.sidebar-desktop-collapsed .app-layout { grid-template-columns: 0 minmax(0, 1fr); }
}

@media (max-width: 991.98px) {
    body:not(.auth-login) {
        padding-left: env(safe-area-inset-left, 0px);
        padding-right: env(safe-area-inset-right, 0px);
        padding-bottom: env(safe-area-inset-bottom, 0px);
    }
    body:not(.auth-login):not(.app-shell) { padding-top: env(safe-area-inset-top, 0px); }

    .app-layout { grid-template-columns: minmax(0, 1fr); }
    .sidebar {
        padding-top: env(safe-area-inset-top, 0px);
        padding-left: env(safe-area-inset-left, 0px);
        padding-bottom: env(safe-area-inset-bottom, 0px);
    }
    .sidebar .sidebar-link, .sidebar .sidebar-submenu .sidebar-link { min-height: 44px; }
    .topbar .topbar-menu-toggle, .sidebar .sidebar-close, .notif-wrap .notif-bell {
        min-width: 44px;
        min-height: 44px;
        flex-shrink: 0;
    }
    .topbar {
        height: auto;
        min-height: var(--topbar-height);
        padding-top: max(.5rem, env(safe-area-inset-top, 0px));
        padding-bottom: .5rem;
        gap: .75rem;
    }
    .topbar-left { flex: 1; }
    .topbar-breadcrumb { overflow: hidden; }
    .topbar-breadcrumb > a, .topbar-breadcrumb > i { flex-shrink: 0; }

    /* 16px inputs avoid automatic focus zoom in iOS while retaining pinch zoom. */
    body input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]),
    body select, body textarea,
    body .form-control, body .form-select {
        font-size: 16px;
        min-height: 44px;
        max-width: 100%;
    }
    body input[type="date"], body input[type="datetime-local"], body input[type="month"], body input[type="time"] {
        min-width: 0;
    }
    body .btn, body .btn-action, body .btn-action-sm, body .page-link,
    body .btn-nav, body .chip-filter, body .btn-full, body .btn-cairkan,
    body .btn-tolak, body .btn-primary-action, body .btn-success-action, body .btn-back {
        min-height: 44px;
        align-content: center;
        white-space: normal;
    }
    body .btn-icon, body .btn-action-sm, body .page-link, body .btn-full { min-width: 44px; }
    body .export-form .form-select, body .toolbar .form-select { font-size: 16px; }
    body .form-check { min-height: 44px; display: flex; align-items: center; gap: .5rem; }
    body .form-check .form-check-input { flex-shrink: 0; margin-top: 0; }
    body .form-check-label { padding-block: .5rem; }
    .select2-container { max-width: 100%; }
    .select2-container .select2-selection--single { min-height: 44px; font-size: 16px; }
    .select2-results__option { min-height: 44px; }
    .modal .btn-close { min-width: 44px; min-height: 44px; padding: 0; }
    body .pagination { flex-wrap: wrap; gap: .25rem; }
    .modal-dialog { margin: max(.5rem, env(safe-area-inset-top, 0px)) .5rem max(.5rem, env(safe-area-inset-bottom, 0px)); }
    .modal-content { overflow-wrap: anywhere; }
    .modal-footer { gap: .5rem; }
    .modal-footer .btn { margin: 0; }

    /* The drawer owns the viewport until it is closed (including on Safari). */
    body.sidebar-open { position: fixed; width: 100%; overflow: hidden; }
}

@media (max-width: 767.98px) {
    .content-wrapper { padding: 1rem; }
    .topbar { flex-wrap: wrap; }
    .topbar .topbar-left { gap: .625rem; }
    .topbar .topbar-actions {
        display: contents;
        max-width: none;
    }
    .topbar .application-live-time--inline {
        order: 2;
        flex: 1 0 100%;
        justify-content: center;
        margin: 0;
        min-height: 30px;
    }
    .topbar .notif-wrap { flex: 0 0 auto; }
    .topbar-breadcrumb > a, .topbar-breadcrumb > i { display: none; }
    .topbar-breadcrumb .current { font-size: .875rem; }
    .card-header-modern.success { padding: 1rem; }
    .card-header-modern.success > .d-flex { width: 100%; flex-wrap: wrap; }
    .card-header-modern.success .total-badge { width: auto; flex: 1; min-width: 0; padding: .5rem; overflow-wrap: anywhere; }
    .card-header-modern.success #btn-tambah-baris { flex-shrink: 0; white-space: nowrap; }

    /* Forms for repeated expense items become labelled, full-width rows. */
    table.mobile-entry-table, .mobile-entry-table tbody { display: block; width: 100%; min-width: 0; }
    .mobile-entry-table thead {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        overflow: hidden;
        clip-path: inset(50%);
    }
    .mobile-entry-table tbody tr {
        display: block;
        padding: .75rem;
        border-bottom: 1px solid #e2e8f0;
    }
    .mobile-entry-table tbody tr:nth-child(even) { background: #f8fafc; }
    .mobile-entry-table tbody td {
        display: block;
        width: 100% !important;
        min-width: 0 !important;
        padding: .5rem .25rem;
        border: 0;
        text-align: left !important;
        white-space: normal;
    }
    .mobile-entry-table td[data-label]::before {
        content: attr(data-label);
        display: block;
        margin-bottom: .375rem;
        font-size: .8125rem;
        font-weight: 600;
        color: #475569;
    }
    .mobile-entry-table .input-group { flex-wrap: nowrap; }
    .mobile-entry-table .input-group .form-control { min-width: 0; }
    .mobile-entry-table .btn-hapus, .mobile-entry-table .btn-hapus-show, .mobile-entry-table .btn-hapus-view {
        min-width: 44px;
        min-height: 44px;
    }
}

@media (max-width: 575.98px) {
    body.py-5 { padding-top: max(1rem, env(safe-area-inset-top, 0px)) !important; padding-bottom: max(1rem, env(safe-area-inset-bottom, 0px)) !important; }
    .page-header, .header-section, .page-hero, .card-header, .card-header-modern, .section-header {
        flex-wrap: wrap;
        gap: .75rem;
        min-width: 0;
    }
    .page-header > *, .card-header > *, .card-header-modern > *, .toolbar > * { min-width: 0; max-width: 100%; }
    .page-header h1, .page-header h2, .header-section h1, .header-section h2 { font-size: 1.5rem; overflow-wrap: anywhere; }
    .card-header h4, .card-header h5, .card-header-modern h5 { font-size: 1.125rem; }
    .card-body.p-4, .card-body.p-5 { padding: 1rem !important; }
    .toolbar > .d-flex { flex-wrap: wrap; width: 100%; }
    .toolbar #periodSelect { min-width: 0 !important; width: 100%; }
    .table-responsive > table:not(.mobile-entry-table) { font-size: .8125rem; }
    .stat-card, .stat-value, .info-value, .info-row .value { min-width: 0; overflow-wrap: anywhere; }
    .card-custom .info-row { flex-direction: column; align-items: flex-start !important; gap: .25rem; }
    .card-custom .info-row .info-value { max-width: 100%; text-align: left; white-space: normal; }
    .document-heading { min-width: 0; max-width: 100%; overflow-wrap: anywhere; }
    .cf-header, .cf-actions { flex-wrap: wrap; }
    .cf-actions, .cf-actions > * { min-width: 0; max-width: 100%; }

    .login-container { margin-block: auto; }
    .login-container .login-header { padding: 1.75rem 1.25rem; }
    .login-container .login-body { padding: 1.5rem 1.25rem; }
    .login-container .login-header h1 { font-size: 1.375rem; }
    .login-container #password { padding-right: 3.25rem; }
    .login-container .password-toggle { width: 44px; height: 44px; right: 4px; }
    .login-container .alert { overflow-wrap: anywhere; }
}

@media print {
    .table-responsive { overflow: visible !important; }
}

~~~~

## public/js/mobile.js

Adaptasi tabel dan label sel pada tampilan mobile.

~~~~javascript
(() => {
    // Keep the existing form controls and row handlers when presenting mobile cards.
    document.querySelectorAll('[data-mobile-entry]').forEach(table => {
        const headers = [...table.querySelectorAll('thead th')].map(header => header.textContent.trim().replace(/\s+/g, ' '));
        const labelRows = () => {
            table.querySelectorAll('tbody tr').forEach(row => {
                if (row.cells.length !== headers.length) return;
                [...row.cells].forEach((cell, index) => {
                    cell.dataset.label = headers[index];
                    cell.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(input => {
                        if (!input.labels?.length && !input.hasAttribute('aria-label') && !input.hasAttribute('aria-labelledby')) {
                            input.setAttribute('aria-label', headers[index]);
                        }
                    });
                    cell.querySelectorAll('button').forEach(button => {
                        if (!button.textContent.trim() && !button.hasAttribute('aria-label')) {
                            button.setAttribute('aria-label', button.title || 'Hapus baris');
                        }
                    });
                });
            });
        };
        labelRows();
        table.classList.add('mobile-entry-table');
        new MutationObserver(labelRows).observe(table.tBodies[0], { childList: true, subtree: true });
    });

    // Keyboard users can also reach and scroll wide data tables.
    document.querySelectorAll('.table-responsive').forEach(container => {
        if (container.querySelector('[data-mobile-entry]')) return;
        container.setAttribute('tabindex', '0');
        if (!container.hasAttribute('role')) container.setAttribute('role', 'region');
        if (!container.hasAttribute('aria-label') && !container.hasAttribute('aria-labelledby')) {
            container.setAttribute('aria-label', 'Tabel data, geser ke samping untuk melihat kolom lainnya');
        }
    });
})();

~~~~
