# Pemeriksaan Finance, persetujuan, dan rekap — jika foto ditampilkan di alur ini

Salinan kode saat pemetaan 8 Oktober 2026. Fitur foto per rincian belum diimplementasikan.

## app/Services/BsUsageCheckService.php

snapshot memetakan setiap rincian ke source_detail_id dan fingerprint; perlu dipertimbangkan jika foto ikut menjadi bukti pemeriksaan.

~~~~php
<?php

namespace App\Services;

use App\Models\BsUsageCheck;
use App\Models\BsUsageCheckDraft;
use App\Models\TransaksiOperasionalHeader;
use App\Models\TransaksiPerjalananDinasHeader;
use App\Models\PerongkosanEventDalamKota;
use App\Models\PerongkosanEventLuarKota;
use App\Models\User;
use App\Support\Money;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class BsUsageCheckService
{
    public const TYPES = [
        'OPR' => TransaksiOperasionalHeader::class,
        'PD' => TransaksiPerjalananDinasHeader::class,
        'EDK' => PerongkosanEventDalamKota::class,
        'ELK' => PerongkosanEventLuarKota::class,
    ];

    public const LABELS = ['OPR' => 'Operasional Sales', 'PD' => 'Perjalanan Dinas', 'EDK' => 'Event Dalam Kota', 'ELK' => 'Event Luar Kota'];
    public const DECISIONS = ['APPROVED' => 'Disetujui Finance', 'REJECTED' => 'Ditolak'];

    public static function decisionLabel(string $decision): string
    {
        return self::DECISIONS[$decision] ?? ($decision === 'REVISION' ? 'Perlu Revisi (keputusan lama)' : $decision);
    }

    public static function awaitingResubmission(Model $source): bool
    {
        return $source->status !== 'VALIDATED'
            && (self::isEvent($source) || $source->finance_correction_check_id !== null);
    }

    public static function isEvent(Model $source): bool
    {
        return $source instanceof PerongkosanEventDalamKota || $source instanceof PerongkosanEventLuarKota;
    }

    public function source(string $type, int $id, bool $lock = false): Model
    {
        abort_unless(isset(self::TYPES[$type]), 404);
        $query = self::TYPES[$type]::query();
        if ($lock) {
            $query->lockForUpdate();
        }

        return $query->findOrFail($id);
    }

    public function snapshot(Model $source, bool $lock = false): array
    {
        if (self::isEvent($source)) {
            $type = $source instanceof PerongkosanEventDalamKota ? 'EDK' : 'ELK';
            $items = collect([[
                'source_detail_id' => null, 'source_remark' => $source->description,
                'cost_category_id' => null, 'cost_category_name' => self::LABELS[$type],
                'nominal_asal' => Money::decimal(Money::minor($source->nominal)),
            ]]);
            $fingerprint = hash('sha256', json_encode($source->getAttributes(), JSON_THROW_ON_ERROR));

            return compact('items', 'fingerprint');
        }
        $query = $source->details()->with('costCategory')->orderBy('id');
        if ($lock) {
            $query->lockForUpdate();
        }
        $details = $query->get();
        $items = $details->map(function ($row) {
            $minor = Money::minor($row->nominal);
            if ($minor < 0 || $minor > 999999999999999) {
                throw ValidationException::withMessages(['source' => 'Nominal rincian sumber di luar batas yang dapat diperiksa.']);
            }

            return [
                'source_detail_id' => (int) $row->id,
                'source_remark' => $row->remark,
                'cost_category_id' => (int) $row->cost_category_id,
                'cost_category_name' => $row->costCategory?->nama ?? 'Kategori #'.$row->cost_category_id,
                'nominal_asal' => Money::decimal($minor),
            ];
        })->values();

        $fingerprint = hash('sha256', json_encode([
            'header' => [$source->getKey(), $source->transaksi_id, $source->user_id, $source->tanggal, $source->status, $source->description, (int) $source->submission_version],
            'details' => $details->map(fn ($row) => [$row->id, $row->cost_category_id, Money::decimal(Money::minor($row->nominal)), $row->remark])->all(),
        ], JSON_THROW_ON_ERROR));

        return compact('items', 'fingerprint');
    }

    public function token(string $type, int $id, string $fingerprint): string
    {
        return Crypt::encryptString(json_encode([$type, $id, $fingerprint], JSON_THROW_ON_ERROR));
    }

    public function reviewToken(string $type, int $id, ?BsUsageCheck $latest, ?BsUsageCheckDraft $draft): string
    {
        return Crypt::encryptString(json_encode([$type, $id, $latest?->id, $draft?->id, $draft?->version], JSON_THROW_ON_ERROR));
    }

    public function store(User $checker, string $type, int $id, array $data): BsUsageCheck|BsUsageCheckDraft
    {
        abort_unless($checker->can('akses.approval-finance'), 403);
        $data['save_action'] = $data['save_action'] ?? 'confirm';
        $explicitDecision = array_key_exists('keputusan', $data);
        if (!$explicitDecision) $data['keputusan'] = 'APPROVED';
        $isDraft = $data['save_action'] === 'draft';
        $data = validator($data, [
            'save_action' => 'required|in:draft,confirm',
            'tanggal_pengecekan' => 'required|date_format:Y-m-d',
            'source_token' => 'required|string|max:4096',
            'review_token' => 'nullable|required_if:save_action,draft|string|max:4096',
            'keputusan' => 'required|in:APPROVED,REJECTED',
            'catatan_keputusan' => 'nullable|'.($isDraft ? '' : 'required_if:keputusan,REJECTED|').'string|max:2000',
            'details' => 'required|array|min:1|max:1000',
            'details.*' => 'required|array:source_detail_id,cost_category_id,nominal_disetujui,catatan',
            'details.*.source_detail_id' => 'present|nullable|integer|min:1|distinct',
            'details.*.cost_category_id' => 'present|nullable|integer',
            'details.*.nominal_disetujui' => [$isDraft ? 'present' : 'required', 'nullable', 'numeric', 'min:0', 'max:9999999999999.99', 'regex:/^\d{1,13}(?:\.\d{1,2})?$/D'],
            'details.*.catatan' => 'nullable|string|max:2000',
        ])->validate();
        try {
            $expected = json_decode(Crypt::decryptString($data['source_token']), true, flags: JSON_THROW_ON_ERROR);
        } catch (DecryptException|\JsonException $exception) {
            throw ValidationException::withMessages(['source_token' => 'Referensi pengecekan tidak valid. Buka kembali form dari daftar transaksi.']);
        }

        $reference = $this->source($type, $id);
        $posting = app(FinanceBsExpenseService::class);
        $period = $posting->period($reference);
        $owner = $posting->owner($reference);

        return DB::transaction(function () use ($checker, $type, $id, $data, $expected, $isDraft, $explicitDecision, $reference, $posting, $period, $owner) {
            if (!$isDraft) {
                // Match transaction writes and period closing: period, owners, then source.
                app(PeriodService::class)->lockOpen($period);
                foreach (collect([$owner, (int) $reference->user_id])->filter()->unique()->sort() as $userId) {
                    DB::table('user')->where('id', $userId)->lockForUpdate()->first();
                }
            }
            $source = $this->source($type, $id, true);
            if ($posting->period($source) !== $period || $posting->owner($source) !== $owner
                || (int) $source->user_id !== (int) $reference->user_id) {
                throw ValidationException::withMessages(['source' => 'Transaksi berubah. Muat ulang pemeriksaan Finance.']);
            }
            $latest = BsUsageCheck::where('jenis_transaksi', $type)->where('transaksi_pemakaian_id', $id)->latest('id')->first();
            $draft = BsUsageCheckDraft::where('jenis_transaksi', $type)->where('transaksi_pemakaian_id', $id)->lockForUpdate()->first();
            if ($draft && !isset(self::DECISIONS[$draft->keputusan]) && !$explicitDecision) {
                throw ValidationException::withMessages(['keputusan' => 'Pilih Disetujui Finance atau Ditolak untuk melanjutkan draft lama.']);
            }
            // Source writes are serialized; versioning also catches stale browser tabs.
            $context = null;
            if (!empty($data['review_token'])) {
                try {
                    $context = json_decode(Crypt::decryptString($data['review_token']), true, flags: JSON_THROW_ON_ERROR);
                } catch (DecryptException|\JsonException $exception) {
                    throw ValidationException::withMessages(['review_token' => 'Form pemeriksaan tidak valid. Buka kembali pemeriksaan dari daftar Finance.']);
                }
            }
            if ((!empty($data['review_token']) && $context !== [$type, $id, $latest?->id, $draft?->id, $draft?->version])
                || ($draft && empty($data['review_token']))) {
                throw ValidationException::withMessages(['review_token' => 'Pemeriksaan sudah diperbarui atau dikonfirmasi. Muat ulang untuk melanjutkan versi terbaru.']);
            }
            if ((!$isDraft || self::isEvent($source)) && $source->status !== 'VALIDATED') {
                throw ValidationException::withMessages(['source' => 'Transaksi harus dikonfirmasi oleh pengguna dan disetujui pemilik saldo bila diperlukan sebelum dikonfirmasi Finance.']);
            }
            if (self::awaitingResubmission($source)) {
                throw ValidationException::withMessages(['source' => 'Perbaikan pengajuan harus dikonfirmasi kembali sebelum diperiksa Finance.']);
            }
            $snapshot = $this->snapshot($source, true);
            if ($expected !== [$type, $id, $snapshot['fingerprint']]) {
                throw ValidationException::withMessages(['source_token' => 'Transaksi sumber berubah. Muat ulang form dan periksa kembali rincian sebelum menyimpan.']);
            }
            $items = $snapshot['items'];
            $submitted = collect($data['details']);
            $expectedIds = $items->pluck('source_detail_id')->map(fn ($value) => (int) $value)->sort()->values()->all();
            $submittedIds = $submitted->pluck('source_detail_id')->map(fn ($value) => (int) $value)->sort()->values()->all();
            if ($items->isEmpty() || $expectedIds !== $submittedIds) {
                throw ValidationException::withMessages(['details' => 'Rincian harus memuat setiap baris biaya sumber tepat satu kali. Muat ulang form pemeriksaan.']);
            }

            $source->load('user');
            $attributes = [
                'tanggal_pengecekan' => $data['tanggal_pengecekan'],
                'jenis_transaksi' => $type,
                'transaksi_pemakaian_id' => $source->getKey(),
                'no_referensi' => $source->transaksi_id ?: $type.' #'.$source->getKey(),
                'user_id' => $source->user_id,
                'user_checker_id' => $checker->id,
                'user_name' => $source->user->nama,
                'checker_name' => $checker->nama,
                'periode' => app(PeriodService::class)->ofDate($data['tanggal_pengecekan']),
                'source_fingerprint' => $snapshot['fingerprint'],
                'keputusan' => $data['keputusan'],
                'catatan_keputusan' => $data['catatan_keputusan'] ?? null,
                'revision_of_id' => $latest?->id,
            ];
            $submitted = $submitted->keyBy(fn ($input) => (int) $input['source_detail_id']);
            $details = $items->map(function ($item) use ($submitted, $data) {
                $input = $submitted->get((int) $item['source_detail_id']);
                if ((int) $input['cost_category_id'] !== (int) $item['cost_category_id']) {
                    throw ValidationException::withMessages(['details' => 'Kategori rincian tidak sesuai dengan sumber. Muat ulang form pemeriksaan.']);
                }
                return $item + [
                    'nominal_disetujui' => $data['keputusan'] === 'REJECTED' ? '0.00'
                        : ($input['nominal_disetujui'] === null ? null : Money::decimal(Money::minor($input['nominal_disetujui']))),
                    'catatan' => $input['catatan'] ?? null,
                ];
            });
            if ($isDraft) {
                $draft ??= new BsUsageCheckDraft();
                $draft->fill($attributes + ['details' => $details->all(), 'version' => ($draft->version ?? 0) + 1])->save();

                return $draft;
            }
            if ($owner !== null && $data['keputusan'] === 'APPROVED') {
                $cash = app(BsCashFlowService::class);
                $available = Money::minor($cash->availableBalance($cash->calculate($owner, $period)));
                $previous = $posting->approvedAmount($source);
                $approved = $details->sum(fn ($item) => Money::minor($item['nominal_disetujui']));
                if ($approved > $previous && $approved > $available + $previous) {
                    throw ValidationException::withMessages(['bs_balance' => 'Nominal disetujui Finance melebihi saldo BS yang tersedia. Sisa untuk transaksi ini: Rp '.number_format(($available + $previous) / 100, 2, ',', '.').'.']);
                }
            }
            $check = BsUsageCheck::create($attributes + [
                'document_no' => app(DocumentNumberService::class)->next('CEKBS', $data['tanggal_pengecekan']),
                'source_revision' => (int) $source->submission_version,
            ]);
            $check->details()->createMany($details->all());
            // The draft is consumed only after the complete immutable document was saved.
            $draft?->delete();
            if ($owner !== null) {
                app(BsCashFlowService::class)->recalculateSnapshot($owner, $period);
                app(StockCashFlowService::class)->recalculateSnapshot($owner, $period);
            }

            return $check;
        }, 3);
    }
}

~~~~

## app/Http/Controllers/BsUsageCheckController.php

Menyiapkan item pemeriksaan dan membaca riwayat hasil Finance.

~~~~php
<?php

namespace App\Http\Controllers;

use App\Models\BsUsageCheck;
use App\Models\BsUsageCheckDetail;
use App\Models\BsUsageCheckDraft;
use App\Models\User;
use App\Services\BsUsageCheckService;
use App\Services\BsUsageDashboardService;
use App\Services\PeriodService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class BsUsageCheckController extends Controller
{
    public function index(Request $request)
    {
        $filters = $this->filters($request);
        $data = match ($filters['tampilan']) {
            'rincian' => $this->reportData($filters),
            'draft' => $this->draftData($filters),
            default => $this->sourceData($request, $filters),
        };

        return view('bs-usage-checks.index', $data + ['filters' => $filters, 'users' => $this->users()]);
    }

    public function create(string $jenis, int $source, BsUsageCheckService $service)
    {
        $transaction = $service->source($jenis, $source);
        $transaction->load('user');
        $snapshot = $service->snapshot($transaction);
        $draft = BsUsageCheckDraft::where('jenis_transaksi', $jenis)->where('transaksi_pemakaian_id', $source)->first();
        $revisionOf = $transaction->financeChecks()->latest('id')->with('details')->first();
        $previous = $draft ? collect($draft->details) : ($revisionOf?->details->map(fn ($detail) => $detail->getAttributes()) ?? collect());
        if (!$draft && $revisionOf?->keputusan === 'REJECTED') $previous = collect();
        $previousLines = $previous->filter(fn ($item) => !empty($item['source_detail_id']))->keyBy('source_detail_id');
        $previousCategories = $previous->filter(fn ($item) => empty($item['source_detail_id']))
            ->keyBy(fn ($item) => (int) $item['cost_category_id']);
        $categoryCounts = $snapshot['items']->countBy(fn ($item) => (int) $item['cost_category_id']);
        $needsItemReview = false;
        $items = $snapshot['items']->map(function ($item) use ($previousLines, $previousCategories, $categoryCounts, &$needsItemReview) {
            $saved = $previousLines->get($item['source_detail_id']);
            $legacy = $previousCategories->get((int) $item['cost_category_id']);
            $ambiguous = !$saved && $legacy && $categoryCounts[(int) $item['cost_category_id']] > 1;
            $needsItemReview = $needsItemReview || $ambiguous;
            if (!$saved && !$ambiguous) $saved = $legacy;
            $same = $saved && (int) $saved['cost_category_id'] === (int) $item['cost_category_id']
                && \App\Support\Money::minor($saved['nominal_asal']) === \App\Support\Money::minor($item['nominal_asal'])
                && (empty($saved['source_detail_id']) || ($saved['source_remark'] ?? '') === ($item['source_remark'] ?? ''));
            return $item + [
                'nominal_disetujui' => $ambiguous ? null : ($same ? $saved['nominal_disetujui'] : $item['nominal_asal']),
                'catatan' => $same ? ($saved['catatan'] ?? '') : '',
            ];
        });
        $previousFingerprint = $draft?->source_fingerprint ?? $revisionOf?->source_fingerprint;
        $sourceChanged = $previousFingerprint && $previousFingerprint !== $snapshot['fingerprint'];
        $defaults = [
            'tanggal_pengecekan' => $draft?->tanggal_pengecekan->toDateString() ?? \App\Support\AppTime::now()->toDateString(),
            'keputusan' => $draft && !isset(BsUsageCheckService::DECISIONS[$draft->keputusan]) ? '' : ($draft?->keputusan ?? 'APPROVED'),
            'catatan_keputusan' => $draft?->catatan_keputusan ?? '',
        ];

        return view('bs-usage-checks.create', [
            'transaction' => $transaction, 'jenis' => $jenis, 'items' => $items,
            'sourceToken' => $service->token($jenis, $source, $snapshot['fingerprint']),
            'reviewToken' => $service->reviewToken($jenis, $source, $revisionOf, $draft),
            'draft' => $draft, 'revisionOf' => $revisionOf, 'defaults' => $defaults, 'sourceChanged' => $sourceChanged,
            'needsItemReview' => $needsItemReview,
            'historyCount' => $transaction->financeChecks()->count(),
        ]);
    }

    public function store(Request $request, string $jenis, int $source, BsUsageCheckService $service)
    {
        $check = $service->store($request->user(), $jenis, $source, $request->all());
        if ($check instanceof BsUsageCheckDraft) {
            return redirect()->route('bs-usage-checks.create', [$jenis, $source])
                ->with('success', 'Draft pemeriksaan tersimpan. Draft belum menjadi hasil Finance pada dashboard dan laporan.');
        }

        return redirect()->route('bs-usage-checks.show', $check)
            ->with('success', 'Pengecekan '.$check->document_no.' dikonfirmasi. Sisa Saldo BS dan Total Keluar Stok Kas mengikuti hasil Finance terakhir.');
    }

    public function show(BsUsageCheck $check)
    {
        $check->load(['details', 'source', 'revisionOf']);
        $history = BsUsageCheck::where('jenis_transaksi', $check->jenis_transaksi)
            ->where('transaksi_pemakaian_id', $check->transaksi_pemakaian_id)->orderByDesc('id')->paginate(10)->withQueryString();

        return view('bs-usage-checks.show', compact('check', 'history'));
    }

    public function report(Request $request)
    {
        // Keep existing bookmarks working inside the same Finance workspace.
        $request->merge(['tampilan' => 'rincian']);

        return $this->index($request);
    }

    private function filters(Request $request): array
    {
        if ($request->query('status_finance') === 'RECHECK') {
            $request->query->set('status_finance', 'PENDING');
        }

        $filters = $request->validate([
            'tampilan' => 'nullable|in:transaksi,rincian,draft',
            'tanggal_awal' => 'nullable|date_format:Y-m-d',
            'tanggal_akhir' => ['nullable', 'date_format:Y-m-d', ...($request->filled('tanggal_awal') ? ['after_or_equal:tanggal_awal'] : [])],
            'periode' => ['nullable', 'regex:/^\\d{4}-?(0[1-9]|1[0-2])$/D'],
            'jenis' => 'nullable|in:OPR,PD,EDK,ELK',
            'referensi' => 'nullable|string|max:64',
            'user_id' => 'nullable|integer|exists:user,id',
            'status_selisih' => 'nullable|in:sesuai,tidak_sesuai',
            'status_finance' => 'nullable|in:PENDING,REVIEWED,APPROVED,REJECTED,REVISION',
            'status_cek' => 'nullable|in:sudah,belum',
            'mode' => 'nullable|in:terakhir,semua',
            'source_id' => 'nullable|required_with:jenis_source|integer|min:1',
            'jenis_source' => 'nullable|required_with:source_id|in:OPR,PD,EDK,ELK',
            'page' => 'nullable|integer|min:1',
        ]);
        if (!empty($filters['periode'])) {
            $filters['periode'] = app(PeriodService::class)->normalize($filters['periode']);
        }
        $filters['tampilan'] = $filters['tampilan'] ?? 'transaksi';
        $filters['mode'] = $filters['tampilan'] === 'rincian' ? ($filters['mode'] ?? 'terakhir') : 'terakhir';
        // Normalize old lookup links to the new status filter.
        if (!$request->has('status_finance') && !empty($filters['status_cek'])) {
            $filters['status_finance'] = $filters['status_cek'] === 'belum' ? 'PENDING' : 'REVIEWED';
        }
        unset($filters['status_cek'], $filters['page']);
        if ($filters['tampilan'] !== 'transaksi') unset($filters['status_finance']);
        if ($filters['tampilan'] === 'draft') unset($filters['status_selisih']);

        return $filters;
    }

    private function sourceData(Request $request, array $filters): array
    {
        $query = app(BsUsageDashboardService::class)->financeSources($request->user());
        foreach (['jenis' => 'jenis', 'user_id' => 'user_id', 'periode' => 'check_period', 'source_id' => 'source_id', 'jenis_source' => 'jenis'] as $filter => $column) {
            if (!empty($filters[$filter])) $query->where($column, $filters[$filter]);
        }
        if (!empty($filters['referensi'])) $query->where('no_referensi', 'like', '%'.$filters['referensi'].'%');
        if (!empty($filters['tanggal_awal'])) $query->where('tanggal_pengecekan', '>=', $filters['tanggal_awal']);
        if (!empty($filters['tanggal_akhir'])) $query->where('tanggal_pengecekan', '<', \Carbon\CarbonImmutable::parse($filters['tanggal_akhir'])->addDay()->toDateString());
        if (($filters['status_finance'] ?? '') === 'REVIEWED') {
            $query->whereNotNull('check_id');
        } elseif (!empty($filters['status_finance'])) {
            $query->where('finance_status', $filters['status_finance']);
        }
        if (!empty($filters['status_selisih'])) {
            // A stale comparison cannot classify the current transaction as matching.
            $query->whereNotNull('check_id')->where('needs_recheck', 0)
                ->where('different_items', $filters['status_selisih'] === 'sesuai' ? '=' : '>', 0);
        }
        $final = "finance_status IN ('APPROVED', 'REJECTED')";
        $totals = (clone $query)->selectRaw("COUNT(*) as count,
            COALESCE(SUM(nominal_user), 0) as nominal_asal,
            COALESCE(SUM(CASE WHEN $final THEN nominal_finance ELSE 0 END), 0) as nominal_disetujui,
            COALESCE(SUM(CASE WHEN $final THEN nominal_user - nominal_finance ELSE 0 END), 0) as selisih,
            COALESCE(SUM(CASE WHEN $final THEN 0 ELSE 1 END), 0) as unresolved_count")->first();
        $sources = $query->select('usage.*')
            ->selectRaw("CASE WHEN $final THEN nominal_user - nominal_finance ELSE NULL END as selisih")
            ->orderByDesc('tanggal')->orderBy('jenis')->orderByDesc('source_id')
            ->paginate(20)->withPath(route('bs-usage-checks.index'))->appends($filters);
        $drafts = BsUsageCheckDraft::whereIn('jenis_transaksi', $sources->pluck('jenis'))
            ->whereIn('transaksi_pemakaian_id', $sources->pluck('source_id'))
            ->get()->keyBy(fn ($draft) => $draft->jenis_transaksi.':'.$draft->transaksi_pemakaian_id);
        foreach ($sources as $source) $source->draft = $drafts->get($source->jenis.':'.$source->source_id);

        return compact('sources', 'totals');
    }

    private function draftData(array $filters): array
    {
        $query = BsUsageCheckDraft::query();
        foreach (['jenis' => 'jenis_transaksi', 'user_id' => 'user_id', 'periode' => 'periode', 'source_id' => 'transaksi_pemakaian_id', 'jenis_source' => 'jenis_transaksi'] as $filter => $column) {
            if (!empty($filters[$filter])) $query->where($column, $filters[$filter]);
        }
        if (!empty($filters['referensi'])) $query->where('no_referensi', 'like', '%'.$filters['referensi'].'%');
        if (!empty($filters['tanggal_awal'])) $query->where('tanggal_pengecekan', '>=', $filters['tanggal_awal']);
        if (!empty($filters['tanggal_akhir'])) $query->where('tanggal_pengecekan', '<', \Carbon\CarbonImmutable::parse($filters['tanggal_akhir'])->addDay()->toDateString());
        $drafts = $query->with(['source', 'revisionOf'])->orderByDesc('updated_at')->orderByDesc('id')
            ->paginate(20)->withPath(route('bs-usage-checks.index'))->appends($filters);

        return compact('drafts');
    }

    private function reportData(array $filters): array
    {
        $headers = BsUsageCheck::query();
        if ($filters['mode'] === 'terakhir') $headers->latestPerSource();
        foreach (['jenis' => 'jenis_transaksi', 'user_id' => 'user_id', 'periode' => 'periode', 'source_id' => 'transaksi_pemakaian_id', 'jenis_source' => 'jenis_transaksi'] as $filter => $column) {
            if (!empty($filters[$filter])) $headers->where($column, $filters[$filter]);
        }
        if (!empty($filters['referensi'])) $headers->where('no_referensi', 'like', '%'.$filters['referensi'].'%');
        if (!empty($filters['tanggal_awal'])) $headers->where('tanggal_pengecekan', '>=', $filters['tanggal_awal']);
        if (!empty($filters['tanggal_akhir'])) {
            $headers->where('tanggal_pengecekan', '<', \Carbon\CarbonImmutable::parse($filters['tanggal_akhir'])->addDay()->toDateString());
        }
        $different = fn (Builder $q) => $q->whereColumn('nominal_asal', '<>', 'nominal_disetujui');
        if (($filters['status_selisih'] ?? '') === 'tidak_sesuai') {
            $headers->whereHas('details', $different);
        } elseif (($filters['status_selisih'] ?? '') === 'sesuai') {
            $headers->whereDoesntHave('details', $different);
        }

        $query = BsUsageCheckDetail::whereIn('bs_usage_check_id', $headers->select('bs_usage_checks.id'));
        $totals = (clone $query)->selectRaw('COALESCE(SUM(nominal_asal), 0) as nominal_asal, COALESCE(SUM(nominal_disetujui), 0) as nominal_disetujui, COALESCE(SUM(nominal_asal - nominal_disetujui), 0) as selisih')->toBase()->first();
        $rows = $query->with('check')->orderByDesc('bs_usage_check_id')->orderBy('id')
            ->paginate(30)->withPath(route('bs-usage-checks.index'))->appends($filters);

        return compact('rows', 'totals');
    }

    private function users()
    {
        return User::orderBy('nama')->get(['id', 'nama']);
    }
}

~~~~

## app/Models/BsUsageCheck.php

Relasi pemeriksaan ke transaksi sumber dan detail pemeriksaan.

~~~~php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BsUsageCheck extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['tanggal_pengecekan' => 'date'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function checker()
    {
        return $this->belongsTo(User::class, 'user_checker_id');
    }

    public function source()
    {
        return $this->morphTo(__FUNCTION__, 'jenis_transaksi', 'transaksi_pemakaian_id');
    }

    public function details()
    {
        return $this->hasMany(BsUsageCheckDetail::class);
    }

    public function revisionOf()
    {
        return $this->belongsTo(self::class, 'revision_of_id');
    }

    public function scopeLatestPerSource(Builder $query): Builder
    {
        // Choose the globally latest saved check BEFORE date/status filters.
        return $query->whereIn('bs_usage_checks.id', DB::table('bs_usage_checks')
            ->selectRaw('MAX(id)')->groupBy('jenis_transaksi', 'transaksi_pemakaian_id'));
    }

    public function scopeDifferent(Builder $query): Builder
    {
        return $query->whereHas('details', fn ($detail) => $detail->whereColumn('nominal_asal', '<>', 'nominal_disetujui'));
    }
}

~~~~

## app/Models/BsUsageCheckDetail.php

Model rincian pemeriksaan; terkait jika metadata foto disimpan sebagai snapshot historis.

~~~~php
<?php

namespace App\Models;

use App\Support\Money;
use Illuminate\Database\Eloquent\Model;

class BsUsageCheckDetail extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected $casts = ['nominal_asal' => 'decimal:2', 'nominal_disetujui' => 'decimal:2'];

    public function check()
    {
        return $this->belongsTo(BsUsageCheck::class, 'bs_usage_check_id');
    }

    public function costCategory()
    {
        return $this->belongsTo(CostCategory::class);
    }

    public function getSelisihAttribute(): string
    {
        return Money::decimal(Money::minor($this->nominal_asal) - Money::minor($this->nominal_disetujui));
    }
}

~~~~

## app/Models/BsUsageCheckDraft.php

Model draft pemeriksaan; terkait bila foto ikut menjadi bagian snapshot draft.

~~~~php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BsUsageCheckDraft extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['tanggal_pengecekan' => 'date', 'details' => 'array', 'version' => 'integer'];

    public function source()
    {
        return $this->morphTo(__FUNCTION__, 'jenis_transaksi', 'transaksi_pemakaian_id');
    }

    public function revisionOf()
    {
        return $this->belongsTo(BsUsageCheck::class, 'revision_of_id');
    }
}

~~~~

## resources/views/bs-usage-checks/create.blade.php

Tabel rincian saat Finance memeriksa nominal per item.

~~~~php
@extends('layouts.app-with-sidebar')
@section('title', 'Form Pengecekan Pemakaian BS')
@section('content')
    @include('transaction-recap.assets')
    @php
        $reloadInputs = $errors->has('source_token') || $errors->has('review_token') || $errors->has('details');
        $fieldValue = fn ($name) => $reloadInputs ? $defaults[$name] : old($name, $defaults[$name]);
        $canSave = $items->isNotEmpty() && !\App\Services\BsUsageCheckService::awaitingResubmission($transaction);
    @endphp
    <div class="recap-workspace">
        <a class="recap-back" href="{{ route('bs-usage-checks.index') }}"><i class="bi bi-arrow-left" aria-hidden="true"></i>Kembali ke daftar pengecekan</a>
        <header class="recap-head"><div><div class="recap-eyebrow">Pemeriksaan Finance</div><h1>{{ $draft ? 'Lanjutkan draft pemeriksaan' : ($historyCount ? 'Periksa kembali pengajuan' : 'Periksa pengajuan') }}</h1><p>Simpan pekerjaan sebagai draft atau konfirmasikan hasil pemeriksaan. Setiap konfirmasi menyimpan keputusan baru; keputusan sebelumnya tetap tercatat.</p></div></header>
        @include('bs-usage-checks.shared')
        <ol class="check-steps" aria-label="Langkah pemeriksaan"><li><span class="check-step">1</span>Tinjau pengajuan</li><li><span class="check-step">2</span>Periksa nominal</li><li><span class="check-step">3</span>Konfirmasi keputusan</li></ol>
        @if($reloadInputs)<div class="alert alert-warning" role="alert">Rincian terbaru sudah ditampilkan. Periksa kembali nominal dan catatan sebelum konfirmasi.</div>@endif
        @if($draft)<div class="alert alert-secondary"><strong>Draft pemeriksaan #{{ $draft->id }}</strong> · terakhir disimpan oleh {{ $draft->checker_name }} pada {{ \App\Support\AppTime::format($draft->updated_at) }}. Draft ini belum menjadi hasil Finance.</div>@endif
        @if($revisionOf)<div class="alert alert-info">Pemeriksaan sebelumnya: <a href="{{ route('bs-usage-checks.show', $revisionOf) }}">{{ $revisionOf->document_no }}</a>. Dokumen tersebut tetap tersimpan setelah konfirmasi baru.</div>@endif
        @if($sourceChanged)<div class="alert alert-warning">Pengajuan berubah sejak pemeriksaan terakhir. Nominal item yang berubah atau baru diisi dari pengajuan terbaru; periksa kembali sebelum menyimpan.</div>@endif
        @if($needsItemReview)<div class="alert alert-warning" role="alert">Pemeriksaan sebelumnya menggabungkan beberapa rincian dalam satu kategori. Isi nominal persetujuan untuk setiap rincian tersebut. Hasil lama tetap tersedia dalam riwayat atau daftar draft.</div>@endif
        @if(\App\Services\BsUsageCheckService::awaitingResubmission($transaction))<div class="alert alert-warning">Pengajuan perlu dikonfirmasi kembali sebelum pemeriksaan Finance dapat dilanjutkan.</div>@endif
        @if($transaction->status !== 'VALIDATED')<div class="alert alert-info">Transaksi sumber belum final ({{ $transaction->status }}). Pemeriksaan ini mencatat rincian saat ini; sumber belum masuk rekap pengajuan terkonfirmasi.</div>@endif
        @if($draft?->keputusan === 'REVISION')<div class="alert alert-warning">Draft lama menggunakan keputusan Perlu Revisi. Pilih Disetujui Finance atau Ditolak sebelum menyimpan kembali; rincian draft tetap tersedia.</div>@endif
        <form method="POST" action="{{ route('bs-usage-checks.store', ['jenis' => $jenis, 'source' => $transaction->id]) }}" id="bs-check-form" class="check-form">
            @csrf
            <input type="hidden" name="source_token" value="{{ $sourceToken }}">
            <input type="hidden" name="review_token" value="{{ $reviewToken }}">
            <section class="check-card"><h2 class="h6 fw-bold mb-3"><span class="check-step">1</span>Pengajuan yang diperiksa</h2>
                <div class="check-context"><div><small>{{ \App\Services\BsUsageCheckService::LABELS[$jenis] }}</small><strong>{{ $transaction->transaksi_id }}</strong><small>{{ $transaction->user->nama }}</small></div><a class="btn btn-sm btn-outline-primary" href="{{ route('transaction-recap.show', [$jenis, $transaction->id]) }}">Rincian &amp; Bukti Pengajuan</a></div>
                <div class="row g-3"><div class="col-sm-6"><label class="form-label" for="tanggal_pengecekan">Tanggal pengecekan</label><input type="date" class="form-control" id="tanggal_pengecekan" name="tanggal_pengecekan" value="{{ $fieldValue('tanggal_pengecekan') }}" required></div><div class="col-sm-6"><label class="form-label" for="periode">Periode pemeriksaan</label><input id="periode" class="form-control check-readonly" value="{{ substr($fieldValue('tanggal_pengecekan'), 0, 7) }}" readonly><div class="form-text">Mengikuti tanggal pengecekan.</div></div></div>
                <details class="recap-guide mb-0"><summary>Informasi dokumen otomatis</summary><dl class="row small mt-3 mb-0"><dt class="col-sm-4">Nomor dokumen</dt><dd class="col-sm-8">Otomatis saat Simpan Konfirmasi</dd><dt class="col-sm-4">Checker</dt><dd class="col-sm-8">{{ auth()->user()->nama }}</dd><dt class="col-sm-4">Referensi</dt><dd class="col-sm-8">{{ $jenis }} · {{ $transaction->transaksi_id }}</dd></dl></details>
            </section>
            <section class="check-card"><h2 class="h6 fw-bold"><span class="check-step">2</span>Periksa nominal per item</h2><p class="small text-muted">Setiap rincian biaya diperiksa terpisah, termasuk yang kategorinya sama. Nominal awal mengikuti pengajuan; ubah hanya rincian yang perlu disesuaikan.</p>
                <div class="table-responsive"><table class="table check-table" role="table"><thead role="rowgroup"><tr role="row"><th scope="col">Item</th><th scope="col">Keterangan</th><th scope="col" class="check-money">Nominal Asal (Rp)</th><th scope="col" class="check-money">Nominal Disetujui (Rp)</th><th scope="col" class="check-money">Selisih (Rp)</th><th scope="col">Catatan internal Finance</th></tr></thead><tbody role="rowgroup">
                    @forelse($items as $item)
                        @php
                            $key = (int) $item['source_detail_id'];
                            $itemLabel = $item['cost_category_name'].' · '.($item['source_remark'] ?: 'Rincian '.$loop->iteration);
                            $restoreItem = !$reloadInputs && (string) old('details.'.$key.'.source_detail_id') === (string) $item['source_detail_id'];
                        @endphp
                        <tr role="row" data-check-item data-original-minor="{{ \App\Support\Money::minor($item['nominal_asal']) }}">
                            <td role="cell" class="fw-semibold">{{ $item['cost_category_name'] }}<input type="hidden" name="details[{{ $key }}][source_detail_id]" value="{{ $item['source_detail_id'] }}"><input type="hidden" name="details[{{ $key }}][cost_category_id]" value="{{ $item['cost_category_id'] }}"></td>
                            <td role="cell" data-label="Keterangan" class="text-break">{{ $item['source_remark'] ?: '—' }}</td>
                            <td role="cell" data-label="Nominal asal (Rp)" class="check-money">{{ number_format($item['nominal_asal'], 2, ',', '.') }}</td>
                            <td role="cell" data-label="Nominal disetujui (Rp)"><input aria-label="Nominal disetujui {{ $itemLabel }}" type="number" inputmode="decimal" min="0" max="9999999999999.99" step="0.01" class="form-control text-end" data-approved name="details[{{ $key }}][nominal_disetujui]" value="{{ $restoreItem ? old('details.'.$key.'.nominal_disetujui', $item['nominal_disetujui']) : $item['nominal_disetujui'] }}" required></td>
                            <td role="cell" data-label="Selisih (Rp)" class="check-money" data-difference>0,00</td>
                            <td role="cell" data-label="Catatan internal Finance"><textarea aria-label="Catatan {{ $itemLabel }}" class="form-control" name="details[{{ $key }}][catatan]" maxlength="2000" rows="2" placeholder="Catatan untuk pemeriksaan…">{{ $restoreItem ? old('details.'.$key.'.catatan', $item['catatan']) : $item['catatan'] }}</textarea></td>
                        </tr>
                    @empty<tr><td colspan="6" class="text-center text-muted py-4">Transaksi ini belum mempunyai rincian biaya aktif. Tambahkan rincian pada transaksi sumber sebelum melakukan pengecekan.</td></tr>@endforelse
                </tbody><tfoot><tr class="fw-bold"><td colspan="2">Total</td><td data-label="Nominal asal (Rp)" class="check-money" id="check-total-original">{{ number_format(\App\Support\Money::decimal($items->sum(fn ($item) => \App\Support\Money::minor($item['nominal_asal']))), 2, ',', '.') }}</td><td data-label="Nilai pemeriksaan (Rp)" class="check-money" id="check-total-approved">—</td><td data-label="Selisih (Rp)" class="check-money" id="check-total-difference">—</td><td></td></tr></tfoot></table></div>
                <p class="small text-muted mb-0">Selisih = nominal asal − nominal disetujui. Catatan per item hanya terlihat pada halaman Finance.</p>
            </section>
            <section class="check-card"><h2 class="h6 fw-bold mb-3"><span class="check-step">3</span>Tentukan keputusan Finance</h2><div class="row g-3">
                <div class="col-md-4"><label class="form-label" for="keputusan">Keputusan Finance</label><select class="form-select" name="keputusan" id="keputusan" aria-describedby="check-decision-help" required><option value="" @selected($fieldValue('keputusan') === '') disabled>Pilih keputusan Finance</option>@foreach(\App\Services\BsUsageCheckService::DECISIONS as $value => $label)<option value="{{ $value }}" @selected($fieldValue('keputusan') === $value)>{{ $label }}</option>@endforeach</select></div>
                <div class="col-md-8"><label class="form-label" for="catatan_keputusan">Catatan Keputusan untuk User <span id="check-note-required" class="text-danger"></span></label><textarea class="form-control" name="catatan_keputusan" id="catatan_keputusan" rows="3" maxlength="2000" aria-describedby="decision-note-hint" placeholder="Jelaskan alasan atau perbaikan yang diperlukan…">{{ $fieldValue('catatan_keputusan') }}</textarea><div class="form-text" id="decision-note-hint">Terlihat oleh user setelah konfirmasi. Alasan penolakan wajib diisi saat mengonfirmasi keputusan Ditolak.</div></div>
            </div><p class="check-decision-help mb-0" id="check-decision-help" role="status">Persetujuan memakai nominal hasil pemeriksaan. Penolakan membuat persetujuan nol dan wajib disertai alasan. User dapat memperbaiki dan mengajukan kembali.</p></section>
            <p class="small text-muted">Simpan Draft belum mengubah saldo. Simpan Konfirmasi memperbarui Sisa Saldo BS dan Total Keluar Stok Kas sesuai nominal yang disetujui Finance. Pemeriksaan ulang mengganti hasil sebelumnya; riwayat tetap tersimpan.</p>
            <div class="check-savebar"><div class="check-save-totals"><div><span id="check-approved-label">Total disetujui</span><strong id="check-live-approved">—</strong></div><div><span>Selisih pemeriksaan</span><strong id="check-live-difference">—</strong></div></div><div class="recap-head-actions"><button class="btn btn-outline-secondary" type="submit" name="save_action" value="draft" formnovalidate @disabled(!$canSave)><i class="bi bi-save me-1" aria-hidden="true"></i>Simpan Draft</button><button class="btn btn-primary" type="submit" name="save_action" value="confirm" @disabled(!$canSave)><i class="bi bi-check2-circle me-1" aria-hidden="true"></i>Simpan Konfirmasi</button></div></div>
        </form>
    </div>
@endsection
@push('scripts')<script src="{{ asset('js/bs-usage-checks.js') }}?v={{ filemtime(public_path('js/bs-usage-checks.js')) }}" defer></script>@endpush

~~~~

## resources/views/bs-usage-checks/show.blade.php

Tabel rincian hasil pemeriksaan dan riwayat Finance.

~~~~php
@extends('layouts.app-with-sidebar')
@section('title', 'Hasil Pengecekan — '.$check->document_no)
@push('styles')
    <link rel="stylesheet" href="{{ asset('css/bs-usage-check-result.css') }}?v={{ filemtime(public_path('css/bs-usage-check-result.css')) }}">
@endpush
@section('content')
    @php
        $asal = $check->details->sum(fn ($item) => \App\Support\Money::minor($item->nominal_asal));
        $disetujui = $check->details->sum(fn ($item) => \App\Support\Money::minor($item->nominal_disetujui));
        $sesuai = $check->details->every(fn ($item) => $item->selisih === '0.00');
    @endphp
    <div class="check-result-page">
    <header class="check-result-header">
        <div>
            <h1 class="h3">Hasil Pengecekan Pemakaian BS</h1>
            <div class="check-result-document"><span>{{ $check->document_no }}</span><span class="check-result-confirmed"><i class="bi bi-file-earmark-check" aria-hidden="true"></i>Dikonfirmasi</span></div>
        </div>
        <div class="check-result-actions">
            <a class="btn btn-outline-secondary" href="{{ route('bs-usage-checks.index') }}"><i class="bi bi-arrow-left" aria-hidden="true"></i>Daftar Pemakaian</a>
            @if($check->source)<a class="btn btn-primary" href="{{ route('bs-usage-checks.create', ['jenis' => $check->jenis_transaksi, 'source' => $check->transaksi_pemakaian_id]) }}"><i class="bi bi-pencil-square" aria-hidden="true"></i>Ubah Hasil Pemeriksaan</a>@endif
        </div>
    </header>
    @include('bs-usage-checks.shared', ['compactFeedback' => true])
    @include('bs-usage-checks.result')
    <div class="check-card"><div class="row g-3">
        @foreach([
            'Transaksi ID' => $check->id, 'Document No' => $check->document_no,
            'Tanggal Pengecekan' => $check->tanggal_pengecekan->format('d/m/Y'), 'Periode' => $check->periode,
            'Jenis Transaksi' => $check->jenis_transaksi, 'No Referensi' => $check->no_referensi,
            'Transaksi Pemakaian BS ID' => $check->transaksi_pemakaian_id,
            'User Pemilik Transaksi' => $check->user_name, 'User Checker' => $check->checker_name,
            'Waktu Simpan' => \App\Support\AppTime::format($check->created_at),
        ] as $label => $value)<div class="col-md-4"><div class="small text-muted">{{ $label }}</div><div class="fw-semibold">{{ $value }}</div></div>@endforeach
    </div></div>
    @if(!$check->source)<div class="alert alert-info">Transaksi sumber sudah tidak tersedia. Hasil pengecekan dan nomor referensi historis tetap tersimpan.</div>@endif
    <div class="check-card"><div class="d-flex justify-content-between mb-3"><h2 class="h5">Rincian Hasil Pengecekan</h2><span class="badge {{ $sesuai ? 'bg-success' : 'bg-warning text-dark' }} align-self-start">{{ $sesuai ? 'Sesuai' : 'Tidak Sesuai' }}</span></div>
        @if(in_array($check->jenis_transaksi, ['OPR', 'PD']) && $check->details->every(fn ($item) => $item->source_detail_id === null))<p class="alert alert-info small">Dokumen lama ini menyimpan gabungan per kategori. Nominal historis tetap dipertahankan; pemeriksaan baru dilakukan per rincian biaya.</p>@endif
        <div class="table-responsive"><table class="table check-table"><thead><tr><th>Item</th><th>Keterangan</th><th class="check-money">Nominal Asal (Rp)</th><th class="check-money">Nominal Disetujui (Rp)</th><th class="check-money">Selisih (Rp)</th><th>Catatan</th></tr></thead><tbody>
            @foreach($check->details as $item)<tr><td>{{ $item->cost_category_name }}</td><td class="text-break">{{ $item->source_remark ?: '—' }}</td><td class="check-money">{{ number_format($item->nominal_asal, 2, ',', '.') }}</td><td class="check-money">{{ number_format($item->nominal_disetujui, 2, ',', '.') }}</td><td class="check-money {{ $item->selisih !== '0.00' ? 'text-danger' : '' }}">{{ number_format($item->selisih, 2, ',', '.') }}</td><td class="check-note">{{ $item->catatan ?: '—' }}</td></tr>@endforeach
        </tbody><tfoot><tr class="fw-bold"><td colspan="2">Total</td><td class="check-money">{{ number_format(\App\Support\Money::decimal($asal), 2, ',', '.') }}</td><td class="check-money">{{ number_format(\App\Support\Money::decimal($disetujui), 2, ',', '.') }}</td><td class="check-money">{{ number_format(\App\Support\Money::decimal($asal - $disetujui), 2, ',', '.') }}</td><td></td></tr></tfoot></table></div>
        <p class="small text-muted mb-0">Selisih = Nominal Asal − Nominal Disetujui. Hasil konfirmasi Finance terakhir menentukan pengeluaran Stok Kas dan pengurangan saldo BS. Dokumen lama tetap tersimpan sebagai riwayat.</p>
    </div>
    <div class="check-card"><div class="d-flex justify-content-between gap-2 mb-3"><h2 class="h5">Riwayat Pengecekan Referensi Ini</h2><a href="{{ route('bs-usage-checks.index', ['tampilan' => 'rincian', 'mode' => 'semua', 'jenis_source' => $check->jenis_transaksi, 'source_id' => $check->transaksi_pemakaian_id]) }}">Lihat semua riwayat</a></div>
        <div class="table-responsive"><table class="table"><thead><tr><th>Document No</th><th>Tanggal Pengecekan</th><th>Checker</th><th>Waktu Simpan</th></tr></thead><tbody>@foreach($history as $item)<tr class="{{ $item->id === $check->id ? 'table-primary' : '' }}"><td><a href="{{ route('bs-usage-checks.show', $item) }}">{{ $item->document_no }}</a></td><td>{{ $item->tanggal_pengecekan->format('d/m/Y') }}</td><td>{{ $item->checker_name }}</td><td>{{ \App\Support\AppTime::format($item->created_at) }}</td></tr>@endforeach</tbody></table></div>
        {{ $history->links() }}
    </div>
    </div>
@endsection

~~~~

## app/Http/Controllers/TransactionRecapController.php

Pemuatan transaksi untuk halaman detail rekap.

~~~~php
<?php

namespace App\Http\Controllers;

use App\Services\BsUsageCheckService;
use App\Services\BsUsageDashboardService;
use App\Services\BsValidationService;
use App\Services\PeriodService;
use App\Support\AppTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionRecapController extends Controller
{
    public function index(Request $request, BsUsageDashboardService $dashboard)
    {
        $filters = $dashboard->filters($request);
        $type = $filters['pemakaian_jenis'] ?? null;
        unset($filters['pemakaian_jenis']);
        if ($type) {
            return redirect()->route('transaction-recap.module', ['jenis' => $type] + $filters);
        }
        unset($filters['pemakaian_page']);

        return redirect()->to(route('dashboard.transaksi', $filters).'#pemakaian-bs');
    }

    public function module(Request $request, string $jenis, BsUsageDashboardService $dashboard)
    {
        // The route fixes the module; query parameters cannot switch the list.
        $request->query->set('pemakaian_jenis', $jenis);

        return view('transaction-recap.index', $dashboard->data($request) + ['moduleType' => $jenis]);
    }

    public function show(Request $request, string $jenis, int $source, BsUsageCheckService $service, BsUsageDashboardService $dashboard)
    {
        $transaction = $service->source($jenis, $source);
        abort_unless($request->user()->can('akses.approval-finance') || $request->user()->canSeeAllTransactions()
            || (int) $transaction->user_id === (int) $request->user()->id, 403);
        $transaction->load('user');
        if (BsUsageCheckService::isEvent($transaction)) {
            $transaction->load('jamKerja');
            if ($jenis === 'ELK') $transaction->load('wilayah');
        }
        $items = $service->snapshot($transaction)['items'];

        $financeResult = $dashboard->sourceResult($request->user(), $jenis, $source);
        $financeHistory = $transaction->financeChecks()->withSum('details as total_asal', 'nominal_asal')
            ->withSum('details as total_disetujui', 'nominal_disetujui')->latest('id')->paginate(10, ['*'], 'riwayat_page')->withQueryString();
        $latestDecision = $transaction->financeChecks()->latest('id')->first();
        $editUrl = $this->editUrl($jenis, $transaction);
        $canCorrect = (int) $transaction->user_id === (int) $request->user()->id
            && $request->user()->can($this->modulePermission($jenis));
        $periodClosed = $canCorrect && !app(PeriodService::class)->isOpen($transaction->periode);

        return view('transaction-recap.show', compact('transaction', 'items', 'jenis', 'financeResult',
            'financeHistory', 'latestDecision', 'editUrl', 'canCorrect', 'periodClosed'));
    }

    public function correct(Request $request, string $jenis, int $source, BsUsageCheckService $service, BsValidationService $validation)
    {
        abort_unless(in_array($jenis, ['OPR', 'PD'], true), 404);
        abort_unless($request->user()->can($this->modulePermission($jenis)), 403);
        $data = $request->validate(['check_id' => 'required|integer|min:1']);
        $transaction = $service->source($jenis, $source);
        abort_unless((int) $transaction->user_id === (int) $request->user()->id, 403);
        $validation->reopenAfterFinanceRejection($transaction, (int) $data['check_id']);

        return redirect()->to($this->editUrl($jenis, $transaction))
            ->with('success', 'Pengajuan dibuka sebagai draft perbaikan. Simpan perubahan lalu konfirmasikan kembali. Keputusan Finance sebelumnya tetap tersimpan.');
    }

    private function modulePermission(string $type): string
    {
        return match ($type) {
            'OPR' => 'akses.transaksi-operasional', 'PD' => 'akses.transaksi-perjalanan-dinas',
            'EDK' => 'akses.event-dalam-kota', 'ELK' => 'akses.event-luar-kota',
        };
    }

    private function editUrl(string $type, $source): string
    {
        return match ($type) {
            'OPR' => route('transaksi_operasional.show', $source->id).'?edit=1',
            'PD' => route('transaksi_perjalanan_dinas.show', $source->transaksi_id).'?edit=1',
            'EDK' => route('perongkosan_event_dalam_kota.edit', $source->id),
            'ELK' => route('perongkosan_event_luar_kota.edit', $source->id),
        };
    }

    public function confirmEvent(Request $request, string $jenis, int $source, BsUsageCheckService $service)
    {
        abort_unless(in_array($jenis, ['EDK', 'ELK'], true), 404);
        abort_unless($request->user()->can($jenis === 'EDK' ? 'akses.event-dalam-kota' : 'akses.event-luar-kota'), 403);
        $reference = $service->source($jenis, $source);
        $period = app(PeriodService::class)->ofDate($reference->tanggal);
        DB::transaction(function () use ($request, $jenis, $source, $service, $reference, $period) {
            app(PeriodService::class)->lockOpen($period);
            DB::table('user')->where('id', $reference->user_id)->lockForUpdate()->first();
            $transaction = $service->source($jenis, $source, true);
            if ($transaction->tanggal !== $reference->tanggal || (int) $transaction->user_id !== (int) $reference->user_id) {
                throw \Illuminate\Validation\ValidationException::withMessages(['source_token' => 'Event berubah. Muat ulang sebelum konfirmasi.']);
            }
            abort_unless((int) $transaction->user_id === (int) $request->user()->id, 403);
            if ($transaction->status === 'VALIDATED') return;
            $request->validate(['source_token' => 'required|string']);
            $snapshot = $service->snapshot($transaction);
            try {
                $token = json_decode(\Illuminate\Support\Facades\Crypt::decryptString($request->source_token), true, flags: JSON_THROW_ON_ERROR);
            } catch (\Illuminate\Contracts\Encryption\DecryptException|\JsonException $exception) {
                $token = null;
            }
            if ($token !== [$jenis, $source, $snapshot['fingerprint']]) {
                throw \Illuminate\Validation\ValidationException::withMessages(['source_token' => 'Event berubah. Muat ulang dan periksa rincian sebelum konfirmasi.']);
            }
            $transaction->forceFill(['status' => 'VALIDATED', 'validated_at' => AppTime::now(),
                'validated_by' => $request->user()->id, 'submission_version' => $transaction->submission_version + 1])->save();
        });

        return back()->with('success', 'Pengajuan Event dikonfirmasi dan siap diperiksa Finance.');
    }
}

~~~~

## resources/views/transaction-recap/show.blade.php

Tabel rincian transaksi pada rekap.

~~~~php
@extends('layouts.app-with-sidebar', ['panel' => 'transaksi'])

@section('title', 'Rincian Transaksi — '.$transaction->transaksi_id)

@section('content')
    @include('transaction-recap.assets')
    
    @php
        $backFilters = request()->only(['pemakaian_periode', 'pemakaian_status', 'pemakaian_referensi', 'pemakaian_page']);
        $backFilters['pemakaian_periode'] = request()->query->has('pemakaian_periode') ? (request('pemakaian_periode') ?? '') : $transaction->periode;
        $backFilters['jenis'] = $jenis;
        $backRoute = 'transaction-recap.module';
        $isEvent = in_array($jenis, ['EDK', 'ELK']);
        
        $statusLabel = match($transaction->status) { 
            'VALIDATED' => 'Dikonfirmasi', 
            'DRAFT' => 'Belum dikonfirmasi', 
            'PENDING_OWNER' => 'Menunggu pemohon', 
            'REJECTED_OWNER' => 'Ditolak pemohon', 
            default => $transaction->status 
        };

        // 🎯 BARU: Ambil data Pengajuan BS terkait untuk mengecek lampiran
        $bs = $transaction->pengajuanBs ?? $transaction->bonSementara ?? null;
        $isPerjalananDinas = $bs && ($bs->tipe_pengajuan ?? '') === 'perjalanan_dinas';
    @endphp

    <div class="recap-workspace">
        <a class="recap-back" href="{{ route($backRoute, $backFilters) }}#pemakaian-bs">
            <i class="bi bi-arrow-left" aria-hidden="true"></i>Kembali ke Daftar {{ \App\Services\BsUsageCheckService::LABELS[$jenis] }}
        </a>
        
        <header class="recap-head">
            <div>
                <div class="recap-eyebrow">{{ \App\Services\BsUsageCheckService::LABELS[$jenis] }}</div>
                <h1>Rincian Transaksi</h1>
                <p>{{ $transaction->transaksi_id ?: $jenis.' #'.$transaction->id }}</p>
            </div>
            <span class="recap-status {{ $transaction->status === 'VALIDATED' ? 'approved' : 'pending' }}">{{ $statusLabel }}</span>
        </header>

        @include('bs-usage-checks.shared')
        @include('transaction-recap.correction')

        <div class="recap-detail-grid">
            <div>
                {{-- ================= INFORMASI PENGAJUAN ================= --}}
                <section class="recap-card">
                    <h2>Informasi pengajuan</h2>
                    <dl>
                        @foreach(['User' => $transaction->user->nama, 'Tanggal transaksi' => \Carbon\Carbon::parse($transaction->tanggal)->format('d/m/Y'), 'Periode' => $transaction->periode, 'Keterangan' => $transaction->description ?: '—'] as $label => $value)
                            <dt>{{ $label }}</dt><dd>{{ $value }}</dd>
                        @endforeach
                        
                        @if($isEvent)
                            <dt>Kelompok jam kerja</dt><dd>{{ $transaction->jamKerja?->code ?? '—' }}</dd>
                            <dt>Hari libur</dt><dd>{{ $transaction->is_libur ? 'Ya' : 'Tidak' }}</dd>
                            @if($jenis === 'ELK')<dt>Lokasi Event</dt><dd>{{ $transaction->wilayah?->nama ?? '—' }}</dd>@endif
                            <dt>Plafon</dt><dd>{{ $transaction->plafon_value !== null ? 'Rp '.number_format($transaction->plafon_value, 2, ',', '.') : '—' }}</dd>
                        @endif
                    </dl>
                </section>

                {{-- 🎯 BARU: LAMPIRAN PERJALANAN DINAS (dari Pengajuan BS) --}}
                @if($isPerjalananDinas && !empty($bs->attachment_path))
                    <section class="recap-card mt-3">
                        <h2>Lampiran Perjalanan Dinas</h2>
                        <div class="d-flex align-items-center gap-3 p-3 rounded" style="background: linear-gradient(135deg, #f0f4ff 0%, #e8efff 100%); border: 1px solid #c7d2fe;">
                            @php
                                $ext = strtolower(pathinfo($bs->attachment_path, PATHINFO_EXTENSION));
                                $icon = $ext === 'pdf' ? 'bi-file-earmark-pdf-fill text-danger' : 'bi-file-earmark-image-fill text-success';
                            @endphp
                            <i class="bi {{ $icon }}" style="font-size: 2rem;"></i>
                            <div class="flex-grow-1">
                                <div class="fw-semibold" style="font-size: 0.95rem;">
                                    {{ $bs->attachment_name ?? 'Dokumen Pendukung' }}
                                </div>
                                <small class="text-muted">
                                    <i class="bi bi-cloud-check me-1"></i>
                                    {{ strtoupper($ext) }} • Terunggah pada {{ \App\Support\AppTime::format($bs->created_at) }}
                                </small>
                            </div>
                            <a href="{{ asset('storage/' . $bs->attachment_path) }}"
                               target="_blank"
                               class="btn btn-sm btn-primary"
                               style="border-radius: 8px;">
                                <i class="bi bi-eye me-1"></i> Lihat / Unduh
                            </a>
                        </div>
                    </section>
                @endif

                {{-- ================= RINCIAN BIAYA ================= --}}
                <section class="recap-card mt-3">
                    <h2>Rincian biaya yang diajukan</h2>
                    <div class="table-responsive">
                        <table class="table small">
                            <thead>
                                <tr>
                                    <th scope="col">Item</th>
                                    @unless($isEvent)<th scope="col">Keterangan</th>@endunless
                                    <th scope="col" class="text-end">Nominal</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if($isEvent)
                                    @foreach($items as $item)
                                        <tr>
                                            <td>{{ $item['cost_category_name'] }}</td>
                                            <td class="text-end text-nowrap">Rp {{ number_format($item['nominal_asal'], 2, ',', '.') }}</td>
                                        </tr>
                                    @endforeach
                                @else
                                    @foreach($transaction->details()->with('costCategory')->get() as $detail)
                                        <tr>
                                            <td>{{ $detail->costCategory?->nama }}</td>
                                            <td class="text-break">{{ $detail->remark }}</td>
                                            <td class="text-end text-nowrap">Rp {{ number_format($detail->nominal, 2, ',', '.') }}</td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                    <p class="small text-muted mb-0">Nominal asli dari pengajuan user. Hasil Finance terakhir ditampilkan di bawah rincian ini.</p>
                    
                    @if($isEvent && ($transaction->foto_event_1 || $transaction->foto_event_2 || $transaction->foto_event_3))
                        <h3 class="h6 mt-4">Bukti kegiatan</h3>
                        <div class="recap-help-links">
                            @foreach(['foto_event_1', 'foto_event_2', 'foto_event_3'] as $photo)
                                @if($transaction->$photo)
                                    <a href="{{ asset('storage/'.$transaction->$photo) }}" target="_blank" rel="noopener" class="btn btn-sm btn-outline-secondary">
                                        <i class="bi bi-image me-1" aria-hidden="true"></i>Bukti Event {{ $loop->iteration }} <span class="visually-hidden">(tab baru)</span>
                                    </a>
                                @endif
                            @endforeach
                        </div>
                    @endif
                </section>

                {{-- ================= HASIL FINANCE ================= --}}
                @if($financeResult)
                    @include('transaction-recap.finance-result', ['row' => $financeResult])
                @else
                    <section class="recap-card mt-3">
                        <h2>Hasil Finance</h2>
                        <p class="small text-muted mb-0">Pengajuan belum dikonfirmasi. Hasil Finance masuk rekap setelah konfirmasi pengajuan.</p>
                    </section>
                @endif

                @if($isEvent)
                    @include('partials.event-confirmation', ['event' => $transaction, 'eventType' => $jenis])
                @endif
                
                @include('transaction-recap.decision-history')
            </div>

            {{-- ================= SIDEBAR ================= --}}
            <aside>
                <section class="recap-card">
                    <div class="recap-eyebrow">Total pengajuan</div>
                    <div class="recap-detail-amount">Rp {{ number_format($items->sum('nominal_asal'), 2, ',', '.') }}</div>
                    <p class="recap-meta">{{ $items->count() }} kategori biaya</p>
                    
                    @can('akses.approval-finance')
                        @if(!\App\Services\BsUsageCheckService::awaitingResubmission($transaction))
                            <a class="btn btn-primary w-100 mt-2" href="{{ route('bs-usage-checks.create', [$jenis, $transaction->id]) }}">
                                Periksa Pengajuan
                            </a>
                        @else
                            <p class="small text-muted mt-2 mb-0">Menunggu konfirmasi pengajuan sebelum diperiksa Finance.</p>
        @endif
                    @endcan
                </section>

                <section class="recap-card mt-3">
                    <h2>Alur pengajuan</h2>
                    <ol class="recap-step-list">
                        <li>User melengkapi rincian dan mengonfirmasi pengajuan.</li>
                        <li>Finance menyetujui atau menolak dengan alasan.</li>
                        <li>Jika ditolak, user dapat berdiskusi dengan Finance, memperbaiki transaksi, lalu mengonfirmasi pengajuan kembali.</li>
                        <li>Finance memeriksa ulang dan menyimpan keputusan baru. Riwayat keputusan tetap tersimpan.</li>
                    </ol>
                </section>
            </aside>
        </div>
    </div>
@endsection
~~~~

## app/Http/Controllers/BsUsageApprovalController.php

Pemuatan rincian untuk persetujuan pemakaian BS oleh pemilik saldo.

~~~~php
<?php

namespace App\Http\Controllers;

use App\Models\TransaksiPerjalananDinasHeader;
use App\Services\BsCashFlowService;
use App\Services\BsValidationService;
use Illuminate\Http\Request;

class BsUsageApprovalController extends Controller
{
    public function index(Request $request)
    {
        $request->validate(['status' => 'sometimes|in:PENDING_OWNER,REJECTED_OWNER,VALIDATED,ALL']);
        $status = $request->input('status', 'PENDING_OWNER');
        $query = TransaksiPerjalananDinasHeader::forBsOwner((int) $request->user()->id)
            ->where('user_id', '<>', $request->user()->id)->where('approval_version', '>', 0)
            ->with(['user', 'tujuanDinas'])->withSum('details', 'nominal');
        if ($status !== 'ALL') $query->where('status', $status);
        $requests = $query->orderByDesc('submitted_at')->paginate(15)->withQueryString();
        return view('bs-usage-approvals.index', compact('requests', 'status'));
    }

    public function show(int $id, BsCashFlowService $cash)
    {
        $transaksi = $this->document($id);
        $transaksi->load(['user', 'bsOwner', 'details.costCategory', 'tujuanDinas', 'approvalLogs.actor']);
        $balance = $cash->calculate($transaksi->bsCashOwnerId(), $transaksi->periode);
        return view('bs-usage-approvals.show', compact('transaksi', 'balance'));
    }

    public function approve(Request $request, int $id, BsValidationService $service)
    {
        $request->validate(['approval_version' => 'required|integer|min:1']);
        $service->approve($this->document($id), (int) $request->approval_version);
        return redirect()->route('bs-usage-approvals.show', $id)
            ->with('success', 'Pemakaian disetujui dan siap diperiksa Finance. Saldo BS berkurang setelah konfirmasi Finance.');
    }

    public function reject(Request $request, int $id, BsValidationService $service)
    {
        $request->validate(['approval_version' => 'required|integer|min:1', 'reason' => 'required|string|max:1000']);
        $service->reject($this->document($id), (int) $request->approval_version, $request->reason);
        return redirect()->route('bs-usage-approvals.show', $id)
            ->with('success', 'Pemakaian ditolak. Saldo BS tidak berkurang.');
    }

    private function document(int $id): TransaksiPerjalananDinasHeader
    {
        $document = TransaksiPerjalananDinasHeader::findOrFail($id);
        abort_unless($document->bsCashOwnerId() === (int) auth()->id() && $document->needsOwnerApproval(), 403);
        abort_unless($document->approval_version > 0, 404);
        return $document;
    }
}

~~~~

## resources/views/bs-usage-approvals/show.blade.php

Tabel rincian yang diperiksa pemilik saldo BS.

~~~~php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Pemeriksaan Pemakaian BS - {{ $transaksi->transaksi_id }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    @include('partials.mobile-assets')
</head>
<body class="bg-light">
    @include('partials.application-time')
    <main class="container py-4" style="max-width: 1000px">
        <div class="d-flex justify-content-between gap-3 mb-3"><h1 class="h3">Pemeriksaan Pemakaian BS</h1><a href="{{ route('bs-usage-approvals.index') }}" class="btn btn-outline-secondary">Daftar Permintaan</a></div>
        @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
        @if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
        @include('partials.travel-confirmation', ['canEdit' => false])
        <div class="card mb-3"><div class="card-body">
            <h2 class="h5">{{ $transaksi->transaksi_id }}</h2>
            <dl class="row mb-0">
                <dt class="col-sm-4">Anggota yang memakai</dt><dd class="col-sm-8">{{ $transaksi->user?->nama }}</dd>
                <dt class="col-sm-4">Tanggal / Tujuan Dinas</dt><dd class="col-sm-8">{{ \Carbon\Carbon::parse($transaksi->tanggal)->format('d/m/Y') }} / {{ $transaksi->tujuanDinas?->nama }}</dd>
                <dt class="col-sm-4">Keterangan</dt><dd class="col-sm-8">{{ $transaksi->description }}</dd>
                <dt class="col-sm-4">Jarak / Durasi</dt><dd class="col-sm-8">{{ $transaksi->jarak_km }} km / {{ $transaksi->durasi_jam }} jam</dd>
                <dt class="col-sm-4">Saldo BS tersedia ({{ $transaksi->periode }})</dt><dd class="col-sm-8">Rp {{ number_format(app(\App\Services\BsCashFlowService::class)->availableBalance($balance), 2, ',', '.') }}</dd>
            </dl>
            @if(!$balance['opening_final'])<p class="text-warning mb-0">Saldo awal masih menunggu tutup buku bulan sebelumnya.</p>@endif
            @if($transaksi->is_over_plafon)<p class="text-danger mt-2 mb-0">Biaya melebihi plafon Rp {{ number_format($transaksi->plafon_value, 2, ',', '.') }}. Selisih: Rp {{ number_format($transaksi->selisih_plafon, 2, ',', '.') }}.</p>@endif
        </div></div>
        <div class="card mb-3"><div class="table-responsive"><table class="table mb-0">
            <thead><tr><th>Jenis Biaya</th><th>Keterangan</th><th class="text-end">Nominal</th></tr></thead>
            <tbody>@foreach($transaksi->details as $detail)<tr><td>{{ $detail->costCategory?->nama ?? $detail->costCategory?->name ?? $detail->costCategory?->description ?? '-' }}</td><td>{{ $detail->remark }}</td><td class="text-end text-nowrap">Rp {{ number_format($detail->nominal, 2, ',', '.') }}</td></tr>@endforeach</tbody>
            <tfoot><tr><th colspan="2">Total Pemakaian yang Diajukan</th><th class="text-end text-nowrap">Rp {{ number_format($transaksi->details->sum('nominal'), 2, ',', '.') }}</th></tr></tfoot>
        </table></div></div>
        @include('bs-usage-approvals.actions')
        @include('bs-usage-approvals.history')
    </main>
</body>
</html>

~~~~

## database/migrations/2026_10_07_160000_track_finance_approval_per_source_detail.php

Referensi skema source_detail_id/source_remark; bukan migration foto.

~~~~php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bs_usage_check_details', function (Blueprint $table) {
            // Logical reference: OPR/PD rows may be replaced or deleted; history must survive.
            $table->unsignedInteger('source_detail_id')->nullable();
            $table->text('source_remark')->nullable();
            // MySQL needs a replacement index for the parent foreign key before dropping the old unique key.
            $table->index('bs_usage_check_id', 'bs_check_parent_index');
            $table->unique(['bs_usage_check_id', 'source_detail_id'], 'bs_check_source_detail_unique');
        });
        Schema::table('bs_usage_check_details', fn (Blueprint $table) => $table->dropUnique('bs_check_category_unique'));
    }

    public function down(): void
    {
        if (DB::table('bs_usage_check_details')->whereNotNull('source_detail_id')->exists()
            || DB::table('bs_usage_check_drafts')->exists()) {
            throw new RuntimeException('Archive per-item Finance checks and drafts before reverting this migration.');
        }
        Schema::table('bs_usage_check_details', fn (Blueprint $table) =>
            $table->unique(['bs_usage_check_id', 'cost_category_id'], 'bs_check_category_unique'));
        Schema::table('bs_usage_check_details', function (Blueprint $table) {
            $table->dropUnique('bs_check_source_detail_unique');
            $table->dropIndex('bs_check_parent_index');
            $table->dropColumn(['source_detail_id', 'source_remark']);
        });
    }
};

~~~~
